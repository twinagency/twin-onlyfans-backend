# Start here — independent Q3 c657a77

1. Read REVIEW.md for the two separate FAIL verdicts, verified repairs and proof gaps.
2. Read HISTORICAL-MAP.md for all 36 prior register entries.
3. Reproduce the four newly failing cases in test_q3_wording_boundaries.py. The script is outside the application repo and only writes temporary test profile data through existing fixtures.
4. Compare the command/result JSON and raw logs. Each command identifies the exact image, network isolation, capabilities, mount paths and node selection.
5. Read failure-set-comparison.json and end-state.json for baseline versus final failure sets and clean-tree/lab checks.

This package is review evidence, not a source release, deploy instruction or approval. The unchanged exact application source remains at:
 /srv/projects/twin-engine-completion-20261107/claude-completion-v4-20261110/integ
 HEAD c657a77319c3fe32dd787ae38cab6e5a0870fd39.

Reproduction requires existing authorized Work Server access, Docker access to the retained exact image and the isolated PostgreSQL test lab. No AWS, provider or model credentials are needed. Check no other lab job is using the limited tmpfs before rerunning; run one PG test container at a time. Do not restart/clear the shared lab or change its CPU/memory. Follow the saved command arrays rather than constructing a live configuration. Network mode for PG tests joins the network-none lab; pure tests use --network none.

Results:
- pure: 278 pass, 54 subtests.
- pg: 123 pass.
- independent-wording: 4 fail, 2 pass (confirmed unsupported replies).
- sales-and-retained-delivery: 34 known sales fixture failures, 10 pass (7 sales/history cases, 3 retry/receipt cases).
Counts are scoped selections, not total project quality measures.

File ownership capabilities were used only in the isolated ops test container; they are not recommendations for production permissions.
Legacy evidence and all original failure logs remain preserved on Work Server.
