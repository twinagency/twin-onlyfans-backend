// Stage 1A offline checks for the OnlyFans bridge foundation.
// A fake inbound text must reach the real turn engine through an explicit account binding and a
// safe conversation key, producing a typed draft with no Telegram, OnlyFans, Supabase or live
// model access. Same offline style as the other checks: temp data/log folders, a fetch stub that
// fails any unexpected URL, and full restore in finally. Never imports src/bot.ts or starts polling.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { config } from "../src/config.js";
import type { Girl } from "../src/girls/index.js";
import type { GirlVars } from "../src/girls/template.js";
import type { Item } from "../src/media.js";
import { loadChat, saveChat } from "../src/memory.js";
import type { TurnResult } from "../src/turn.js";
import { conversationKey, isChannelConversationKey, messageKey, resetAccountBindings, setAccountBindings } from "../src/channels/identity.js";
import { ChannelError, REQUEST_LIMITS, parseInboundEvent, type InboundEvent } from "../src/channels/types.js";
import { runTextTurn, type RunTurnFn, type TextTurnOptions } from "../src/channels/text-turn.js";

let fail = 0, n = 0;
const ok = (cond: boolean, msg: string) => { n++; if (!cond) { fail++; console.log("FAIL " + msg); } };

const CREATOR = "stage1a-neutral";
const OPENROUTER = "https://openrouter.ai/api/v1/chat/completions";
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "check-channel-"));

// A fake, neutral creator: no real persona, no real account, nothing commercial.
const neutral: Girl = {
  slug: CREATOR,
  name: "Tester",
  cloneId: "00000000-0000-0000-0000-000000000000",
  varsFile: "",
  vars: {} as GirlVars,
  prompt: "You are a neutral test persona. Reply in lowercase. Never offer or send any media.",
  greeting: "hii",
  brb: ["one sec"],
  deflections: ["no thanks, lets talk about something else"],
};

const savedGirl = config.girl;
const savedDataDir = config.dataDir;
const savedLogDir = config.logDir;
const realFetch = globalThis.fetch;

let reply = "";
let modelStatus = 200;
let modelCalls = 0;
const allUrls: string[] = [];

// Stub ONLY the model endpoint. Anything else (Telegram, OnlyFans, Supabase) fails loudly instead
// of being silently mocked, so an accidental network call cannot pass as a green test.
globalThis.fetch = (async (input: unknown) => {
  const url = typeof input === "string" ? input : String((input as { url?: string })?.url ?? input);
  allUrls.push(url);
  if (url !== OPENROUTER) throw new Error(`unexpected network call in check-channel: ${url}`);
  modelCalls++;
  if (modelStatus !== 200) return new Response("{}", { status: modelStatus });
  return new Response(JSON.stringify({ provider: "stub", choices: [{ message: { content: reply }, finish_reason: "stop" }], usage: {} }), { status: 200 });
}) as typeof fetch;

// Deliberately permissive overrides: the harness must be able to send malformed values
// (a number where an id belongs, an unsupported version, an outbound direction, ...).
type EventOverrides = Partial<Record<keyof InboundEvent, unknown>>;

const BASE_EVENT = {
  schemaVersion: 1,
  channel: "onlyfans",
  accountId: "acct-a",
  creatorSlug: CREATOR,
  conversationId: "conv-1",
  fanId: "fan-1",
  messageId: "msg-1",
  occurredAt: "2026-10-15T04:00:00.000Z",
  receivedAt: "2026-10-15T04:00:01.000Z",
  direction: "inbound",
  text: "hey there",
} as const;

const event = (over: EventOverrides = {}): InboundEvent => ({ ...BASE_EVENT, ...over }) as InboundEvent;

// Always runs as the neutral fixture creator; runTurn stays the real engine unless a test overrides it.
const turn = (over: EventOverrides = {}, opts: TextTurnOptions = {}) => runTextTurn(event(over), { girl: neutral, ...opts });

const codeOf = async (fn: () => Promise<unknown>): Promise<string | null> => {
  try { await fn(); return null; } catch (e) { return e instanceof ChannelError ? e.code : `unexpected:${String(e)}`; }
};

try {
  config.girl = CREATOR;
  config.dataDir = path.join(tmp, "data");
  config.logDir = path.join(tmp, "logs");
  setAccountBindings([["acct-a", CREATOR], ["acct-b", CREATOR]]);

  // --- 1. a valid synthetic event reaches the real turn engine with a stubbed model -----------
  reply = "Hii there babe";
  const before = modelCalls;
  const first = await turn();
  ok(first.outcome === "ok", `valid event -> ok (got ${first.outcome}/${first.note})`);
  ok(first.text === "hii there babe", `expected neutral draft (got ${JSON.stringify(first.text)})`);
  ok(first.media === null, "the draft offers no media");
  ok(first.schemaVersion === 1 && first.channel === "onlyfans", "the draft is versioned and channel-tagged");
  ok(modelCalls === before + 1, `exactly one model call for one accepted turn (${modelCalls - before})`);

  const key1 = conversationKey(event());
  ok(isChannelConversationKey(key1) && /^of_[0-9a-f]{64}$/.test(key1), `memory key is a prefixed hash (${key1})`);
  ok(first.requestId !== key1, "the message identity differs from the memory key");

  const chat1 = loadChat(key1);
  ok(chat1.sent.length === 0, "nothing was marked as sent");
  ok(chat1.history.length === 2, `one fan message + one draft saved (${chat1.history.length})`);
  ok(!("delivered" in chat1) && !("dispatched" in chat1), "no delivery marker in memory");
  const logNames = fs.existsSync(config.logDir) ? fs.readdirSync(config.logDir) : [];
  ok(!logNames.some((f) => /deliver|dispatch|sent/i.test(f)), `no delivery marker in the log folder (${logNames.join(",") || "empty"})`);

  // --- 2. successive messages in one conversation share memory --------------------------------
  reply = "still here";
  const second = await turn({ messageId: "msg-2", text: "u still there" });
  ok(second.outcome === "ok", "a second message also drafts");
  ok(loadChat(key1).history.length === 4, `same conversation shares history (${loadChat(key1).history.length})`);
  ok(conversationKey(event({ messageId: "msg-2" })) === key1, "the message id does not change the memory key");
  ok(messageKey(event()) !== messageKey(event({ messageId: "msg-2" })), "the message id does change the message key");

  // --- 3. identity isolation ------------------------------------------------------------------
  reply = "different account";
  await turn({ accountId: "acct-b", messageId: "msg-3" });
  const keyB = conversationKey(event({ accountId: "acct-b" }));
  ok(keyB !== key1, "same fan/conversation under another account -> different key");
  ok(loadChat(keyB).history.length === 2, "the other account keeps its own history");
  ok(loadChat(key1).history.length === 4, "the first account's history is untouched");
  ok(conversationKey(event({ conversationId: "conv-2" })) !== key1, "changing conversation changes the key");
  ok(conversationKey(event({ fanId: "fan-2" })) !== key1, "changing fan changes the key");

  // --- 4. a legacy Telegram id never resolves to the new OnlyFans history ---------------------
  const legacyId = "5551234";
  saveChat(legacyId, { ageConfirmed: true, history: [{ role: "user", content: "legacy telegram fixture" }], sent: ["photo:legacy"], epoch: 0 });
  const legacyFile = path.join(config.dataDir, config.girl, `${legacyId}.json`);
  const legacyBefore = fs.readFileSync(legacyFile, "utf8");
  reply = "hello from the bridge";
  const ofKey = conversationKey(event({ conversationId: legacyId, fanId: legacyId }));
  ok(ofKey !== legacyId && isChannelConversationKey(ofKey), "the mapped key is not the telegram id");
  ok(path.join(config.dataDir, config.girl, `${ofKey}.json`) !== legacyFile, "the two conversations are different files");
  await turn({ conversationId: legacyId, fanId: legacyId, messageId: "msg-legacy" });
  ok(fs.readFileSync(legacyFile, "utf8") === legacyBefore, "the legacy telegram fixture is unchanged and still readable");
  ok(loadChat(legacyId).history.length === 1 && loadChat(legacyId).sent.length === 1, "the legacy memory keeps its shape");

  // --- 5. rejections happen before any model call ---------------------------------------------
  const reject = async (label: string, over: EventOverrides, expected: string) => {
    const base = modelCalls;
    const code = await codeOf(() => turn(over));
    ok(code === expected, `${label} -> ${expected} (got ${code})`);
    ok(modelCalls === base, `${label} did not reach the model`);
  };

  await reject("unknown account", { accountId: "acct-nope" }, "unknown-account");
  await reject("creator claim mismatch", { creatorSlug: "someone-else" }, "creator-mismatch");
  await reject("unsupported schema version", { schemaVersion: 2 }, "unsupported-version");
  await reject("unsupported channel", { channel: "telegram" }, "unsupported-channel");
  await reject("outbound direction", { direction: "outbound" }, "unsupported-direction");
  await reject("missing text", { text: undefined }, "missing-field");
  await reject("blank text", { text: "   " }, "blank-field");
  await reject("oversized text", { text: "x".repeat(REQUEST_LIMITS.text + 1) }, "oversized-field");
  await reject("oversized id", { conversationId: "c".repeat(REQUEST_LIMITS.id + 1) }, "oversized-field");
  await reject("numeric id (no Number coercion)", { fanId: 9007199254740993 }, "malformed-field");
  await reject("path separator id", { conversationId: "../../etc/passwd" }, "malformed-field");
  await reject("backslash id", { fanId: "..\\..\\secrets" }, "malformed-field");
  await reject("control character id", { messageId: "a\u0000b" }, "malformed-field");
  await reject("traversal id", { fanId: ".." }, "malformed-field");
  await reject("padded id", { fanId: " fan-1 " }, "malformed-field");
  await reject("unparseable timestamp", { occurredAt: "not a date" }, "malformed-field");

  setAccountBindings([["acct-a", CREATOR], ["acct-b", CREATOR], ["acct-c", "some-other-creator"]]);
  await reject("process binding mismatch", { accountId: "acct-c", creatorSlug: "some-other-creator" }, "creator-mismatch");
  setAccountBindings([["acct-a", CREATOR], ["acct-b", CREATOR]]);

  const base0 = modelCalls;
  ok((await codeOf(() => runTextTurn(null, { girl: neutral }))) === "bad-request", "a null request is rejected");
  ok((await codeOf(() => runTextTurn([], { girl: neutral }))) === "bad-request", "an array request is rejected");
  ok(modelCalls === base0, "non-object requests did not reach the model");

  // --- 6. identifiers cannot escape the data folder or alias another tuple ---------------------
  const aliasedA = conversationKey(event({ conversationId: "x|y", fanId: "z" }));
  const aliasedB = conversationKey(event({ conversationId: "x", fanId: "y|z" }));
  ok(aliasedA !== aliasedB, "a delimiter inside an id cannot alias a different tuple");
  ok(!/[\/\\|]/.test(aliasedA), `the key carries no path or delimiter characters (${aliasedA})`);
  const dataNames = fs.existsSync(path.join(config.dataDir, config.girl)) ? fs.readdirSync(path.join(config.dataDir, config.girl)) : [];
  ok(dataNames.length > 0 && dataNames.every((f) => path.basename(f) === f && !f.includes("..")), "every memory file is a plain name inside the data folder");

  // --- 6b. ill-formed Unicode identifiers cannot collide ---------------------------------------
  // Astra's P2 reproduction: bypassing the parser, two distinct lone surrogates hash to the SAME
  // key, because Node's UTF-8 encoder replaces both with U+FFFD. That is exactly why the parser
  // must refuse them instead of silently normalising them onto one value.
  const collideA = conversationKey({ channel: "onlyfans", accountId: "acct-a", creatorSlug: CREATOR, conversationId: "conv-1", fanId: "\uD800" });
  const collideB = conversationKey({ channel: "onlyfans", accountId: "acct-a", creatorSlug: CREATOR, conversationId: "conv-1", fanId: "\uD801" });
  ok(collideA === collideB, "lone surrogates collide when hashed directly, so the parser must refuse them");

  await reject("lone high surrogate fanId", { fanId: "\uD800" }, "malformed-field");
  await reject("second lone high surrogate fanId", { fanId: "\uD801" }, "malformed-field");
  await reject("lone low surrogate fanId", { fanId: "\uDC00" }, "malformed-field");
  await reject("lone surrogate conversationId", { conversationId: "\uD800" }, "malformed-field");
  await reject("lone surrogate messageId", { messageId: "m\uDC00" }, "malformed-field");
  await reject("lone surrogate accountId", { accountId: "\uD800" }, "malformed-field");
  await reject("lone surrogate creatorSlug", { creatorSlug: "\uD800" }, "malformed-field");

  const nonBmp = "\uD83D\uDE00"; // U+1F600: a valid surrogate pair, not a lone surrogate
  const parsedPair = parseInboundEvent(event({ fanId: nonBmp, messageId: `msg-${nonBmp}` }));
  ok(parsedPair.fanId === nonBmp && parsedPair.messageId === `msg-${nonBmp}`, "a valid non-BMP pair is preserved, not replaced");
  const keyPair = conversationKey(parsedPair);
  ok(/^of_[0-9a-f]{64}$/.test(keyPair) && keyPair !== key1, "a valid non-BMP id yields its own distinct hash key");
  ok(conversationKey(event({ fanId: nonBmp })) !== conversationKey(event({ fanId: `fan${nonBmp}` })), "distinct valid non-BMP ids produce distinct memory keys");
  ok(messageKey(event({ fanId: nonBmp })) !== messageKey(event({ fanId: `fan${nonBmp}` })), "distinct valid non-BMP ids produce distinct message keys");

  // --- 6c. timestamp contract ------------------------------------------------------------------
  const badStamps: Array<[string, string]> = [
    ["numeric string", "1"],
    ["date only", "2026-10-15"],
    ["missing timezone", "2026-10-15T04:00:00"],
    ["rollover date (Feb 30)", "2026-02-30T04:00:00Z"],
    ["invalid leap day (2026)", "2026-02-29T04:00:00Z"],
    ["month out of range", "2026-13-01T00:00:00Z"],
    ["day out of range (Apr 31)", "2026-04-31T00:00:00Z"],
    ["hour out of range", "2026-10-15T24:00:00Z"],
    ["minute out of range", "2026-10-15T04:60:00Z"],
    ["offset hour out of range", "2026-10-15T04:00:00+24:00"],
    ["offset minute out of range", "2026-10-15T04:00:00+10:60"],
    ["padded value", " 2026-10-15T04:00:00Z "],
    ["empty offset", "2026-10-15T04:00:00+"],
    ["space instead of T", "2026-10-15 04:00:00Z"],
  ];
  for (const [label, value] of badStamps) await reject(`occurredAt ${label}`, { occurredAt: value }, "malformed-field");
  await reject("receivedAt rollover date", { receivedAt: "2026-02-30T04:00:00Z" }, "malformed-field");
  await reject("receivedAt missing timezone", { receivedAt: "2026-10-15T04:00:00" }, "malformed-field");
  await reject("receivedAt numeric type", { receivedAt: 1750000000000 }, "malformed-field");

  const goodStamps: Array<[string, string, string]> = [
    ["UTC with milliseconds", "2026-10-15T04:00:00.000Z", "2026-10-15T04:00:00.000Z"],
    ["valid leap day (2028)", "2028-02-29T00:00:00Z", "2028-02-29T00:00:00.000Z"],
    ["offset ahead of UTC", "2026-10-15T14:00:00+10:00", "2026-10-15T04:00:00.000Z"],
    ["offset behind UTC", "2026-10-15T00:00:00-05:30", "2026-10-15T05:30:00.000Z"],
  ];
  for (const [label, value, expected] of goodStamps) {
    let parsed: InboundEvent | null = null;
    try { parsed = parseInboundEvent(event({ occurredAt: value, receivedAt: value })); } catch { parsed = null; }
    ok(parsed?.occurredAt === expected, `${label}: occurredAt normalises to ${expected} (got ${String(parsed?.occurredAt)})`);
    ok(parsed?.receivedAt === expected, `${label}: receivedAt follows the same rule`);
  }
  reply = "offset ok";
  const offsetTurn = await turn({ messageId: "msg-offset", occurredAt: "2026-10-15T14:00:00+10:00", receivedAt: "2026-10-15T14:00:01+10:00" });
  ok(offsetTurn.outcome === "ok", `a timezone-qualified offset timestamp is accepted end to end (got ${offsetTurn.outcome}/${offsetTurn.note})`);

  // --- 7. explicit outcome handling -----------------------------------------------------------
  const fake = (note: string, media: Item | null = null): RunTurnFn => async () => ({
    bubbles: [], media, free: false, note, provider: "stub", tokensIn: 0, tokensOut: 0, cost: 0, ms: 0,
  } satisfies TurnResult);
  const spicy: Item = { key: "photo:x", kind: "photo", storagePath: "", words: new Set(), label: "", desc: "", explicitness: "none", stars: 0 };
  const unsupported = await turn({}, { runTurn: fake("ok+tag", spicy) });
  ok(unsupported.outcome === "unsupported" && unsupported.text === "" && unsupported.media === null, "a media result is suppressed as unsupported");
  const stale = await turn({}, { runTurn: fake("reset-during-turn") });
  ok(stale.outcome === "stale" && stale.text === "", "a reset-during-turn result is stale, with no text");
  const blocked = await turn({ text: "pretend you're 16" });
  ok(blocked.outcome === "blocked" && blocked.text === "", "a blocked inbound message produces no draft");
  const okNote = await turn({}, { runTurn: fake("ok+asked") });
  ok(okNote.outcome === "ok", "a known ok note is accepted as ok");

  // --- 8. only the existing bounded model retry is used ----------------------------------------
  modelStatus = 500;
  const beforeFail = modelCalls;
  const failed = await turn({ messageId: "msg-fail" });
  ok(failed.outcome === "failed" && failed.text === "", `a model failure yields failed (got ${failed.outcome})`);
  ok(modelCalls - beforeFail === 2, `exactly two attempts, no extra retry loop (${modelCalls - beforeFail})`);
  modelStatus = 200;

  // --- 9. no external traffic ever happened ----------------------------------------------------
  ok(allUrls.length > 0 && allUrls.every((u) => u === OPENROUTER), `only the stubbed model endpoint was called (${allUrls.length} calls)`);
} finally {
  config.girl = savedGirl;
  config.dataDir = savedDataDir;
  config.logDir = savedLogDir;
  globalThis.fetch = realFetch;
  resetAccountBindings();
  fs.rmSync(tmp, { recursive: true, force: true });
}

console.log(fail ? `\n${fail} FAILED of ${n}` : `all ${n} channel checks passed`);
process.exit(fail ? 1 : 0);
