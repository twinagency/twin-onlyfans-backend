// Stage 1B part 2 offline checks: private loopback HTTP adapter.
//
// Real loopback HTTP against ephemeral servers, neutral fixtures, isolated temporary data/logs and a
// stubbed model. Only the local test server and the intercepted model endpoint are reachable: the
// fetch stub rejects every other URL, and the HTTP client uses node:http, never fetch.
// Servers, sockets and timers are closed and all overrides restored in finally.
import fs from "node:fs";
import http from "node:http";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { config } from "../src/config.js";
import type { Girl } from "../src/girls/index.js";
import type { GirlVars } from "../src/girls/template.js";
import { conversationKey, messageKey, resetAccountBindings, setAccountBindings } from "../src/channels/identity.js";
import { StoreError, readState, stateFilesFor } from "../src/channels/store.js";
import type { InboundEvent } from "../src/channels/types.js";
import {
  BRIDGE_API_VERSION,
  BRIDGE_BIND_HOST,
  BRIDGE_DEFAULT_PORT,
  BRIDGE_LIMITS,
  BRIDGE_ROUTES,
  createBridgeServer,
  parseBridgePort,
  startBridgeServer,
  validateBridgeToken,
  type BridgeOperations,
  type RunningBridge,
} from "../src/channels/http.js";
import { main as serveMain } from "../src/channels/serve.js";

let fail = 0, n = 0;
const ok = (cond: boolean, msg: string) => { n++; if (!cond) { fail++; console.log("FAIL " + msg); } };

const CREATOR = "stage1b-http-neutral";
const TOKEN = "test-bridge-token-0123456789abcdef"; // 36 chars, no whitespace
const OPENROUTER = "https://openrouter.ai/api/v1/chat/completions";

const neutral: Girl = {
  slug: CREATOR,
  name: "Tester",
  cloneId: "00000000-0000-0000-0000-000000000000",
  varsFile: "",
  vars: {} as GirlVars,
  prompt: "You are a neutral test persona. Reply in lowercase. Never offer or send any media.",
  greeting: "hii",
  brb: ["one sec"],
  deflections: ["no thanks, lets talk about something else"],
};

// Deliberately permissive overrides: the harness must be able to send malformed values.
type EventOverrides = Partial<Record<keyof InboundEvent, unknown>>;
const BASE_EVENT = {
  schemaVersion: 1,
  channel: "onlyfans",
  accountId: "acct-a",
  creatorSlug: CREATOR,
  conversationId: "http-conv-1",
  fanId: "fan-1",
  messageId: "http-msg-1",
  occurredAt: "2026-10-15T04:00:00.000Z",
  receivedAt: "2026-10-15T04:00:01.000Z",
  direction: "inbound",
  text: "hey there",
} as const;
const event = (over: EventOverrides = {}): InboundEvent => ({ ...BASE_EVENT, ...over }) as InboundEvent;

const settle = async (rounds = 4) => { for (let i = 0; i < rounds; i++) await new Promise<void>((r) => setImmediate(r)); };

// ---------------------------------------------------------------- model stub
let reply = "";
let modelStatus = 200;
let modelCalls = 0;
let holdModel = false;
let releaseModel: (() => void) | null = null;
const externalUrls: string[] = [];
const realFetch = globalThis.fetch;

globalThis.fetch = (async (input: unknown) => {
  const url = typeof input === "string" ? input : String((input as { url?: string })?.url ?? input);
  externalUrls.push(url);
  if (url !== OPENROUTER) throw new Error(`unexpected external network call: ${url}`);
  modelCalls++;
  if (holdModel) await new Promise<void>((resolve) => { releaseModel = resolve; });
  if (modelStatus !== 200) return new Response("{}", { status: modelStatus });
  return new Response(JSON.stringify({ provider: "stub", choices: [{ message: { content: reply }, finish_reason: "stop" }], usage: {} }), { status: 200 });
}) as typeof fetch;
const releaseModelCall = async () => { const r = releaseModel; releaseModel = null; r?.(); await settle(); };

// ---------------------------------------------------------------- HTTP client helpers
type Resp = { status: number; headers: http.IncomingHttpHeaders; text: string; json: any | null };

type CallOptions = {
  token?: string | null;
  body?: string | Buffer;
  headers?: Record<string, string>;
  contentType?: string;
  contentEncoding?: string;
  omitContentType?: boolean;
  declaredLength?: number;
  chunked?: boolean;
  partialBody?: boolean;
  abortAfterMs?: number;
};

function call(port: number, method: string, pathname: string, opts: CallOptions = {}): Promise<Resp> {
  return new Promise<Resp>((resolve, reject) => {
    const headers: Record<string, string> = { ...(opts.headers ?? {}) };
    if (opts.token !== null) headers.authorization = `Bearer ${opts.token ?? TOKEN}`;
    const payload = opts.body === undefined ? undefined : Buffer.isBuffer(opts.body) ? opts.body : Buffer.from(opts.body, "utf8");
    if (payload !== undefined && !opts.omitContentType) headers["content-type"] = opts.contentType ?? "application/json";
    if (opts.contentEncoding) headers["content-encoding"] = opts.contentEncoding;
    if (payload !== undefined && !opts.chunked && !opts.partialBody) headers["content-length"] = String(opts.declaredLength ?? payload.length);

    const req = http.request({ host: BRIDGE_BIND_HOST, port, method, path: pathname, headers, agent: false }, (res) => {
      const chunks: Buffer[] = [];
      res.on("data", (c) => chunks.push(c as Buffer));
      res.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        let json: any = null;
        try { json = JSON.parse(text); } catch { json = null; }
        resolve({ status: res.statusCode ?? 0, headers: res.headers, text, json });
      });
    });
    // A reset socket (for example after the server refused an oversized body) resolves with status 0
    // so the assertion reports it instead of crashing the harness.
    req.on("error", () => resolve({ status: 0, headers: {}, text: "", json: null }));
    if (payload !== undefined) {
      if (opts.partialBody) {
        req.write(payload.subarray(0, 8)); // headers plus a fragment, then nothing: the server must time it out
      } else if (opts.chunked) {
        req.end(payload); // no content-length: node uses chunked transfer-encoding
      } else {
        req.end(payload);
      }
    } else {
      req.end();
    }
    if (opts.abortAfterMs !== undefined) setTimeout(() => req.destroy(), opts.abortAfterMs);
  });
}

/** Raw socket request, for header and byte-level cases the http client cannot express. */
function rawCall(port: number, payload: string | Buffer): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const socket = net.connect(port, BRIDGE_BIND_HOST, () => socket.write(payload));
    const chunks: Buffer[] = [];
    const done = () => resolve(Buffer.concat(chunks).toString("utf8"));
    socket.on("data", (c) => chunks.push(c as Buffer));
    socket.on("end", done);
    socket.on("close", done);
    socket.on("error", reject);
    setTimeout(() => socket.destroy(), 3_000).unref?.();
  });
}

const statusOf = (raw: string) => Number(/^HTTP\/1\.\d (\d{3})/.exec(raw)?.[1] ?? 0);
const post = (port: number, pathname: string, body: unknown, opts: CallOptions = {}) => call(port, "POST", pathname, { body: JSON.stringify(body), ...opts });

/** Capture stdout/stderr so a test can prove no secret or internal detail was logged. */
async function captureStdio<T>(fn: () => Promise<T> | T): Promise<{ result: T; out: string }> {
  const chunks: string[] = [];
  const outWrite = process.stdout.write.bind(process.stdout);
  const errWrite = process.stderr.write.bind(process.stderr);
  process.stdout.write = ((c: unknown) => { chunks.push(String(c)); return true; }) as typeof process.stdout.write;
  process.stderr.write = ((c: unknown) => { chunks.push(String(c)); return true; }) as typeof process.stderr.write;
  try {
    return { result: await fn(), out: chunks.join("") };
  } finally {
    process.stdout.write = outWrite;
    process.stderr.write = errWrite;
  }
}

/** A service stub that records calls, for auth/limit tests that must not touch storage. */
function countingOperations(): { operations: BridgeOperations; calls: string[] } {
  const calls: string[] = [];
  const state = (status: string) => ({
    version: 2,
    requestId: "ofm_stub",
    conversationKey: "of_stub",
    status,
    outcome: "ok",
    note: "internal note must not leak",
    text: "stub draft",
    deliverable: status === "completed",
    epoch: 0,
    failure: "internal failure string must not leak",
    createdAt: "2026-10-15T04:00:00.000Z",
    completedAt: null,
    deliveredAt: null,
    committedAt: null,
    usage: { provider: "stub", tokensIn: 1, tokensOut: 2, cost: 0, ms: 3, attempts: 1 },
  });
  return {
    calls,
    operations: {
      requestReply: async () => { calls.push("requestReply"); return state("completed") as never; },
      readReplyState: async () => { calls.push("readReplyState"); return state("completed") as never; },
      acknowledgeDelivery: async () => { calls.push("acknowledgeDelivery"); return { status: "delivered", conversationKey: "of_stub", requestId: "ofm_stub" }; },
      cancelRequest: async () => { calls.push("cancelRequest"); return { status: "cancelled", conversationKey: "of_stub", requestId: "ofm_stub" }; },
      resetConversation: async () => { calls.push("resetConversation"); return { conversationKey: "of_stub", epoch: 1, cancelled: 0 }; },
    },
  };
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "check-http-"));
const savedGirl = config.girl;
const savedDataDir = config.dataDir;
const savedLogDir = config.logDir;
const servers: RunningBridge[] = [];
const startServer = async (options: Parameters<typeof startBridgeServer>[0] = {}) => {
  const bridge = await startBridgeServer({ token: TOKEN, girl: neutral, ...options });
  servers.push(bridge);
  return bridge;
};

try {
  config.girl = CREATOR;
  config.dataDir = path.join(tmp, "data");
  config.logDir = path.join(tmp, "logs");
  setAccountBindings([["acct-a", CREATOR], ["acct-b", CREATOR]]);

  // --- 1. configuration and authentication ----------------------------------------------------
  ok(validateBridgeToken(TOKEN) === TOKEN, "a valid token is accepted");
  const shortToken = await captureStdio(() => {
    try { validateBridgeToken("too-short"); return "no-throw"; } catch (e) { return String((e as Error).message); }
  });
  ok(String(shortToken.result).includes("32 characters"), `a short token is rejected (${shortToken.result})`);
  ok(!shortToken.out.includes("too-short"), "the token validator logs no value");
  let threw = false;
  try { createBridgeServer({ token: "short" }); } catch { threw = true; }
  ok(threw, "the factory refuses a short token before any server exists");
  threw = false;
  try { createBridgeServer({ token: `${TOKEN} with space` }); } catch { threw = true; }
  ok(threw, "the factory refuses a token containing whitespace");

  ok(parseBridgePort(undefined) === BRIDGE_DEFAULT_PORT, `the port defaults to ${BRIDGE_DEFAULT_PORT}`);
  ok(parseBridgePort("8080") === 8080, "a valid port is accepted");
  for (const bad of ["0", "65536", "abc", "-1", "12.5", "1e3"]) {
    let rejected = false;
    try { parseBridgePort(bad); } catch { rejected = true; }
    ok(rejected, `port ${bad} is rejected before listening`);
  }

  const cfgShort = await captureStdio(() => serveMain({ ONLYFANS_BRIDGE_TOKEN: "short" }));
  ok(cfgShort.result === 1 && /configuration error/.test(cfgShort.out), "the entry point exits 1 on a bad token");
  ok(!cfgShort.out.includes(TOKEN), "the entry-point log contains no token value");
  const cfgPort = await captureStdio(() => serveMain({ ONLYFANS_BRIDGE_TOKEN: TOKEN, ONLYFANS_BRIDGE_PORT: "abc" }));
  ok(cfgPort.result === 1 && /configuration error/.test(cfgPort.out), "the entry point exits 1 on a bad port");
  ok(!cfgPort.out.includes(TOKEN), "and logs no token");

  // authentication against a stubbed service: no storage, no model, so any call is provable
  const stub = countingOperations();
  const authBridge = await startServer({ operations: stub.operations, recover: () => undefined });
  const health = await call(authBridge.port, "GET", BRIDGE_ROUTES.health);
  ok(health.status === 200 && health.json?.ok === true && health.json?.result?.status === "ok", `an authenticated health check succeeds (${health.status})`);
  ok(health.json?.schemaVersion === BRIDGE_API_VERSION && health.json?.result?.apiVersion === BRIDGE_API_VERSION, "the envelope and health carry the wire schema version");
  ok(!("account" in (health.json?.result ?? {})) && !("dataDir" in (health.json?.result ?? {})), "health exposes no account or filesystem detail");
  ok(health.headers["access-control-allow-origin"] === undefined, "no public CORS header is sent");
  ok(String(health.headers["cache-control"] ?? "").includes("no-store"), "responses are marked no-store");

  const badAuth: Array<[string, CallOptions]> = [
    ["missing header", { token: null }],
    ["wrong token", { token: "x".repeat(36) }],
    ["malformed scheme", { token: null, headers: { authorization: `Basic ${TOKEN}` } }],
    ["scheme without a value", { token: null, headers: { authorization: "Bearer" } }],
    ["extra text after the token", { token: null, headers: { authorization: `Bearer ${TOKEN} extra` } }],
    ["two tokens in one header", { token: null, headers: { authorization: `Bearer ${TOKEN}, Bearer ${TOKEN}` } }],
  ];
  for (const [label, opts] of badAuth) {
    const before = stub.calls.length;
    const r = await call(authBridge.port, "GET", BRIDGE_ROUTES.health, opts);
    ok(r.status === 401 && r.json?.error?.code === "unauthorized", `${label} -> 401 (${r.status})`);
    ok(r.json?.error?.retryable === false, `${label} is not marked retryable`);
    ok(stub.calls.length === before, `${label} never reaches the service`);
  }
  const cookieOnly = await call(authBridge.port, "GET", BRIDGE_ROUTES.health, { token: null, headers: { cookie: `token=${TOKEN}` } });
  ok(cookieOnly.status === 401, "a cookie token is not accepted");
  const queryToken = await call(authBridge.port, "GET", `${BRIDGE_ROUTES.health}?token=${TOKEN}`, { token: null });
  ok(queryToken.status === 401, "a query-string token is not accepted");
  const duplicate = await rawCall(
    authBridge.port,
    `GET ${BRIDGE_ROUTES.health} HTTP/1.1\r\nHost: ${BRIDGE_BIND_HOST}\r\nAuthorization: Bearer ${TOKEN}\r\nAuthorization: Bearer ${TOKEN}\r\nConnection: close\r\n\r\n`,
  );
  ok(statusOf(duplicate) === 401, `a repeated authorization header -> 401 (${statusOf(duplicate)})`);
  const unauthUnknown = await call(authBridge.port, "GET", "/nope", { token: null });
  ok(unauthUnknown.status === 401, "an unauthenticated unknown path is 401, not 404");
  ok(!health.text.includes(TOKEN) && !unauthUnknown.text.includes(TOKEN) && !duplicate.includes(TOKEN), "no response echoes the token");
  ok(stub.calls.length === 0, "no unauthenticated request reached the service");

  // --- 2. bodies, encodings, routes and methods -----------------------------------------------
  const main = await startServer({ bodyTimeoutMs: 400, headerTimeoutMs: 2_000, responseDeadlineMs: 8_000, maxConcurrentReplies: 4, shutdownGraceMs: 500 });
  const repliesKey = conversationKey(event());
  const beforeBodies = modelCalls;

  let r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: "{not json" });
  ok(r.status === 400 && r.json?.error?.code === "invalid-json", `invalid JSON -> 400 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: Buffer.from([0x7b, 0x22, 0xff, 0xfe, 0x22, 0x7d]) });
  ok(r.status === 400 && r.json?.error?.code === "invalid-utf8", `invalid UTF-8 -> 400 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: "{}", contentType: "text/plain" });
  ok(r.status === 415 && r.json?.error?.code === "unsupported-media-type", `text/plain -> 415 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: "{}", omitContentType: true });
  ok(r.status === 415, "a missing content type -> 415");
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: "{}", contentEncoding: "gzip" });
  ok(r.status === 415 && r.json?.error?.code === "unsupported-encoding", `gzip -> 415 (${r.status}/${r.json?.error?.code})`);
  const oversized = JSON.stringify({ ...event(), pad: "x".repeat(BRIDGE_LIMITS.maxBodyBytes) });
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: oversized });
  ok(r.status === 413 && r.json?.error?.code === "oversized-body", `an oversized declared body -> 413 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: oversized, chunked: true });
  ok(r.status === 413 && r.json?.error?.code === "oversized-body", `an oversized chunked body -> 413 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "POST", BRIDGE_ROUTES.replies, { body: JSON.stringify(event()), partialBody: true });
  ok(r.status === 408 && r.json?.error?.code === "request-timeout", `a stalled body -> 408 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "GET", "/v1/onlyfans/nope");
  ok(r.status === 404 && r.json?.error?.code === "not-found", `an unknown route -> 404 (${r.status}/${r.json?.error?.code})`);
  r = await call(main.port, "GET", BRIDGE_ROUTES.replies);
  ok(r.status === 405 && r.headers.allow === "POST" && r.json?.error?.code === "method-not-allowed", `GET on replies -> 405 with Allow: POST (${r.status}/${r.headers.allow})`);
  r = await post(main.port, BRIDGE_ROUTES.health, {});
  ok(r.status === 405 && r.headers.allow === "GET", `POST on health -> 405 with Allow: GET (${r.status}/${r.headers.allow})`);
  ok(modelCalls === beforeBodies, `no rejected body or route reached the model (${modelCalls - beforeBodies})`);
  ok(stateFilesFor(repliesKey).length === 0, "no rejected request was admitted to the journal");

  // --- 3. generating a draft, duplicates and status -------------------------------------------
  reply = "http draft one";
  const beforeGen = modelCalls;
  let gen = await post(main.port, BRIDGE_ROUTES.replies, event());
  ok(gen.status === 200 && gen.json?.ok === true, `a valid event returns 200 (${gen.status})`);
  const firstResult = gen.json?.result ?? {};
  ok(firstResult.status === "completed" && firstResult.deliverable === true, `the draft is ready to deliver (${firstResult.status}/${firstResult.deliverable})`);
  ok(firstResult.text === "http draft one", `the draft text is returned when deliverable (${JSON.stringify(firstResult.text)})`);
  ok(typeof firstResult.requestId === "string" && typeof firstResult.conversationKey === "string", "the response carries the request and conversation keys");
  ok(firstResult.epoch === 0 && typeof firstResult.createdAt === "string", "the response carries the revision and timestamps");
  ok(firstResult.usage?.provider === "stub", "the response carries usage metadata");
  ok(!("note" in firstResult) && !("failure" in firstResult), "internal notes and stored failure strings are not returned");
  ok(modelCalls - beforeGen === 1, `one accepted event makes one model call (${modelCalls - beforeGen})`);
  ok(readState(repliesKey).transcript.filter((m) => m.role === "assistant").length === 0, "generation alone does not acknowledge delivery");
  ok(readState(repliesKey).requests[firstResult.requestId].status === "completed", "the durable record is completed, not delivered");

  const beforeDup = modelCalls;
  gen = await post(main.port, BRIDGE_ROUTES.replies, event());
  ok(gen.status === 200 && gen.json?.result?.requestId === firstResult.requestId && gen.json?.result?.text === "http draft one", "a repeated request returns the saved draft");
  ok(modelCalls === beforeDup, "a repeated request makes no model call");

  reply = "http draft two";
  const beforeConcurrent = modelCalls;
  const [c1, c2] = await Promise.all([
    post(main.port, BRIDGE_ROUTES.replies, event({ messageId: "http-msg-2" })),
    post(main.port, BRIDGE_ROUTES.replies, event({ messageId: "http-msg-2" })),
  ]);
  ok(c1.status === 200 && c2.status === 200 && c1.json?.result?.requestId === c2.json?.result?.requestId, "concurrent duplicates agree on the request");
  ok(c1.json?.result?.text === "http draft two" && c2.json?.result?.text === "http draft two", "both concurrent callers get the draft");
  ok(modelCalls - beforeConcurrent === 1, `concurrent duplicates make one model call (${modelCalls - beforeConcurrent})`);

  const beforeStatus = modelCalls;
  const statusResp = await post(main.port, BRIDGE_ROUTES.status, event());
  ok(statusResp.status === 200 && statusResp.json?.result?.requestId === firstResult.requestId, `status returns the request state (${statusResp.status})`);
  ok(statusResp.json?.result?.text === "http draft one" && statusResp.json?.result?.deliverable === true, "status returns the deliverable draft");
  ok(modelCalls === beforeStatus, "status makes no model call");
  const unknownStatus = await post(main.port, BRIDGE_ROUTES.status, event({ messageId: "http-msg-unknown" }));
  ok(unknownStatus.status === 404 && unknownStatus.json?.error?.code === "not-found", `status for an unknown request -> 404 (${unknownStatus.status})`);
  ok(readState(repliesKey).requests[messageKey(event({ messageId: "http-msg-unknown" }))] === undefined, "status never creates an unknown request");
  ok(modelCalls === beforeStatus, "an unknown status read makes no model call");

  // --- 4. acknowledgement, cancellation, reset and identity checks ----------------------------
  const ackResp = await post(main.port, BRIDGE_ROUTES.ack, event());
  ok(ackResp.status === 200 && ackResp.json?.result?.status === "delivered", `acknowledgement -> delivered (${ackResp.status}/${ackResp.json?.result?.status})`);
  ok(readState(repliesKey).transcript.filter((m) => m.role === "assistant").length === 1, "the acknowledged reply enters the transcript once");
  const ackAgain = await post(main.port, BRIDGE_ROUTES.ack, event());
  ok(ackAgain.status === 200 && ackAgain.json?.result?.status === "already-delivered", "a repeated acknowledgement is idempotent");
  ok(readState(repliesKey).transcript.filter((m) => m.role === "assistant").length === 1, "and adds no duplicate transcript entry");
  const ackUnknown = await post(main.port, BRIDGE_ROUTES.ack, event({ messageId: "http-msg-unknown" }));
  ok(ackUnknown.status === 404 && ackUnknown.json?.error?.code === "not-found", `acknowledging an unknown request -> 404 (${ackUnknown.status})`);
  const cancelDelivered = await post(main.port, BRIDGE_ROUTES.cancel, event());
  ok(cancelDelivered.status === 409 && cancelDelivered.json?.error?.code === "cancel-rejected" && cancelDelivered.json?.error?.reason === "already-delivered", `cancelling a delivered reply -> 409 (${cancelDelivered.status}/${cancelDelivered.json?.error?.reason})`);
  const statusAfterAck = await post(main.port, BRIDGE_ROUTES.status, event());
  ok(statusAfterAck.json?.result?.status === "delivered" && statusAfterAck.json?.result?.deliverable === false && statusAfterAck.json?.result?.text === "", "a delivered reply is never offered again");
  ok(typeof statusAfterAck.json?.result?.deliveredAt === "string" && typeof statusAfterAck.json?.result?.committedAt === "string", "delivery evidence is reported");

  holdModel = true;
  reply = "cancelled draft";
  const heldPost = post(main.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-cancel", messageId: "held-1" }));
  await settle();
  const cancelHeld = await post(main.port, BRIDGE_ROUTES.cancel, event({ conversationId: "http-conv-cancel", messageId: "held-1" }));
  ok(cancelHeld.status === 200 && cancelHeld.json?.result?.status === "cancelled", `cancelling a running request -> cancelled (${cancelHeld.status}/${cancelHeld.json?.result?.status})`);
  await releaseModelCall();
  const heldDone = await heldPost;
  ok(heldDone.status === 200 && heldDone.json?.result?.status === "cancelled" && heldDone.json?.result?.deliverable === false, "the cancelled request stays cancelled and undeliverable");
  ok(heldDone.json?.result?.text === "", "a cancelled draft returns no text");
  holdModel = false;

  holdModel = true;
  reply = "reset draft";
  const resetPost = post(main.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-reset", messageId: "reset-1" }));
  await settle();
  const resetResp = await post(main.port, BRIDGE_ROUTES.reset, event({ conversationId: "http-conv-reset", messageId: "reset-1" }));
  ok(resetResp.status === 200 && resetResp.json?.result?.epoch === 1 && resetResp.json?.result?.cancelled >= 1, `reset bumps the revision and cancels work (${resetResp.json?.result?.epoch}/${resetResp.json?.result?.cancelled})`);
  await releaseModelCall();
  const resetDone = await resetPost;
  ok(resetDone.json?.result?.status === "cancelled" && resetDone.json?.result?.deliverable === false, "the reset turn ends cancelled");
  holdModel = false;
  reply = "after reset";
  const afterReset = await post(main.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-reset", messageId: "reset-2" }));
  ok(afterReset.status === 200 && afterReset.json?.result?.status === "completed" && afterReset.json?.result?.deliverable === true, `a post-reset input still generates (${afterReset.json?.result?.status})`);

  modelStatus = 500;
  const beforeFail = modelCalls;
  const failed = await post(main.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-fail", messageId: "fail-1" }));
  ok(failed.status === 200 && failed.json?.result?.status === "failed" && failed.json?.result?.deliverable === false, `a model failure -> 200 with status failed (${failed.status}/${failed.json?.result?.status})`);
  ok(failed.json?.result?.text === "", "a failed request returns no text");
  ok(modelCalls - beforeFail === 2, `the existing two-attempt bound still applies (${modelCalls - beforeFail})`);
  modelStatus = 200;

  for (const route of [BRIDGE_ROUTES.replies, BRIDGE_ROUTES.status, BRIDGE_ROUTES.ack, BRIDGE_ROUTES.cancel, BRIDGE_ROUTES.reset]) {
    const unknownAccount = await post(main.port, route, event({ accountId: "acct-nope" }));
    ok(unknownAccount.status === 403 && unknownAccount.json?.error?.code === "forbidden", `an unknown account on ${route} -> 403 (${unknownAccount.status})`);
    const wrongCreator = await post(main.port, route, event({ creatorSlug: "someone-else" }));
    ok(wrongCreator.status === 403, `a creator mismatch on ${route} -> 403 (${wrongCreator.status})`);
  }
  const badDirection = await post(main.port, BRIDGE_ROUTES.replies, event({ direction: "outbound" }));
  ok(badDirection.status === 400, `an outbound event -> 400 (${badDirection.status})`);
  const badVersion = await post(main.port, BRIDGE_ROUTES.status, event({ schemaVersion: 2 }));
  ok(badVersion.status === 400, `an unsupported version -> 400 (${badVersion.status})`);

  // --- 5. response deadline, client abort and saturation ---------------------------------------
  const tight = await startServer({ responseDeadlineMs: 150, maxConcurrentReplies: 1, bodyTimeoutMs: 1_000, shutdownGraceMs: 500 });
  holdModel = true;
  reply = "slow draft";
  const slowPost = post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-slow", messageId: "slow-1" }));
  await settle();
  const saturated = await post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-sat", messageId: "sat-1" }));
  ok(saturated.status === 429 && saturated.json?.error?.code === "overloaded" && saturated.json?.error?.retryable === true, `a saturated adapter -> 429 overloaded (${saturated.status}/${saturated.json?.error?.code})`);
  ok(stateFilesFor(conversationKey(event({ conversationId: "http-conv-sat" }))).length === 0, "saturation is rejected before admission");
  const saturatedStatus = await post(tight.port, BRIDGE_ROUTES.status, event({ conversationId: "http-conv-slow", messageId: "slow-1" }));
  ok(saturatedStatus.status === 200 && saturatedStatus.json?.result?.status === "in_progress", `status stays available while saturated (${saturatedStatus.status}/${saturatedStatus.json?.result?.status})`);
  const saturatedReset = await post(tight.port, BRIDGE_ROUTES.reset, event({ conversationId: "http-conv-other", messageId: "x" }));
  ok(saturatedReset.status === 200, "reset stays available while saturated");

  const slowResp = await slowPost;
  ok(slowResp.status === 503 && slowResp.json?.error?.code === "deadline-exceeded" && slowResp.json?.error?.retryable === true, `a slow turn hits the response deadline -> 503 (${slowResp.status}/${slowResp.json?.error?.code})`);
  const stillSaturated = await post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-sat2", messageId: "sat-2" }));
  ok(stillSaturated.status === 429, "a deadline does not free the capacity slot");
  await releaseModelCall();
  await settle(6);
  const afterSlow = await post(tight.port, BRIDGE_ROUTES.status, event({ conversationId: "http-conv-slow", messageId: "slow-1" }));
  ok(afterSlow.status === 200 && afterSlow.json?.result?.status === "completed" && afterSlow.json?.result?.deliverable === true, `the abandoned work finished durably (${afterSlow.json?.result?.status})`);
  const reused = await post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-slow", messageId: "slow-1" }));
  ok(reused.status === 200 && reused.json?.result?.requestId === afterSlow.json?.result?.requestId && reused.json?.result?.text === "slow draft", "a duplicate returns the same saved result");
  holdModel = false;
  // Now that the held model can answer, a fresh request must be admitted (not 429) and complete: the
  // slot was released when the abandoned work finished, not when its response deadline fired.
  const slotFreed = await post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-sat3", messageId: "sat-3" }));
  ok(slotFreed.status === 200 && slotFreed.json?.result?.status === "completed", `the slot is released once the work finishes (${slotFreed.status}/${slotFreed.json?.result?.status})`);

  holdModel = true;
  reply = "aborted draft";
  const aborted = await post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-abort", messageId: "abort-1" }), { abortAfterMs: 60 });
  ok(aborted.status === 0 || aborted.status === 200, `an aborted client is tolerated (${aborted.status})`);
  await releaseModelCall();
  await settle(6);
  holdModel = false;
  const abortStatus = await post(tight.port, BRIDGE_ROUTES.status, event({ conversationId: "http-conv-abort", messageId: "abort-1" }));
  ok(abortStatus.status === 200 && abortStatus.json?.result?.status === "completed" && abortStatus.json?.result?.deliverable === true, `work continues after a client disconnect (${abortStatus.json?.result?.status})`);
  const abortDup = await post(tight.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-conv-abort", messageId: "abort-1" }));
  ok(abortDup.json?.result?.requestId === abortStatus.json?.result?.requestId, "and the same identity retrieves the same result");

  // --- 6. startup recovery, redaction and restart ----------------------------------------------
  const homeDataDir = config.dataDir;

  // corrupt durable state prevents readiness
  config.dataDir = path.join(tmp, "corrupt-data");
  const seedBridge = await startServer({});
  reply = "corrupt seed";
  const seeded = await post(seedBridge.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-corrupt", messageId: "c1" }));
  ok(seeded.status === 200, "seeding a conversation for the corruption case succeeds");
  await seedBridge.close();
  const corruptFile = stateFilesFor(conversationKey(event({ conversationId: "http-corrupt" })))[0].file;
  const corruptBytes = fs.readFileSync(corruptFile, "utf8");
  fs.writeFileSync(corruptFile, corruptBytes.replace(/"epoch"/, '"epochX"'));
  let corruptErr: unknown = null;
  try { await startBridgeServer({ token: TOKEN, girl: neutral, port: 0 }); } catch (e) { corruptErr = e; }
  ok(corruptErr instanceof StoreError, "a corrupt snapshot prevents startup before listening");
  fs.writeFileSync(corruptFile, corruptBytes);

  // a legacy version-1 journal prevents readiness, alone and beside new snapshots
  config.dataDir = path.join(tmp, "legacy-data");
  const legacyBridge = await startServer({});
  reply = "legacy seed";
  const legacySeed = await post(legacyBridge.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-legacy", messageId: "l1" }));
  ok(legacySeed.status === 200, "seeding a conversation for the legacy case succeeds");
  await legacyBridge.close();
  const legacyDir = path.join(config.dataDir, CREATOR, "bridge");
  const legacyKey = conversationKey(event({ conversationId: "http-legacy" }));
  fs.writeFileSync(path.join(legacyDir, `${legacyKey}.json`), JSON.stringify({ version: 1, conversationKey: legacyKey, epoch: 0, requests: {} }));
  let mixedErr: unknown = null;
  try { await startBridgeServer({ token: TOKEN, girl: neutral, port: 0 }); } catch (e) { mixedErr = e; }
  ok(mixedErr instanceof StoreError && /migration/.test(String((mixedErr as Error).message)), "a mixed old/new layout refuses to serve (migration required)");

  config.dataDir = path.join(tmp, "legacy-only");
  fs.mkdirSync(path.join(config.dataDir, CREATOR, "bridge"), { recursive: true });
  const legacyOnlyKey = conversationKey(event({ conversationId: "http-legacy-only" }));
  fs.writeFileSync(path.join(config.dataDir, CREATOR, "bridge", `${legacyOnlyKey}.json`), JSON.stringify({ version: 1, conversationKey: legacyOnlyKey, epoch: 0, requests: {} }));
  let legacyOnlyErr: unknown = null;
  try { await startBridgeServer({ token: TOKEN, girl: neutral, port: 0 }); } catch (e) { legacyOnlyErr = e; }
  ok(legacyOnlyErr instanceof StoreError && /migration/.test(String((legacyOnlyErr as Error).message)), "an old-only journal refuses to serve (migration required)");

  // a storage failure during a request is a sanitised 500, and the bytes are untouched
  config.dataDir = homeDataDir;
  reply = "redact seed";
  const redactSeed = await post(main.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-redact", messageId: "r1" }));
  ok(redactSeed.status === 200, "seeding the redaction case succeeds");
  const redactFile = stateFilesFor(conversationKey(event({ conversationId: "http-redact" })))[0].file;
  const redactBytes = fs.readFileSync(redactFile, "utf8");
  fs.writeFileSync(redactFile, "not json at all");
  const redacted = await post(main.port, BRIDGE_ROUTES.status, event({ conversationId: "http-redact", messageId: "r1" }));
  ok(redacted.status === 500 && redacted.json?.error?.code === "storage-unavailable" && redacted.json?.error?.retryable === false, `a storage failure -> sanitised 500 (${redacted.status}/${redacted.json?.error?.code})`);
  ok(!redacted.text.includes(config.dataDir) && !redacted.text.includes(".json") && !redacted.text.includes("StoreError") && !redacted.text.includes("bridge/"), "the 500 body leaks no path or internal error text");
  fs.writeFileSync(redactFile, redactBytes);
  const unredactedAgain = await post(main.port, BRIDGE_ROUTES.status, event({ conversationId: "http-redact", messageId: "r1" }));
  ok(unredactedAgain.status === 200, "the conversation works again once the bytes are restored");

  // restarting the adapter over completed/delivered state does not regenerate or re-offer
  reply = "restart seed";
  const restartSeed = await post(main.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-restart", messageId: "s1" }));
  ok(restartSeed.status === 200, "seeding the restart case succeeds");
  const restartAck = await post(main.port, BRIDGE_ROUTES.ack, event({ conversationId: "http-restart", messageId: "s1" }));
  ok(restartAck.status === 200 && restartAck.json?.result?.status === "delivered", "the restart case is acknowledged");
  const restarted = await startServer({});
  const beforeRestart = modelCalls;
  const restartedStatus = await post(restarted.port, BRIDGE_ROUTES.status, event({ conversationId: "http-restart", messageId: "s1" }));
  ok(restartedStatus.status === 200 && restartedStatus.json?.result?.status === "delivered" && restartedStatus.json?.result?.deliverable === false && restartedStatus.json?.result?.text === "", "a restarted adapter keeps the reply undeliverable");
  const restartedDup = await post(restarted.port, BRIDGE_ROUTES.replies, event({ conversationId: "http-restart", messageId: "s1" }));
  ok(restartedDup.json?.result?.requestId === restartSeed.json?.result?.requestId && restartedDup.json?.result?.text === "", "a restarted adapter does not regenerate a delivered request");
  ok(modelCalls === beforeRestart, "and makes no model call");
} finally {
  for (const bridge of servers) {
    try { await bridge.close(); } catch { /* already closed */ }
  }
  config.girl = savedGirl;
  config.dataDir = savedDataDir;
  config.logDir = savedLogDir;
  globalThis.fetch = realFetch;
  resetAccountBindings();
  fs.rmSync(tmp, { recursive: true, force: true });
}

ok(externalUrls.length > 0 && externalUrls.every((u) => u === OPENROUTER), `only the stubbed model endpoint was called externally (${externalUrls.length})`);

console.log(fail ? `\n${fail} FAILED of ${n}` : `all ${n} http checks passed`);
process.exit(fail ? 1 : 0);
