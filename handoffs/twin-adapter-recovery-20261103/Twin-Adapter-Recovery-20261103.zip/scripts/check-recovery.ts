// Stage 1B part 1 offline checks (repair): durable reply state and recovery.
//
// Neutral fixtures, a stubbed model endpoint that fails any other URL, isolated temporary data/log
// directories and full restore in finally. Nothing is sent: acknowledgement and cancellation are
// explicit calls. Some checks re-run this file in a real child process (--child <mode>) so restart
// semantics are exercised by an actual second process, not by hand-seeded JSON alone.
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { config } from "../src/config.js";
import type { Girl } from "../src/girls/index.js";
import type { GirlVars } from "../src/girls/template.js";
import type { Item } from "../src/media.js";
import { loadChat } from "../src/memory.js";
import type { GenerationResult, TurnTranscript } from "../src/turn.js";
import { runTextTurn } from "../src/channels/text-turn.js";
import { conversationKey, messageKey, resetAccountBindings, setAccountBindings } from "../src/channels/identity.js";
import type { InboundEvent } from "../src/channels/types.js";
import { STORE_VERSION, StoreError, emptyConversationState, listConversationKeys, mutateState, newRequestRecord, readState, setWriteFaultForTest, stateFilesFor, writeState, type ConversationState } from "../src/channels/store.js";
import { acknowledgeDelivery, cancelRequest, recoverInterruptedRequests, requestReply, resetConversation } from "../src/channels/service.js";

let fail = 0, n = 0;
const ok = (cond: boolean, msg: string) => { n++; if (!cond) { fail++; console.log("FAIL " + msg); } };

const CREATOR = "stage1b-neutral";
const OPENROUTER = "https://openrouter.ai/api/v1/chat/completions";
const HERE = fileURLToPath(import.meta.url);

const neutral: Girl = {
  slug: CREATOR,
  name: "Tester",
  cloneId: "00000000-0000-0000-0000-000000000000",
  varsFile: "",
  vars: {} as GirlVars,
  prompt: "You are a neutral test persona. Reply in lowercase. Never offer or send any media.",
  greeting: "hii",
  brb: ["one sec"],
  deflections: ["no thanks, lets talk about something else"],
};

type EventOverrides = Partial<Record<keyof InboundEvent, unknown>>;
const BASE_EVENT = {
  schemaVersion: 1,
  channel: "onlyfans",
  accountId: "acct-a",
  creatorSlug: CREATOR,
  conversationId: "conv-1",
  fanId: "fan-1",
  messageId: "msg-1",
  occurredAt: "2026-10-15T04:00:00.000Z",
  receivedAt: "2026-10-15T04:00:01.000Z",
  direction: "inbound",
  text: "hey there",
} as const;
const event = (over: EventOverrides = {}): InboundEvent => ({ ...BASE_EVENT, ...over }) as InboundEvent;

const settle = async (rounds = 4) => { for (let i = 0; i < rounds; i++) await new Promise<void>((r) => setImmediate(r)); };
const digest = (payload: string) => crypto.createHash("sha256").update(payload, "utf8").digest("hex").slice(0, 32);

function useDirs(base: string): void {
  config.girl = CREATOR;
  config.dataDir = path.join(base, "data");
  config.logDir = path.join(base, "logs");
  setAccountBindings([["acct-a", CREATOR], ["acct-b", CREATOR]]);
}

function modelStub(text: string) {
  return (async (input: unknown) => {
    const url = typeof input === "string" ? input : String((input as { url?: string })?.url ?? input);
    if (url !== OPENROUTER) throw new Error(`unexpected network call: ${url}`);
    return new Response(JSON.stringify({ provider: "stub", choices: [{ message: { content: text }, finish_reason: "stop" }], usage: {} }), { status: 200 });
  }) as typeof fetch;
}

// ---------------------------------------------------------------- child-process modes
if (process.argv[2] === "--child") {
  const mode = process.argv[3];
  useDirs(process.argv[4]);

  if (mode === "legacy-startup") {
    let networkCalled = false;
    globalThis.fetch = (async () => { networkCalled = true; throw new Error("unexpected network call"); }) as typeof fetch;
    try {
      await requestReply(event({ conversationId: "child-legacy", messageId: "m1" }), { girl: neutral });
    } catch (e) {
      if (e instanceof StoreError && /migration required/.test(e.message) && !networkCalled) process.exit(0);
    }
    process.exit(2);
  }

  if (mode === "interrupt") {
    // The model call never returns, so the process exits with the claim committed, as a crash would.
    globalThis.fetch = (async () => new Promise(() => {})) as typeof fetch;
    void requestReply(event({ conversationId: "child-interrupt", messageId: "m1", text: "child input" }), { girl: neutral });
    await settle(6);
    process.exit(0);
  }
  if (mode === "queue-abandon") {
    // Admission commits, the generation start fails: a queued record is left by a dead process.
    setWriteFaultForTest((_file, label) => { if (label === "start") throw new Error("injected start failure"); });
    try {
      await requestReply(event({ conversationId: "child-queue", messageId: "m1", text: "queued child input" }), { girl: neutral });
    } catch {
      /* expected */
    }
    setWriteFaultForTest(null);
    process.exit(0);
  }
  if (mode === "ack-partial" || mode === "deliver") {
    globalThis.fetch = modelStub("child draft");
    await requestReply(event({ conversationId: "child-ack", messageId: "m1", text: "child input" }), { girl: neutral });
    if (mode === "ack-partial") {
      // The delivery decision commits, the transcript commit fails, then the process exits.
      setWriteFaultForTest((_file, label) => { if (label === "ack-commit") throw new Error("injected commit failure"); });
      try {
        await acknowledgeDelivery(event({ conversationId: "child-ack", messageId: "m1" }));
      } catch {
        /* expected */
      }
      setWriteFaultForTest(null);
    } else {
      await acknowledgeDelivery(event({ conversationId: "child-ack", messageId: "m1" }));
    }
    process.exit(0);
  }
  console.error(`unknown child mode ${String(mode)}`);
  process.exit(2);
}

// ---------------------------------------------------------------- parent
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "check-recovery-"));
const childDirs = fs.mkdtempSync(path.join(os.tmpdir(), "check-recovery-child-"));
const savedGirl = config.girl;
const savedDataDir = config.dataDir;
const savedLogDir = config.logDir;
const realFetch = globalThis.fetch;

let reply = "";
let modelStatus = 200;
let modelCalls = 0;
let modelUsage: Record<string, unknown> = {};
let modelProvider: unknown = "stub";
let holdModel = false;
let releaseModel: (() => void) | null = null;
const allUrls: string[] = [];

globalThis.fetch = (async (input: unknown) => {
  const url = typeof input === "string" ? input : String((input as { url?: string })?.url ?? input);
  allUrls.push(url);
  if (url !== OPENROUTER) throw new Error(`unexpected network call in check-recovery: ${url}`);
  modelCalls++;
  if (holdModel) await new Promise<void>((resolve) => { releaseModel = resolve; });
  if (modelStatus !== 200) return new Response("{}", { status: modelStatus });
  return new Response(JSON.stringify({ provider: modelProvider, choices: [{ message: { content: reply }, finish_reason: "stop" }], usage: modelUsage }), { status: 200 });
}) as typeof fetch;

const releaseModelCall = async () => { const r = releaseModel; releaseModel = null; r?.(); await settle(); };
const newestFile = (key: string) => stateFilesFor(key)[0].file;
const assistantTexts = (key: string) => readState(key).transcript.filter((m) => m.role === "assistant").map((m) => m.content);
const userTexts = (key: string) => readState(key).transcript.filter((m) => m.role === "user").map((m) => m.content);

/** Write a complete snapshot by hand, as another process would have left it. */
function writeRawState(key: string, state: ConversationState): void {
  const dir = path.join(config.dataDir, config.girl, "bridge");
  fs.mkdirSync(dir, { recursive: true });
  const seq = (stateFilesFor(key)[0]?.seq ?? 0) + 1;
  const payload = JSON.stringify(state, null, 2);
  fs.writeFileSync(path.join(dir, `${key}.${seq}.json`), `${seq}\n${digest(payload)}\n${payload}`);
}

/** Rewrite the newest snapshot in place with a valid checksum, so the schema validator rejects it. */
function tamperNewest(key: string, mutate: (state: any) => void): void {
  const file = newestFile(key);
  const raw = fs.readFileSync(file, "utf8");
  const first = raw.indexOf("\n");
  const second = raw.indexOf("\n", first + 1);
  const state = JSON.parse(raw.slice(second + 1));
  mutate(state);
  const payload = JSON.stringify(state, null, 2);
  fs.writeFileSync(file, `${raw.slice(0, first)}\n${digest(payload)}\n${payload}`);
}

function faultOn(...labels: string[]): () => void {
  setWriteFaultForTest((_file, label) => {
    if (!labels.length || labels.includes(label)) throw new Error(`injected write failure (${label})`);
  });
  return () => setWriteFaultForTest(null);
}

const storeErrorOf = async (fn: () => unknown): Promise<string | null> => {
  try { await fn(); return null; } catch (e) { return e instanceof StoreError ? e.message : `unexpected:${String(e)}`; }
};

function runChild(mode: string): { status: number; stderr: string } {
  const r = spawnSync(process.execPath, ["--import", "tsx", HERE, "--child", mode, childDirs], { cwd: process.cwd(), encoding: "utf8" });
  return { status: r.status ?? -1, stderr: String(r.stderr ?? "") };
}

/** Version 1 used this unsuffixed file and kept history in a separate legacy memory file. */
function writeLegacyJournal(e: InboundEvent): { file: string; bytes: string } {
  const key = conversationKey(e), id = messageKey(e), at = "2026-10-15T04:00:02.000Z";
  const bytes = JSON.stringify({ version: 1, conversationKey: key, inProgress: null, requests: {
    [id]: { version: 1, requestId: id, conversationKey: key, accountId: e.accountId, fanId: e.fanId,
      messageId: e.messageId, epoch: 0, status: "delivered", outcome: "ok", text: "previously delivered",
      note: "ok", failure: null, provider: "stub", tokensIn: 0, tokensOut: 0, cost: 0, ms: 0, attempts: 0,
      createdAt: at, completedAt: at, deliveredAt: at },
  } });
  const dir = path.join(config.dataDir, config.girl, "bridge");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${key}.json`);
  fs.writeFileSync(file, bytes);
  return { file, bytes };
}

/** A gated generator for checks that need a turn held mid-flight. */
const gates: Array<() => void> = [];
let inFlight = 0;
let maxInFlight = 0;
const gatedGenerate = async (_girl: Girl, _catalogue: Item[], chatId: number | string, text: string, transcript: TurnTranscript): Promise<GenerationResult> => {
  inFlight++;
  maxInFlight = Math.max(maxInFlight, inFlight);
  await new Promise<void>((resolve) => gates.push(resolve));
  inFlight--;
  const chat = transcript.load(chatId);
  transcript.commit(chatId, { ...chat, history: [...chat.history, { role: "user", content: text }] }, `reply:${text}`);
  return { result: { bubbles: [`reply:${text}`], media: null, free: false, note: "ok", provider: "stub", tokensIn: 0, tokensOut: 0, cost: 0, ms: 0 }, pending: { chatId, epoch: chat.epoch, text: `reply:${text}` } };
};
const releaseNextGate = async () => { const g = gates.shift(); if (g) g(); await settle(); };

try {
  useDirs(tmp);

  // --- 0. Telegram behaviour unchanged --------------------------------------------------------
  reply = "eager reply";
  const tgKey = conversationKey(event({ conversationId: "c-tg", messageId: "tg-1" }));
  const tg = await runTextTurn(event({ conversationId: "c-tg", messageId: "tg-1" }), { girl: neutral });
  ok(tg.outcome === "ok" && tg.text === "eager reply", `the Stage 1A primitive still works (${tg.outcome}/${tg.note})`);
  ok(loadChat(tgKey).history.length === 2 && loadChat(tgKey).history[1].role === "assistant", "runTurn still commits her reply eagerly for Telegram");

  // --- 1. storage design: append-only generations, newest authoritative -----------------------
  reply = "first draft";
  const s1 = await requestReply(event({ conversationId: "c1", messageId: "m1" }), { girl: neutral });
  const k1 = s1.conversationKey;
  const filesAfterAdmit = stateFilesFor(k1).length;
  ok(filesAfterAdmit >= 2, `each mutation commits a new generation file (${filesAfterAdmit})`);
  ok(filesAfterAdmit <= 2, "older generations are pruned, keeping the newest two");
  ok(stateFilesFor(k1).every((f) => !f.file.endsWith(".tmp")), "no temporary files are left behind");
  const survivorFile = newestFile(k1);
  const survivorBytes = fs.readFileSync(survivorFile, "utf8");
  await cancelRequest(event({ conversationId: "c1", messageId: "m1" })); // exactly one new generation
  ok(newestFile(k1) !== survivorFile, "a mutation writes a new file rather than reusing the committed one");
  ok(fs.existsSync(survivorFile) && fs.readFileSync(survivorFile, "utf8") === survivorBytes, "the committed snapshot is never modified in place");
  ok(readState(k1).lastMutation === "cancel", `the snapshot records the write that produced it (${readState(k1).lastMutation})`);
  reply = "second draft";
  const s2 = await requestReply(event({ conversationId: "c1", messageId: "m2", text: "another" }), { girl: neutral });
  ok(s2.status === "completed", "a second request also completes");
  ok(stateFilesFor(k1).length <= 2, "generation count stays bounded");
  ok(s1.requestId !== s2.requestId, "the two messages are distinct requests");
  ok(readState(k1).requests[s1.requestId].status === "cancelled" && readState(k1).requests[s2.requestId].status === "completed", "both requests are recorded in the journal");

  // --- 2. finding 3/4: write failures at every boundary preserve the committed state ----------
  for (const label of ["admit", "start", "finalise", "transcript", "reset", "ack-decision"]) {
    const conv = `c-w-${label}`;
    const wKey = conversationKey(event({ conversationId: conv, messageId: "m1" }));
    reply = `survivor ${label}`;
    const w1 = await requestReply(event({ conversationId: conv, messageId: "m1" }), { girl: neutral });
    const bytesBefore = fs.readFileSync(newestFile(wKey), "utf8");
    const filesBefore = stateFilesFor(wKey).length;
    const callsBefore = modelCalls;
    const clear = faultOn(label);
    let msg: string | null = null;
    try {
      if (label === "reset") msg = await storeErrorOf(() => resetConversation(event({ conversationId: conv, messageId: "m1" })));
      else if (label === "ack-decision") msg = await storeErrorOf(() => acknowledgeDelivery(event({ conversationId: conv, messageId: "m1" })));
      else msg = await storeErrorOf(() => requestReply(event({ conversationId: conv, messageId: "m2", text: "x" }), { girl: neutral }));
    } finally {
      clear();
    }
    ok(!!msg && msg.includes(label), `a failed ${label} write is reported (${msg})`);
    ok(readState(wKey).requests[w1.requestId].status === "completed", `the committed record survives a failed ${label} write`);
    ok(readState(wKey).epoch === 0, `the revision survives a failed ${label} write`);
    ok(readState(wKey).requests[w1.requestId].deliveredAt === null, `no delivery decision is recorded by a failed ${label} write`);
    if (label === "admit" || label === "reset" || label === "ack-decision") {
      ok(fs.existsSync(newestFile(wKey)) && fs.readFileSync(newestFile(wKey), "utf8") === bytesBefore, `the committed snapshot is byte-identical after a failed ${label} write`);
      ok(stateFilesFor(wKey).length === filesBefore, `no extra generation file is left by a failed ${label} write`);
    }
    if (label === "ack-decision") ok(modelCalls === callsBefore, "no model call during the failed acknowledgement");
  }
  const okKey = conversationKey(event({ conversationId: "c-w-ack-decision", messageId: "m1" }));
  ok((await acknowledgeDelivery(event({ conversationId: "c-w-ack-decision", messageId: "m1" }))).status === "delivered", "the same conversation can be acknowledged once writes work again");
  ok(assistantTexts(okKey).length === 1, "and the reply is committed exactly once");

  // a partial write of the newest snapshot (simulated crash) fails closed, previous snapshot intact
  const crashKey = conversationKey(event({ conversationId: "c-crash", messageId: "m1" }));
  reply = "crash draft";
  await requestReply(event({ conversationId: "c-crash", messageId: "m1" }), { girl: neutral });
  const crashCommitted = newestFile(crashKey);
  const crashBytes = fs.readFileSync(crashCommitted, "utf8");
  const nextSeq = stateFilesFor(crashKey)[0].seq + 1;
  const partial = path.join(path.dirname(crashCommitted), `${crashKey}.${nextSeq}.json`);
  fs.writeFileSync(partial, `${nextSeq}\n`);
  const partialErr = await storeErrorOf(() => requestReply(event({ conversationId: "c-crash", messageId: "m2", text: "y" }), { girl: neutral }));
  ok(!!partialErr && /truncated|checksum/.test(partialErr), `an incomplete newest snapshot fails closed (${partialErr})`);
  ok(fs.existsSync(crashCommitted) && fs.readFileSync(crashCommitted, "utf8") === crashBytes, "the previous committed snapshot is untouched by a partial write");
  fs.rmSync(partial, { force: true });
  ok(readState(crashKey).requests[messageKey(event({ conversationId: "c-crash", messageId: "m1" }))].status === "completed", "and the conversation is usable again once the partial file is gone");

  // --- 3. finding 6: structurally invalid snapshots are rejected, bytes kept -------------------
  const tKey = conversationKey(event({ conversationId: "c-tamper", messageId: "m1" }));
  reply = "tamper draft";
  await requestReply(event({ conversationId: "c-tamper", messageId: "m1" }), { girl: neutral });
  const tamperCases: Array<[string, (s: any) => void, string]> = [
    ["requests null", (s) => { s.requests = null; }, "requests"],
    ["requests array", (s) => { s.requests = []; }, "requests"],
    ["bogus status", (s) => { Object.values<any>(s.requests)[0].status = "exploded"; }, "status"],
    ["request id mismatch", (s) => { Object.values<any>(s.requests)[0].requestId = "other"; }, "requestId"],
    ["unknown claim target", (s) => { s.inProgress = { requestId: "nope", runId: "x", startedAt: new Date().toISOString() }; }, "unknown request"],
    ["claim on a completed request", (s) => { const r = Object.values<any>(s.requests)[0]; s.inProgress = { requestId: r.requestId, runId: "x", startedAt: new Date().toISOString() }; }, "which is completed"],
    ["negative epoch", (s) => { s.epoch = -1; }, "epoch"],
    ["unsupported version", (s) => { s.version = STORE_VERSION + 97; }, "version"],
    ["malformed transcript entry", (s) => { s.transcript = [{ role: "system", content: "x" }]; }, "transcript"],
    ["non-numeric cost", (s) => { Object.values<any>(s.requests)[0].cost = "free"; }, "cost"],
    ["wrong conversation key", (s) => { s.conversationKey = `of_${"0".repeat(64)}`; }, "conversation key"],
  ];
  for (const [label, mutate, fragment] of tamperCases) {
    const good = fs.readFileSync(newestFile(tKey), "utf8");
    tamperNewest(tKey, mutate);
    const tampered = fs.readFileSync(newestFile(tKey), "utf8");
    const callsBefore = modelCalls;
    const err = await storeErrorOf(() => requestReply(event({ conversationId: "c-tamper", messageId: "m1" }), { girl: neutral }));
    ok(!!err && err.includes(fragment), `${label} is rejected (${err})`);
    ok(modelCalls === callsBefore, `${label} is rejected before any model call`);
    ok(fs.readFileSync(newestFile(tKey), "utf8") === tampered, `${label} leaves the damaged bytes intact`);
    fs.writeFileSync(newestFile(tKey), good);
  }
  const missingKey = `of_${"f".repeat(64)}`;
  ok(readState(missingKey).epoch === 0 && readState(missingKey).transcript.length === 0, "a conversation with no file is a new conversation");
  ok(stateFilesFor(tKey).length > 0, "and a conversation with files is not treated as missing");

  // --- 4. finding 1: a persisted delivery decision is authoritative ---------------------------
  reply = "decided draft";
  const f1Key = conversationKey(event({ conversationId: "c-f1", messageId: "m1" }));
  const f1 = await requestReply(event({ conversationId: "c-f1", messageId: "m1" }), { girl: neutral });
  const callsBeforeF1 = modelCalls;
  const clearF1 = faultOn("ack-commit");
  let f1Err: string | null = null;
  try { await acknowledgeDelivery(event({ conversationId: "c-f1", messageId: "m1" })); } catch (e) { f1Err = String((e as Error)?.message ?? e); }
  clearF1();
  ok(!!f1Err && f1Err.includes("ack-commit"), `the failed transcript commit is reported (${f1Err})`);
  const f1Rec = readState(f1Key).requests[f1.requestId];
  ok(f1Rec.status === "delivered" && f1Rec.deliveredAt !== null && f1Rec.committedAt === null, "the persisted delivery decision survives the failed commit");
  const f1Dup = await requestReply(event({ conversationId: "c-f1", messageId: "m1" }), { girl: neutral });
  ok(f1Dup.status === "delivered" && f1Dup.deliverable === false && f1Dup.text === "", "an acknowledged reply is never offered for sending again");
  ok(modelCalls === callsBeforeF1, "and no second model call happens");
  ok(assistantTexts(f1Key).length === 1 && assistantTexts(f1Key)[0] === "decided draft", "reconcile finished the commit exactly once");
  ok((await acknowledgeDelivery(event({ conversationId: "c-f1", messageId: "m1" }))).status === "already-delivered", "a later acknowledgement is idempotent");
  ok(assistantTexts(f1Key).length === 1, "and adds no duplicate transcript entry");
  ok((await cancelRequest(event({ conversationId: "c-f1", messageId: "m1" }))).status === "already-delivered", "confirmed delivery cannot be cancelled away");
  const f1Reset = await resetConversation(event({ conversationId: "c-f1", messageId: "m1" }));
  ok(f1Reset.epoch === 1 && readState(f1Key).transcript.length === 0, "a reset clears the transcript");
  const f1AfterReset = readState(f1Key).requests[f1.requestId];
  ok(f1AfterReset.deliveredAt !== null && f1AfterReset.committedAt !== null, "and keeps the confirmed-delivery evidence");
  ok((await requestReply(event({ conversationId: "c-f1", messageId: "m1" }), { girl: neutral })).deliverable === false, "a reset can never make a delivered reply deliverable again");

  // --- 5. finding 2: queued requests participate in cancel, reset and duplicates --------------
  holdModel = true;
  const q1Key = conversationKey(event({ conversationId: "c-q1", messageId: "a1" }));
  const callsBeforeQ1 = modelCalls;
  reply = "A reply";
  const pA = requestReply(event({ conversationId: "c-q1", messageId: "a1", text: "from A" }), { girl: neutral });
  await settle();
  const pB = requestReply(event({ conversationId: "c-q1", messageId: "b1", text: "from B" }), { girl: neutral });
  await settle();
  const bRec = readState(q1Key).requests[messageKey(event({ conversationId: "c-q1", messageId: "b1" }))];
  ok(bRec?.status === "queued", `a waiting request is persisted as queued (${bRec?.status})`);
  ok(userTexts(q1Key).length === 0, "a held generation has not committed the transcript yet");
  ok((await cancelRequest(event({ conversationId: "c-q1", messageId: "b1" }))).status === "cancelled", "a queued request can be cancelled");
  await releaseModelCall();
  const aDone = await pA;
  const bDone = await pB;
  ok(aDone.status === "completed" && aDone.deliverable, `the running request still completes (${aDone.status})`);
  ok(bDone.status === "cancelled" && bDone.deliverable === false && bDone.text === "", "the cancelled queued request never becomes deliverable");
  ok(modelCalls - callsBeforeQ1 === 1, `the queued request never invoked the model (${modelCalls - callsBeforeQ1} calls)`);
  ok(userTexts(q1Key).length === 1 && userTexts(q1Key)[0] === "from A", "only the running request's message reaches the transcript");
  holdModel = false;

  holdModel = true;
  const q2Key = conversationKey(event({ conversationId: "c-q2", messageId: "a1" }));
  const callsBeforeQ2 = modelCalls;
  const qA = requestReply(event({ conversationId: "c-q2", messageId: "a1", text: "pre reset A" }), { girl: neutral });
  await settle();
  const qB = requestReply(event({ conversationId: "c-q2", messageId: "b1", text: "pre reset B" }), { girl: neutral });
  await settle();
  const reset2 = await resetConversation(event({ conversationId: "c-q2", messageId: "a1" }));
  ok(reset2.epoch === 1 && reset2.cancelled === 2, `reset cancels running and queued work (epoch ${reset2.epoch}, cancelled ${reset2.cancelled})`);
  await releaseModelCall();
  const qADone = await qA;
  const qBDone = await qB;
  ok(qADone.status === "cancelled" && qADone.deliverable === false, "the running turn is cancelled by the reset");
  ok(qBDone.status === "cancelled" && qBDone.deliverable === false, "the queued turn is cancelled by the reset");
  ok(readState(q2Key).transcript.length === 0, "the reset left the transcript empty");
  holdModel = false;
  reply = "after reset";
  const afterReset = await requestReply(event({ conversationId: "c-q2", messageId: "c1", text: "post reset" }), { girl: neutral });
  ok(afterReset.status === "completed" && afterReset.deliverable && afterReset.text === "after reset", `a new post-reset input still works (${afterReset.status})`);
  ok(modelCalls - callsBeforeQ2 === 2, `only the two real turns reached the model (${modelCalls - callsBeforeQ2})`);
  holdModel = false;

  maxInFlight = 0;
  const q3Key = conversationKey(event({ conversationId: "c-q3", messageId: "a1" }));
  const callsBeforeQ3 = modelCalls;
  reply = "queued duplicate";
  const [qd1, qd2] = await Promise.all([
    requestReply(event({ conversationId: "c-q3", messageId: "a1", text: "same" }), { girl: neutral }),
    requestReply(event({ conversationId: "c-q3", messageId: "a1", text: "same" }), { girl: neutral }),
  ]);
  ok(modelCalls - callsBeforeQ3 === 1, `a concurrent duplicate generates once (${modelCalls - callsBeforeQ3})`);
  ok(qd1.requestId === qd2.requestId && qd1.text === "queued duplicate" && qd2.text === "queued duplicate", "both callers get the same saved reply");
  ok(userTexts(q3Key).length === 1, "and the transcript holds the fan message once");

  // --- 6. finding 5: commit identity, not reply text ------------------------------------------
  reply = "same neutral reply";
  const f5Key = conversationKey(event({ conversationId: "c-f5", messageId: "m1" }));
  const f5a = await requestReply(event({ conversationId: "c-f5", messageId: "m1", text: "first" }), { girl: neutral });
  const f5b = await requestReply(event({ conversationId: "c-f5", messageId: "m2", text: "second" }), { girl: neutral });
  ok(f5a.text === f5b.text && f5a.text === "same neutral reply", "both drafts carry identical text");
  ok(assistantTexts(f5Key).length === 0, "neither is in the transcript before acknowledgement");
  await acknowledgeDelivery(event({ conversationId: "c-f5", messageId: "m1" }));
  await acknowledgeDelivery(event({ conversationId: "c-f5", messageId: "m2" }));
  ok(assistantTexts(f5Key).length === 2, `two distinct deliveries each get a transcript entry (${assistantTexts(f5Key).length})`);
  ok(assistantTexts(f5Key).every((t) => t === "same neutral reply"), "both entries carry the identical text");
  const replay = await acknowledgeDelivery(event({ conversationId: "c-f5", messageId: "m1" }));
  ok(replay.status === "already-delivered" && assistantTexts(f5Key).length === 2, "replaying an acknowledgement adds nothing");
  reply = "later";
  await requestReply(event({ conversationId: "c-f5", messageId: "m3", text: "third" }), { girl: neutral });
  ok(assistantTexts(f5Key).length === 2, "a later turn does not duplicate a committed reply");
  for (let i = 0; i < 20; i++) {
    reply = `bulk ${i}`;
    await requestReply(event({ conversationId: "c-f5", messageId: `bulk-${i}`, text: `bulk ${i}` }), { girl: neutral });
  }
  const trimmed = readState(f5Key).transcript.length;
  ok(trimmed <= config.historyLimit, `the transcript stays bounded (${trimmed})`);
  ok(readState(f5Key).requests[f5a.requestId].committedAt !== null, "commit evidence survives trimming");
  const replayAfterTrim = await acknowledgeDelivery(event({ conversationId: "c-f5", messageId: "m1" }));
  ok(replayAfterTrim.status === "already-delivered" && readState(f5Key).transcript.length === trimmed, "replay after trimming adds nothing");

  // --- 7. cancellation and reset basics -------------------------------------------------------
  reply = "draft to cancel";
  const c7Key = conversationKey(event({ conversationId: "c7", messageId: "x1" }));
  await requestReply(event({ conversationId: "c7", messageId: "x1" }), { girl: neutral });
  ok((await cancelRequest(event({ conversationId: "c7", messageId: "x1" }))).status === "cancelled", "cancellation succeeds");
  ok((await acknowledgeDelivery(event({ conversationId: "c7", messageId: "x1" }))).status === "cancelled", "a cancelled draft cannot be acknowledged");
  ok(userTexts(c7Key).length === 1 && assistantTexts(c7Key).length === 0, "cancelling adds nothing to the transcript");
  ok((await cancelRequest(event({ conversationId: "c7", messageId: "x1" }))).status === "already-cancelled", "cancelling twice is idempotent");
  ok((await requestReply(event({ conversationId: "c7", messageId: "x1" }), { girl: neutral })).status === "cancelled", "a cancelled request stays cancelled");
  ok((await cancelRequest(event({ conversationId: "c7", messageId: "nope" }))).status === "not-found", "cancelling an unknown request is explicit");

  // --- 8. interruption, in this process -------------------------------------------------------
  const lostKey = conversationKey(event({ conversationId: "c-lost", messageId: "m1" }));
  const lostId = messageKey(event({ conversationId: "c-lost", messageId: "m1" }));
  const lost = emptyConversationState(lostKey);
  lost.requests[lostId] = {
    ...newRequestRecord({
      requestId: lostId,
      conversationKey: lostKey,
      accountId: "acct-a",
      fanId: "fan-1",
      messageId: "m1",
      runId: "another-process",
      epoch: 0,
      createdAt: "2026-10-15T03:30:00.000Z",
    }),
    status: "in_progress",
    startedAt: "2026-10-15T03:30:01.000Z",
  };
  lost.inProgress = { requestId: lostId, runId: "another-process", startedAt: lost.requests[lostId].startedAt! };
  writeRawState(lostKey, lost);
  const lostReport = recoverInterruptedRequests();
  ok(lostReport.interrupted >= 1, `an abandoned generation is reported interrupted (${lostReport.interrupted})`);
  ok(readState(lostKey).requests[lostId].status === "interrupted", "and the record is explicitly interrupted");
  const callsBeforeLost = modelCalls;
  const lostDup = await requestReply(event({ conversationId: "c-lost", messageId: "m1" }), { girl: neutral });
  ok(lostDup.status === "interrupted" && lostDup.deliverable === false, "a duplicate of an interrupted request is not retried");
  ok(modelCalls === callsBeforeLost, "and makes no model call");
  ok((await acknowledgeDelivery(event({ conversationId: "c-lost", messageId: "m1" }))).status === "interrupted", "an interrupted request cannot be acknowledged");

  // an orphaned in-progress record with no claim is abandoned too
  const orphanKey = conversationKey(event({ conversationId: "c-orphan", messageId: "m1" }));
  const orphanId = messageKey(event({ conversationId: "c-orphan", messageId: "m1" }));
  const orphan = emptyConversationState(orphanKey);
  orphan.requests[orphanId] = {
    ...newRequestRecord({
      requestId: orphanId, conversationKey: orphanKey, accountId: "acct-a", fanId: "fan-1", messageId: "m1",
      runId: "gone-process", epoch: 0, createdAt: "2026-10-15T03:40:00.000Z",
    }),
    status: "in_progress",
    startedAt: "2026-10-15T03:40:01.000Z",
  };
  writeRawState(orphanKey, orphan);
  ok(recoverInterruptedRequests().interrupted >= 1, "an in-progress record with no claim is recovered too");
  ok(readState(orphanKey).requests[orphanId].status === "interrupted", "the orphaned generation is interrupted");

  const liveKey = conversationKey(event({ conversationId: "c-live", messageId: "m1" }));
  const pLive = requestReply(event({ conversationId: "c-live", messageId: "m1", text: "live" }), { girl: neutral, generate: gatedGenerate });
  await settle();
  const liveReport = recoverInterruptedRequests();
  ok(liveReport.interrupted === 0, "recovery leaves a live claim from this process alone");
  ok(readState(liveKey).inProgress !== null, "the live claim survives recovery");
  await releaseNextGate();
  ok((await pLive).status === "completed", "the live request still completes");

  // --- 9. account isolation -------------------------------------------------------------------
  reply = "draft for account a";
  const accA = await requestReply(event({ accountId: "acct-a", conversationId: "shared", fanId: "shared-fan", messageId: "same" }), { girl: neutral });
  reply = "draft for account b";
  const accB = await requestReply(event({ accountId: "acct-b", conversationId: "shared", fanId: "shared-fan", messageId: "same" }), { girl: neutral });
  ok(accA.conversationKey !== accB.conversationKey && accA.requestId !== accB.requestId, "identical ids under two accounts stay separate");
  ok(accA.text === "draft for account a" && accB.text === "draft for account b", "each account keeps its own draft");
  await acknowledgeDelivery(event({ accountId: "acct-a", conversationId: "shared", fanId: "shared-fan", messageId: "same" }));
  ok(assistantTexts(accB.conversationKey).length === 0, "acknowledging one account does not commit in the other");
  ok(assistantTexts(accA.conversationKey).length === 1, "the acknowledged account has its reply");
  ok(stateFilesFor(accA.conversationKey).length > 0 && stateFilesFor(accB.conversationKey).length > 0, "each account has its own journal");

  // --- 10. bounded model failure, no media, no external traffic -------------------------------
  modelStatus = 500;
  const failBefore = modelCalls;
  const failed = await requestReply(event({ conversationId: "c-fail", messageId: "m1" }), { girl: neutral });
  ok(failed.status === "failed" && failed.text === "" && failed.deliverable === false, `a model failure is persisted as failed with no draft (${failed.status})`);
  ok(modelCalls - failBefore === 2, `only the existing two-attempt bound is used (${modelCalls - failBefore})`);
  ok(userTexts(failed.conversationKey).length === 1, "the fan message is still recorded after a failure");
  ok((await acknowledgeDelivery(event({ conversationId: "c-fail", messageId: "m1" }))).status === "not-ready", "a failed request has nothing to acknowledge");
  modelStatus = 200;

  const media: Item = { key: "photo:x", kind: "photo", storagePath: "", words: new Set(), label: "", desc: "", explicitness: "none", stars: 0 };
  const mediaGenerate = async (_girl: Girl, _catalogue: Item[], chatId: number | string, _text: string, transcript: TurnTranscript): Promise<GenerationResult> => {
    const chat = transcript.load(chatId);
    transcript.commit(chatId, chat, null);
    return { result: { bubbles: ["here"], media, free: false, note: "ok+tag", provider: "stub", tokensIn: 0, tokensOut: 0, cost: 0, ms: 0 }, pending: { chatId, epoch: chat.epoch, text: "here" } };
  };
  const unsupported = await requestReply(event({ conversationId: "c-media", messageId: "m1" }), { girl: neutral, generate: mediaGenerate });
  ok(unsupported.status === "failed" && unsupported.outcome === "unsupported" && unsupported.text === "", "a media result is not deliverable in this stage");

  // --- 11. fresh-process restart evidence -----------------------------------------------------
  // Point this process at the child's data directory: a restart means reading what another process
  // committed and recovering it here, with this process's own run id.
  const ownDataDir = config.dataDir;
  config.dataDir = path.join(childDirs, "data");
  const childInterrupt = runChild("interrupt");
  ok(childInterrupt.status === 0, `the interrupt child exited cleanly (${childInterrupt.status}) ${childInterrupt.stderr.slice(0, 200)}`);
  const ciKey = conversationKey(event({ conversationId: "child-interrupt", messageId: "m1" }));
  const ciId = messageKey(event({ conversationId: "child-interrupt", messageId: "m1" }));
  ok(readState(ciKey).requests[ciId]?.status === "in_progress" && readState(ciKey).inProgress !== null, "the child process left a committed in-progress claim on disk");
  ok(userTexts(ciKey).length === 0, "a crashed generation has not committed the transcript yet");
  ok(readState(ciKey).requests[ciId].messageId === "m1", "but the request identity is durable");
  ok(recoverInterruptedRequests().interrupted >= 1, "a fresh process recovers the abandoned generation as interrupted");
  ok(readState(ciKey).requests[ciId].status === "interrupted", "and the record is interrupted");
  const ciCalls = modelCalls;
  ok((await requestReply(event({ conversationId: "child-interrupt", messageId: "m1" }), { girl: neutral })).status === "interrupted", "the interrupted request is not regenerated");
  ok(modelCalls === ciCalls, "and makes no model call");

  const childQueue = runChild("queue-abandon");
  ok(childQueue.status === 0, `the queued child exited cleanly (${childQueue.status}) ${childQueue.stderr.slice(0, 200)}`);
  const cqKey = conversationKey(event({ conversationId: "child-queue", messageId: "m1" }));
  const cqId = messageKey(event({ conversationId: "child-queue", messageId: "m1" }));
  ok(readState(cqKey).requests[cqId]?.status === "queued", "the child left a committed queued request");
  ok(recoverInterruptedRequests().interrupted >= 1, "a fresh process accounts for the abandoned queue");
  ok(readState(cqKey).requests[cqId].status === "interrupted", "the abandoned queued request is interrupted");
  const cqCalls = modelCalls;
  ok((await requestReply(event({ conversationId: "child-queue", messageId: "m1" }), { girl: neutral })).status === "interrupted", "the abandoned queue is not regenerated");
  ok(modelCalls === cqCalls, "and makes no model call");

  const childPartial = runChild("ack-partial");
  ok(childPartial.status === 0, `the partial-ack child exited cleanly (${childPartial.status}) ${childPartial.stderr.slice(0, 200)}`);
  const caKey = conversationKey(event({ conversationId: "child-ack", messageId: "m1" }));
  const caId = messageKey(event({ conversationId: "child-ack", messageId: "m1" }));
  const caRec = readState(caKey).requests[caId];
  ok(caRec.deliveredAt !== null && caRec.committedAt === null, "the child committed the delivery decision but not the transcript commit");
  ok(assistantTexts(caKey).length === 0, "so the reply is not in the transcript yet");
  ok(recoverInterruptedRequests().commitsCompleted >= 1, "a fresh process finishes the outstanding commit");
  ok(assistantTexts(caKey).length === 1 && assistantTexts(caKey)[0] === "child draft", "the reply is committed exactly once");
  const caCalls = modelCalls;
  const caDup = await requestReply(event({ conversationId: "child-ack", messageId: "m1" }), { girl: neutral });
  ok(caDup.status === "delivered" && caDup.deliverable === false && caDup.text === "", "after a restart the acknowledged reply is never offered again");
  ok(modelCalls === caCalls, "and no model call happens");
  ok((await acknowledgeDelivery(event({ conversationId: "child-ack", messageId: "m1" }))).status === "already-delivered", "a later acknowledgement is idempotent");
  ok(assistantTexts(caKey).length === 1, "with no duplicate entry");

  const childDeliver = runChild("deliver");
  ok(childDeliver.status === 0, `the delivery child exited cleanly (${childDeliver.status}) ${childDeliver.stderr.slice(0, 200)}`);
  ok(assistantTexts(caKey).length === 1, "a completed delivery in another process still leaves one entry");
  const cdDup = await requestReply(event({ conversationId: "child-ack", messageId: "m1" }), { girl: neutral });
  ok(cdDup.status === "delivered" && cdDup.deliverable === false, "a restart after delivery keeps it undeliverable");
  config.dataDir = ownDataDir;

  // --- 12. R1: invalid proposed state never becomes an authoritative snapshot -----------------
  for (const [label, usage, provider] of [
    ["string-cost", { cost: "0.01" }, "stub"],
    ["negative-tokens", { prompt_tokens: -1 }, "stub"],
    ["object-cost", { cost: { amount: 1 } }, "stub"],
    ["invalid-provider", {}, { name: "stub" }],
  ] as Array<[string, Record<string, unknown>, unknown]>) {
    const e = event({ conversationId: `metadata-${label}`, messageId: "m1" });
    const key = conversationKey(e), id = messageKey(e), callsBefore = modelCalls;
    modelUsage = usage;
    modelProvider = provider;
    let error: unknown;
    try { await requestReply(e, { girl: neutral }); } catch (e) { error = e; }
    finally { modelUsage = {}; modelProvider = "stub"; }
    ok(error instanceof Error && /invalid .* metadata/.test(error.message), `${label}: invalid provider metadata is a controlled failure`);
    const failedRecord = readState(key).requests[id];
    ok(failedRecord.status === "failed" && failedRecord.text === "" && failedRecord.cost === 0, `${label}: a readable terminal failure replaces the invalid result`);
    ok(modelCalls === callsBefore + 1, `${label}: rejecting metadata does not regenerate the reply`);
    ok((await requestReply(e, { girl: neutral })).deliverable === false && modelCalls === callsBefore + 1, `${label}: a duplicate stays failed without a model call`);
    ok((await acknowledgeDelivery(e)).status === "not-ready", `${label}: the failed result cannot be acknowledged`);
    recoverInterruptedRequests();
    ok(readState(key).requests[id].status === "failed", `${label}: recovery can read the journal`);
    const next = await requestReply({ ...e, messageId: "m2" }, { girl: neutral });
    ok(next.status === "completed" && next.deliverable, `${label}: a later valid input still works`);
  }

  const mutationEvent = event({ conversationId: "invalid-mutation", messageId: "m1" });
  const mutationReply = await requestReply(mutationEvent, { girl: neutral });
  const mutationKey = mutationReply.conversationKey;
  const mutationFile = newestFile(mutationKey), mutationBytes = fs.readFileSync(mutationFile, "utf8");
  const mutationFiles = stateFilesFor(mutationKey).map((f) => f.file).join("|");
  const mutationError = await storeErrorOf(() => mutateState(mutationKey, "invalid-direct-mutation", (s) => {
    s.requests[mutationReply.requestId].cost = "invalid" as unknown as number;
    return { result: "must not be returned", changed: true };
  }));
  ok(!!mutationError && !mutationError.startsWith("unexpected:") && mutationError.includes("cost"), "an invalid mutation raises StoreError before reporting success");
  ok(stateFilesFor(mutationKey).map((f) => f.file).join("|") === mutationFiles, "an invalid mutation creates no new snapshot");
  ok(fs.readFileSync(mutationFile, "utf8") === mutationBytes && readState(mutationKey).requests[mutationReply.requestId].status === "completed", "an invalid mutation leaves the committed state byte-identical and readable");

  // --- 13. R3: checksum-valid contradictions are rejected before acknowledgement or generation -
  await acknowledgeDelivery(mutationEvent);
  const deliveryCases: Array<[string, (s: any) => void]> = [
    ["delivered without evidence", (s) => { const r = s.requests[mutationReply.requestId]; r.deliveredAt = null; r.committedAt = null; }],
    ["committed without delivered", (s) => { s.requests[mutationReply.requestId].deliveredAt = null; }],
    ["completed with delivery evidence", (s) => { s.requests[mutationReply.requestId].status = "completed"; }],
    ["future revision", (s) => { const r = s.requests[mutationReply.requestId]; r.admittedEpoch = r.epoch = s.epoch + 1; }],
    ["admission revision mismatch", (s) => { s.requests[mutationReply.requestId].admittedEpoch++; }],
    ["changed account", (s) => { s.requests[mutationReply.requestId].accountId = "another-account"; }],
    ["changed fan", (s) => { s.requests[mutationReply.requestId].fanId = "another-fan"; }],
    ["changed message", (s) => { s.requests[mutationReply.requestId].messageId = "another-message"; }],
    ["missing completion", (s) => { s.requests[mutationReply.requestId].completedAt = null; }],
    ["invalid result outcome", (s) => { s.requests[mutationReply.requestId].outcome = "failed"; }],
  ];
  for (const [label, corrupt] of deliveryCases) {
    const file = newestFile(mutationKey), good = fs.readFileSync(file, "utf8"), callsBefore = modelCalls;
    const proposed = readState(mutationKey);
    corrupt(proposed);
    const writeError = await storeErrorOf(() => writeState(proposed, "invalid-lifecycle"));
    ok(!!writeError && !writeError.startsWith("unexpected:"), `${label}: rejected before publication`);
    ok(newestFile(mutationKey) === file && fs.readFileSync(file, "utf8") === good, `${label}: proposed write preserves the current snapshot`);
    try {
      tamperNewest(mutationKey, corrupt);
      const damaged = fs.readFileSync(file, "utf8");
      const ackError = await storeErrorOf(() => acknowledgeDelivery(mutationEvent));
      const requestError = await storeErrorOf(() => requestReply(mutationEvent, { girl: neutral }));
      ok(!!ackError && !ackError.startsWith("unexpected:") && !!requestError && !requestError.startsWith("unexpected:"), `${label}: persisted corruption is rejected by acknowledgement and request`);
      ok(modelCalls === callsBefore && newestFile(mutationKey) === file && fs.readFileSync(file, "utf8") === damaged, `${label}: no model call, mutation or duplicate history`);
    } finally { fs.writeFileSync(file, good); }
  }
  ok(assistantTexts(mutationKey).length === 1, "contradictory delivery evidence never appends a second assistant entry");

  // A real running generation supplies a valid claim; corrupt only its ownership/time and restore it.
  const claimEvent = event({ conversationId: "claim-consistency", messageId: "m1" });
  const claimKey = conversationKey(claimEvent);
  holdModel = true;
  const claimTurn = requestReply(claimEvent, { girl: neutral });
  await settle();
  try {
    for (const field of ["runId", "startedAt"] as const) {
      const file = newestFile(claimKey), good = fs.readFileSync(file, "utf8");
      try {
        tamperNewest(claimKey, (s) => { s.inProgress[field] = field === "runId" ? "different-owner" : "2020-01-01T00:00:00.000Z"; });
        const damaged = fs.readFileSync(file, "utf8");
        const error = await storeErrorOf(() => readState(claimKey));
        ok(!!error && !error.startsWith("unexpected:") && error.includes("claim contradicts"), `claim ${field} must match its request`);
        ok(fs.readFileSync(file, "utf8") === damaged, `a contradictory claim ${field} leaves evidence intact`);
      } finally { fs.writeFileSync(file, good); }
    }
  } finally { holdModel = false; await releaseModelCall(); }
  ok((await claimTurn).status === "completed", "the restored, consistent running claim still finishes");

  // Reset before reconciliation must retain old confirmed delivery without restoring old history.
  const oldDeliveryEvent = event({ conversationId: "old-delivery-revision", messageId: "m1" });
  const oldDelivery = await requestReply(oldDeliveryEvent, { girl: neutral });
  const clearOldCommit = faultOn("ack-commit");
  try { await acknowledgeDelivery(oldDeliveryEvent); } catch { /* deliberate commit fault */ }
  finally { clearOldCommit(); }
  await resetConversation(oldDeliveryEvent);
  recoverInterruptedRequests();
  const oldState = readState(oldDelivery.conversationKey);
  ok(oldState.epoch === 1 && oldState.requests[oldDelivery.requestId].epoch === 0 && oldState.requests[oldDelivery.requestId].committedAt !== null, "a confirmed delivery on an older revision remains valid and recovers");
  ok(oldState.transcript.length === 0 && (await requestReply(oldDeliveryEvent, { girl: neutral })).deliverable === false, "recovery after reset neither resurrects history nor offers redelivery");

  // --- 14. R2: old-only and mixed-format directories require explicit migration ----------------
  const normalDataDir = config.dataDir;
  try {
    for (const layout of ["old-only", "mixed"]) {
      config.dataDir = path.join(tmp, `legacy-${layout}`);
      const e = event({ conversationId: `legacy-${layout}`, messageId: "m1" }), key = conversationKey(e);
      let proposed = emptyConversationState(key);
      if (layout === "mixed") {
        await requestReply(e, { girl: neutral });
        await acknowledgeDelivery(e);
        proposed = readState(key);
      }
      const legacy = writeLegacyJournal(e), dir = path.dirname(legacy.file), callsBefore = modelCalls;
      const before = fs.readdirSync(dir).sort().map((name) => [name, fs.readFileSync(path.join(dir, name), "utf8")]);
      for (const [operation, fn] of [
        ["read", () => readState(key)],
        ["discovery", () => listConversationKeys()],
        ["recovery", () => recoverInterruptedRequests()],
        ["request", () => requestReply(e, { girl: neutral })],
        ["write", () => writeState(proposed, "must-not-publish")],
      ] as Array<[string, () => unknown]>) {
        const error = await storeErrorOf(fn);
        ok(!!error && !error.startsWith("unexpected:") && error.includes("migration required"), `${layout}: ${operation} refuses the legacy journal explicitly`);
      }
      ok(modelCalls === callsBefore, `${layout}: the old delivered request causes no model call`);
      const after = fs.readdirSync(dir).sort().map((name) => [name, fs.readFileSync(path.join(dir, name), "utf8")]);
      ok(JSON.stringify(after) === JSON.stringify(before), `${layout}: all bytes and filenames are unchanged`);
    }
    config.dataDir = path.join(childDirs, "data");
    const legacy = writeLegacyJournal(event({ conversationId: "child-legacy", messageId: "m1" }));
    const namesBefore = fs.readdirSync(path.dirname(legacy.file)).sort().join("|");
    const childLegacy = runChild("legacy-startup");
    ok(childLegacy.status === 0, `fresh-process startup rejects a legacy journal before model invocation (${childLegacy.status}) ${childLegacy.stderr.slice(0, 200)}`);
    ok(fs.readFileSync(legacy.file, "utf8") === legacy.bytes && fs.readdirSync(path.dirname(legacy.file)).sort().join("|") === namesBefore, "startup preserves the old journal and creates no snapshots");
  } finally { config.dataDir = normalDataDir; }

  // --- 15. no external traffic beyond the stubbed model ---------------------------------------
  ok(allUrls.length > 0 && allUrls.every((u) => u === OPENROUTER), `only the stubbed model endpoint was called (${allUrls.length} calls)`);
} finally {
  setWriteFaultForTest(null);
  config.girl = savedGirl;
  config.dataDir = savedDataDir;
  config.logDir = savedLogDir;
  globalThis.fetch = realFetch;
  resetAccountBindings();
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.rmSync(childDirs, { recursive: true, force: true });
}

console.log(fail ? `\n${fail} FAILED of ${n}` : `all ${n} recovery checks passed`);
process.exit(fail ? 1 : 0);
