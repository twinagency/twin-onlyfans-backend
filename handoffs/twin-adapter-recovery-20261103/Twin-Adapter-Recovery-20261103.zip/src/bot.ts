import fs from "node:fs";
import path from "node:path";
import { Bot, InlineKeyboard, InputFile } from "grammy";
import { config } from "./config.js";
import { getGirl } from "./girls/index.js";
import { loadCatalogue, download, type Item } from "./media.js";
import { loadChat, saveChat, resetChat, setConfirmed, getFileId, setFileId, touchChat } from "./memory.js";
import { priceFor, priceMode, payloadFor, purchases, startStarPoller, type Purchase } from "./payments.js";
import { runTurn, noteMediaSent, logTurn } from "./turn.js";

for (const k of ["telegramToken", "openrouterKey", "supabaseUrl", "supabaseKey"] as const) {
  if (!config[k]) { console.error(`missing ${k} in .env`); process.exit(1); }
}

const girl = getGirl(config.girl);
const catalogue = await loadCatalogue(girl.cloneId);
// New uploads show up without a restart: reload her catalogue every 10 minutes (kept as-is if a reload fails).
setInterval(async () => {
  try {
    const fresh = await loadCatalogue(girl.cloneId);
    if (fresh.length) catalogue.splice(0, catalogue.length, ...fresh);
  } catch (e: any) { console.warn(`[media] reload failed: ${String(e?.message ?? e).slice(0, 120)}`); }
}, 10 * 60_000);
const bot = new Bot(config.telegramToken);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Per-fan: lines arriving within mergeMs become one turn; turns for one fan never overlap.
type Pending = { lines: string[]; timer?: NodeJS.Timeout; who: string };
/** business_connection_id for this chat, or undefined for a plain bot chat. Every send passes it. */
const bcidOf = (chatId: number) => loadChat(chatId).bcid;
const biz = (chatId: number) => { const b = bcidOf(chatId); return b ? { business_connection_id: b } : {}; };
const pending = new Map<number, Pending>();
const running = new Map<number, Promise<void>>();

function queue(chatId: number, who: string, text: string) {
  const p = pending.get(chatId) ?? { lines: [], who };
  p.lines.push(text);
  clearTimeout(p.timer);
  p.timer = setTimeout(() => flush(chatId), config.mergeMs);
  pending.set(chatId, p);
}

function flush(chatId: number) {
  const prev = running.get(chatId) ?? Promise.resolve();
  const next = prev.then(async () => {
    const p = pending.get(chatId);
    if (!p || !p.lines.length) return;
    pending.delete(chatId);
    await reply(chatId, p.who, p.lines.join("\n")).catch((e) => console.error(`[error] chat=${chatId}`, e?.message ?? e));
  });
  running.set(chatId, next);
  next.finally(() => { if (running.get(chatId) === next) running.delete(chatId); });
}

async function sendMedia(chatId: number, it: Item, caption?: string) {
  const opt = { ...(caption ? { caption } : {}), ...biz(chatId) };
  const cached = getFileId(it.key);
  if (cached) {
    try {
      await (it.kind === "video" ? bot.api.sendVideo(chatId, cached, opt) : bot.api.sendPhoto(chatId, cached, opt));
      return "sent(cached)";
    } catch { /* file id went stale, upload again */ }
  }
  await bot.api.sendChatAction(chatId, it.kind === "video" ? "upload_video" : "upload_photo", biz(chatId)).catch(() => {});
  const file = new InputFile(await download(it), it.storagePath.replace(/^.*\//, ""));
  const fid = it.kind === "video"
    ? (await bot.api.sendVideo(chatId, file, { supports_streaming: true, ...opt })).video.file_id
    : (await bot.api.sendPhoto(chatId, file, opt)).photo.at(-1)?.file_id;
  if (fid) setFileId(it.key, fid);
  return "sent(uploaded)";
}

/** Locked item = a real Telegram Stars paid post: blurred, "Unlock for N Stars", her text as the caption. */
async function sendLocked(chatId: number, it: Item, herText: string) {
  const stars = priceFor(it.stars);
  const cached = getFileId(it.key);
  const media = cached ?? new InputFile(await download(it), it.storagePath.replace(/^.*\//, ""));
  const msg: any = await bot.api.sendPaidMedia(chatId, stars, [{ type: it.kind, media } as any], {
    caption: herText ? herText.slice(0, 1024) : undefined,
    payload: payloadFor(it.key),
    ...biz(chatId),
  } as any);
  const pm = msg?.paid_media?.paid_media?.[0];
  const fid = it.kind === "video" ? pm?.video?.file_id : pm?.photo?.at?.(-1)?.file_id;
  if (fid && !cached) setFileId(it.key, fid);
  return `paid post ${stars}* ${cached ? "(cached)" : "(uploaded)"}`;
}

/** A sale landed: he owns it, and she sees "[he unlocked the photo: ...]" so she can react. */
async function onSale(p: Purchase) {
  const it = catalogue.find((x) => x.key === p.itemKey);
  const chat = loadChat(p.chatId);
  chat.owned = [...new Set([...(chat.owned ?? []), p.itemKey])];
  if (!chat.sent.includes(p.itemKey)) chat.sent.push(p.itemKey);
  saveChat(p.chatId, chat);
  if (it) noteMediaSent(p.chatId, it, "unlocked");
  console.log(`${p.ts} | chat=${p.chatId} | SALE ${p.itemKey} ${p.stars}* charge=${p.chargeId}`);
}

/** Operator info shown on /start (test build only): memory cleared, how it works, then her full prompt. */
function startInfo(): string[] {
  const how = [
    "[TEST BUILD INFO]",
    "Memory cleared: her chat history with you and your sent-media list are wiped. Fresh chat.",
    "",
    "HOW IT WORKS",
    `- One AI call per message: ${config.model}, pinned to ${config.providerOrder.join(" then ")}, reasoning off. No routing, no sub-AIs, no tool calls.`,
    `- Double-text wait: she replies after you've been quiet ${config.mergeMs / 1000}s, so quick texts get one answer.`,
    "- What the AI sees: her prompt (below) + a list of 5 items she can send + the last 30 messages. Nothing is ever added after your message.",
    `- Media, no tool: before each reply, code shortlists 3 locked photos matched to the chat, 1 locked video and 1 free teaser you haven't had (from ${catalogue.length} items in Supabase, read-only, dupes removed). Their real descriptions go in her prompt. She ends her text with [photo 2] / [video 1] / [free photo] and code sends that exact file.`,
    `- Locked = a real Telegram Stars paid post (blurred, Unlock button). Price mode: ${priceMode()}. Sales are logged from Telegram's Stars transactions.`,
    "- Code checks on every reply: 18+ filters in and out (minors, incest, non-consent, animals), lowercase forced, emojis and dashes stripped, cut-off replies trimmed to the last full sentence, a trailing 'what would u do to me' cut, empty reply resampled once then one in-character brb line.",
    "- Never repeats a file to you. Logs: logs/turns.log (every turn: text, media, provider, cost, ms).",
    "",
    "Her full prompt follows, then the 18+ gate. Chat starts after you tap I'm 18+.",
  ].join("\n");
  const parts = [how];
  const p = `[HER FULL PROMPT]\n\n${girl.prompt}`;
  for (let i = 0; i < p.length; i += 3900) parts.push(p.slice(i, i + 3900));
  return parts;
}

async function reply(chatId: number, who: string, text: string) {
  await bot.api.sendChatAction(chatId, "typing", biz(chatId)).catch(() => {});
  const r = await runTurn(girl, catalogue, chatId, text);
  if (r.note === "reset-during-turn") return void console.log(`[stale] chat=${chatId} reset during the turn, reply dropped`);
  const herText = r.bubbles.join(" ");
  await sleep(Math.min(4000, 600 + herText.length * 20)); // typing time
  // Exactly ONE message per reply: plain text, or text + locked card, or the free file with her text as its caption.
  let mediaStatus: string | undefined;
  try {
    if (r.media && !r.free) {
      mediaStatus = await sendLocked(chatId, r.media, herText);
      noteMediaSent(chatId, r.media, "locked");
    } else if (r.media && r.free && herText.length <= 1000) {
      mediaStatus = await sendMedia(chatId, r.media, herText || undefined);
      noteMediaSent(chatId, r.media, "free");
    } else {
      if (herText) await bot.api.sendMessage(chatId, herText, biz(chatId));
      if (r.media) {
        mediaStatus = await sendMedia(chatId, r.media);
        noteMediaSent(chatId, r.media, "free");
      }
    }
  } catch (e: any) {
    mediaStatus = `FAILED: ${String(e?.message ?? e).slice(0, 150)}`;
    if (r.media && herText) await bot.api.sendMessage(chatId, herText, biz(chatId)).catch(() => {});
  }
  logTurn({ fan: who, text, r, mediaStatus });
}

bot.command("start", async (ctx) => {
  // Every /start is a fresh chat: memory and sent media wiped, 18+ asked again.
  const p = pending.get(ctx.chat.id); // drop texts still waiting for the double-text timer
  if (p) { clearTimeout(p.timer); pending.delete(ctx.chat.id); }
  resetChat(ctx.chat.id);
  setConfirmed(ctx.chat.id, false);
  console.log(`[start] chat=${ctx.chat.id} memory + sent media cleared`);
  // Test-build info for Ronan and Jesse, shown before the 18+ gate on every /start.
  for (const part of startInfo()) await ctx.reply(part);
  const kb = new InlineKeyboard().text("I'm 18+", "age:yes").text("No", "age:no");
  await ctx.reply("This chat has sexually explicit adult content. You must be 18 or older to continue. Are you 18+?", { reply_markup: kb });
});

bot.callbackQuery("age:yes", async (ctx) => {
  const id = ctx.chat?.id ?? ctx.from.id;
  setConfirmed(id, true);
  await ctx.answerCallbackQuery();
  await ctx.editMessageReplyMarkup({ reply_markup: undefined }).catch(() => {});
  await ctx.reply(girl.greeting);
  console.log(`[gate] chat=${id} confirmed 18+`);
});

bot.callbackQuery("age:no", async (ctx) => {
  const id = ctx.chat?.id ?? ctx.from.id;
  setConfirmed(id, false);
  await ctx.answerCallbackQuery();
  await ctx.editMessageReplyMarkup({ reply_markup: undefined }).catch(() => {});
  await ctx.reply("No worries. This chat is for adults only. Bye!");
});

bot.callbackQuery(/^u:(.+)$/, async (ctx) => {
  const chatId = ctx.chat?.id ?? ctx.from.id;
  const key = ctx.match[1];
  const it = catalogue.find((x) => x.key === key);
  await ctx.answerCallbackQuery(it ? "Unlocking..." : "That one is gone, sorry").catch(() => {});
  if (!it) return;
  await ctx.editMessageReplyMarkup({ reply_markup: undefined }).catch(() => {});
  let status: string;
  try {
    status = await sendMedia(chatId, it);
    noteMediaSent(chatId, it, "unlocked");
  } catch (e: any) {
    status = `FAILED: ${String(e?.message ?? e).slice(0, 150)}`;
  }
  console.log(`${new Date().toISOString()} | chat=${chatId} | UNLOCK ${key} ${it.stars}* | ${status}`);
});

bot.command("reset", async (ctx) => {
  resetChat(ctx.chat.id);
  await ctx.reply("(chat history and sent media cleared)");
  console.log(`[reset] chat=${ctx.chat.id}`);
});

bot.on("message", async (ctx) => {
  if (ctx.chat.type !== "private") return; // groups would share one memory and one 18+ answer
  const chatId = ctx.chat.id;
  const who = ctx.from?.username ? `@${ctx.from.username}` : String(ctx.from?.id ?? chatId);
  if (!loadChat(chatId).ageConfirmed) {
    await ctx.reply("Please send /start and confirm you're 18+ first.");
    return;
  }
  const text = ctx.message.text ?? ctx.message.caption ?? (ctx.message.photo ? "(sent you a photo)" : ctx.message.voice ? "(sent you a voice note)" : ctx.message.sticker ? `(sent a sticker ${ctx.message.sticker.emoji ?? ""})` : "");
  if (!text || text.startsWith("/")) return;
  touchChat(chatId, { who });
  queue(chatId, who, text);
});

// ---------- business connection: fans write to the creator's own account ----------
const BIZ_FILE = path.join(config.dataDir, config.girl, "_business.json");
const bizOwners = (): Record<string, number> => { try { return JSON.parse(fs.readFileSync(BIZ_FILE, "utf8")); } catch { return {}; } };
bot.on("business_connection", (ctx) => {
  const c = ctx.businessConnection;
  const owners = bizOwners();
  if (c.is_enabled) owners[c.id] = c.user.id; else delete owners[c.id];
  fs.mkdirSync(path.dirname(BIZ_FILE), { recursive: true });
  fs.writeFileSync(BIZ_FILE, JSON.stringify(owners, null, 2));
  console.log(`[business] connection ${c.id} ${c.is_enabled ? "enabled" : "disabled"} by user ${c.user.id} (can reply: ${(c as any).rights?.can_reply ?? (c as any).can_reply})`);
});
bot.on("business_message", (ctx) => {
  const m = ctx.businessMessage;
  const bcid = m.business_connection_id;
  if (!bcid || m.from?.id === bizOwners()[bcid]) return; // the creator's own messages, not a fan
  if (m.chat.type !== "private") return;
  const chatId = m.chat.id;
  const who = m.from?.username ? `@${m.from.username}` : String(m.from?.id ?? chatId);
  touchChat(chatId, { bcid, who });
  const text = m.text ?? m.caption ?? (m.photo ? "(sent you a photo)" : m.voice ? "(sent you a voice note)" : m.sticker ? `(sent a sticker ${m.sticker.emoji ?? ""})` : "");
  if (!text) return;
  queue(chatId, who, text); // no 18+ button here: fans write to her account, like live Twin
});

// ---------- test-only: give an admin's Stars back ----------
const ADMINS = new Set((process.env.ADMIN_IDS ?? "6814483810").split(",").map((x) => Number(x.trim())).filter(Boolean));
bot.command("refund", async (ctx) => {
  if (!ADMINS.has(ctx.from?.id ?? 0)) return;
  const mine = purchases().filter((p) => p.chatId === ctx.from!.id).at(-1);
  if (!mine) return void ctx.reply("(no purchase of yours to refund)");
  try {
    await bot.api.refundStarPayment(ctx.from!.id, mine.chargeId);
    await ctx.reply(`(refunded ${mine.stars} Stars for ${mine.itemKey})`);
    console.log(`[refund] ${mine.chargeId} ${mine.stars}*`);
  } catch (e: any) { await ctx.reply(`(refund failed: ${String(e?.message ?? e).slice(0, 120)})`); }
});

bot.catch((e) => console.error("[bot error]", e.message));
startStarPoller(bot.api, onSale);

console.log(`[startup] ${girl.name} | model ${config.model} via ${config.providerOrder.join(" > ")} | ${catalogue.length} media items`);
bot.start({ allowed_updates: ["message", "callback_query", "business_connection", "business_message", "purchased_paid_media"], onStart: (me) => console.log(`[startup] online as @${me.username} (long polling)`) });
