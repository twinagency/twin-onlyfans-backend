/**
 * Private loopback HTTP adapter for the OnlyFans bridge (Stage 1B part 2).
 *
 * This module NEVER listens on import: `createBridgeServer` builds a server, `startBridgeServer`
 * explicitly binds it. It is a thin authenticated shell around the durable service in `service.ts`;
 * it holds no lifecycle rules of its own and stores nothing.
 *
 * Guarantees:
 * - Every route, including health, requires exactly one `Authorization: Bearer <token>` header,
 *   compared in constant time. Authentication runs before routing, so an unauthenticated request can
 *   never reach the service, the model or storage, and cannot probe which routes exist.
 * - Bodies are UTF-8 JSON, counted as raw bytes while reading and capped at REQUEST_LIMITS.totalBytes
 *   (16 KiB) for both fixed-length and chunked requests. Invalid UTF-8 and unsupported encodings are
 *   refused, never repaired.
 * - Generation requests are bounded: a finite response deadline and a hard cap on concurrent replies
 *   (excess is rejected before admission, with no queue). Status, cancel and reset stay available
 *   while reply capacity is occupied.
 * - A deadline or client disconnect does not cancel work, free the capacity slot early, mark delivery
 *   or write to a closed response. The durable service finishes, and the same identity can read the
 *   result afterwards.
 * - Responses are sanitised: no transcripts, no stored failure strings, no stack traces, no secrets
 *   and no filesystem paths. HTTP success never means a message was sent.
 *
 * Single-process, loopback-only scope, deliberately: this adapter performs no platform sends and
 * makes no exactly-once delivery claim.
 */
import crypto from "node:crypto";
import http from "node:http";
import type { Socket } from "node:net";
import type { Girl } from "../girls/index.js";
import type { Item } from "../media.js";
import { resolveCreator } from "./identity.js";
import {
  acknowledgeDelivery,
  cancelRequest,
  readReplyState,
  recoverInterruptedRequests,
  requestReply,
  resetConversation,
  type AckResult,
  type CancelResult,
  type GenerateFn,
  type ReplyState,
  type ResetResult,
} from "./service.js";
import { StoreError } from "./store.js";
import { ChannelError, REQUEST_LIMITS, parseInboundEvent, type InboundEvent } from "./types.js";

/** Wire schema version of the HTTP envelope. Separate from the store's own schema version. */
export const BRIDGE_API_VERSION = 1;
export const BRIDGE_BIND_HOST = "127.0.0.1";
export const BRIDGE_DEFAULT_PORT = 4311;

/** Route paths, used by the implementation, the tests and the documentation alike. */
export const BRIDGE_ROUTES = {
  health: "/healthz",
  replies: "/v1/onlyfans/replies",
  status: "/v1/onlyfans/replies/status",
  ack: "/v1/onlyfans/replies/ack",
  cancel: "/v1/onlyfans/replies/cancel",
  reset: "/v1/onlyfans/conversations/reset",
} as const;

/**
 * Documented limits. The response deadline is deliberately larger than the model's own bounded
 * budget (llm.complete tries twice with a 45s per-attempt timeout), so a slow provider normally
 * surfaces as a `failed` service state rather than as an adapter deadline.
 */
export const BRIDGE_LIMITS = {
  maxBodyBytes: REQUEST_LIMITS.totalBytes,
  headerTimeoutMs: 10_000,
  bodyTimeoutMs: 10_000,
  responseDeadlineMs: 100_000,
  maxConcurrentReplies: 4,
  keepAliveTimeoutMs: 5_000,
  shutdownGraceMs: 5_000,
} as const;

export type PublicErrorCode =
  | "unauthorized"
  | "forbidden"
  | "bad-request"
  | "invalid-json"
  | "invalid-utf8"
  | "oversized-body"
  | "unsupported-media-type"
  | "unsupported-encoding"
  | "request-timeout"
  | "not-found"
  | "method-not-allowed"
  | "ack-rejected"
  | "cancel-rejected"
  | "overloaded"
  | "deadline-exceeded"
  | "storage-unavailable"
  | "internal";

/** Fixed public messages: an internal message is never copied into a response. */
const ERROR_MESSAGES: Record<PublicErrorCode, string> = {
  unauthorized: "authentication required",
  forbidden: "account is not bound to this creator",
  "bad-request": "request is not a valid bridge event",
  "invalid-json": "body is not valid JSON",
  "invalid-utf8": "body is not valid UTF-8",
  "oversized-body": "body exceeds the permitted size",
  "unsupported-media-type": "body must be application/json",
  "unsupported-encoding": "content encoding is not supported",
  "request-timeout": "body was not received in time",
  "not-found": "no such route or request",
  "method-not-allowed": "method is not allowed for this route",
  "ack-rejected": "request cannot be acknowledged",
  "cancel-rejected": "request cannot be cancelled",
  overloaded: "reply capacity is busy",
  "deadline-exceeded": "response deadline exceeded",
  "storage-unavailable": "durable state is unavailable",
  internal: "internal error",
};

/**
 * `retryable` means: retrying this HTTP call with the same body is safe, because the service is
 * idempotent on the request identity. It never authorises re-sending a platform message.
 */
const RETRYABLE: ReadonlySet<PublicErrorCode> = new Set<PublicErrorCode>(["overloaded", "deadline-exceeded"]);

/** The five service operations this adapter may call. A test may replace the whole set. */
export type BridgeOperations = {
  requestReply(event: InboundEvent): Promise<ReplyState>;
  readReplyState(event: InboundEvent): Promise<ReplyState | null>;
  acknowledgeDelivery(event: InboundEvent): Promise<AckResult>;
  cancelRequest(event: InboundEvent): Promise<CancelResult>;
  resetConversation(event: InboundEvent): Promise<ResetResult>;
};

/** Documented seams. A production request body can never influence any of these. */
export type BridgeHttpOptions = {
  /** Bearer token. Defaults to ONLYFANS_BRIDGE_TOKEN and is validated before the server is built. */
  token?: string;
  /** Test seams forwarded to the durable service. */
  girl?: Girl;
  catalogue?: Item[];
  generate?: GenerateFn;
  now?: () => Date;
  /** Replace the service entirely (auth/limit tests that must not touch storage). */
  operations?: BridgeOperations;
  /** Time limits and capacity. */
  headerTimeoutMs?: number;
  bodyTimeoutMs?: number;
  responseDeadlineMs?: number;
  maxConcurrentReplies?: number;
  keepAliveTimeoutMs?: number;
  shutdownGraceMs?: number;
  /** Test seam for startup recovery; defaults to the real durable recovery. */
  recover?: () => unknown;
};

export type RunningBridge = {
  server: http.Server;
  host: string;
  port: number;
  url: string;
  close(): Promise<void>;
};

/** Validate the bearer token. Throws without echoing the value; callers must fail before listening. */
export function validateBridgeToken(raw: string | undefined): string {
  const token = raw ?? "";
  if (token.length < 32) throw new Error("ONLYFANS_BRIDGE_TOKEN must be at least 32 characters");
  if (/\s/.test(token)) throw new Error("ONLYFANS_BRIDGE_TOKEN must not contain whitespace");
  return token;
}

/** Validate the loopback port. Throws for anything that is not a usable TCP port. */
export function parseBridgePort(raw: string | undefined): number {
  const text = (raw ?? "").trim();
  if (!text) return BRIDGE_DEFAULT_PORT;
  if (!/^\d{1,5}$/.test(text)) throw new Error("ONLYFANS_BRIDGE_PORT must be an integer between 1 and 65535");
  const port = Number(text);
  if (port < 1 || port > 65535) throw new Error("ONLYFANS_BRIDGE_PORT must be an integer between 1 and 65535");
  return port;
}

const sha256 = (v: string) => crypto.createHash("sha256").update(v, "utf8").digest();

/** Constant-time token comparison over fixed-length digests, so length never leaks through timing. */
function tokenMatches(presented: string, expected: string): boolean {
  return crypto.timingSafeEqual(sha256(presented), sha256(expected));
}

function defaultOperations(options: BridgeHttpOptions): BridgeOperations {
  const seams = { girl: options.girl, catalogue: options.catalogue, generate: options.generate, now: options.now };
  return {
    requestReply: (event) => requestReply(event, seams),
    readReplyState: (event) => readReplyState(event, seams),
    acknowledgeDelivery: (event) => acknowledgeDelivery(event, seams),
    cancelRequest: (event) => cancelRequest(event, seams),
    resetConversation: (event) => resetConversation(event, seams),
  };
}

/** Only the fields a caller needs. No transcripts, stored failure strings, notes or paths. */
function projectReply(state: ReplyState) {
  return {
    requestId: state.requestId,
    conversationKey: state.conversationKey,
    status: state.status,
    outcome: state.outcome,
    deliverable: state.deliverable,
    text: state.deliverable ? state.text : "",
    epoch: state.epoch,
    createdAt: state.createdAt,
    completedAt: state.completedAt,
    deliveredAt: state.deliveredAt,
    committedAt: state.committedAt,
    usage: {
      provider: state.usage.provider,
      tokensIn: state.usage.tokensIn,
      tokensOut: state.usage.tokensOut,
      cost: state.usage.cost,
      ms: state.usage.ms,
      attempts: state.usage.attempts,
    },
  };
}

type Mapped = { status: number; code: PublicErrorCode; reason?: string };

/** Map an internal failure onto a documented, sanitised public result. */
function mapThrown(err: unknown): Mapped {
  if (err instanceof ChannelError) {
    if (err.code === "unknown-account" || err.code === "creator-mismatch") return { status: 403, code: "forbidden" };
    if (err.code === "oversized-field") return { status: 413, code: "oversized-body" };
    return { status: 400, code: "bad-request" };
  }
  // Storage corruption, unsupported/legacy journals and write failures all land here. Not retryable:
  // the state needs operator attention, and the adapter must not pretend the request succeeded.
  if (err instanceof StoreError) return { status: 500, code: "storage-unavailable" };
  return { status: 500, code: "internal" };
}

type BuiltBridge = { server: http.Server; activeWork: Set<Promise<void>> };

function buildBridge(options: BridgeHttpOptions): BuiltBridge {
  const token = validateBridgeToken(options.token ?? process.env.ONLYFANS_BRIDGE_TOKEN);
  const operations = options.operations ?? defaultOperations(options);
  const limits = {
    headerTimeoutMs: options.headerTimeoutMs ?? BRIDGE_LIMITS.headerTimeoutMs,
    bodyTimeoutMs: options.bodyTimeoutMs ?? BRIDGE_LIMITS.bodyTimeoutMs,
    responseDeadlineMs: options.responseDeadlineMs ?? BRIDGE_LIMITS.responseDeadlineMs,
    maxConcurrentReplies: options.maxConcurrentReplies ?? BRIDGE_LIMITS.maxConcurrentReplies,
    keepAliveTimeoutMs: options.keepAliveTimeoutMs ?? BRIDGE_LIMITS.keepAliveTimeoutMs,
    maxBodyBytes: BRIDGE_LIMITS.maxBodyBytes,
  };

  /** Reply work that has started and not yet settled. Its slot is held until the work finishes. */
  const activeWork = new Set<Promise<void>>();
  let repliesInFlight = 0;

  const server = http.createServer((req, res) => {
    res.on("error", () => {}); // a late write to a dropped socket must not become an unhandled error
    void handle(req, res);
  });

  server.headersTimeout = limits.headerTimeoutMs;
  server.requestTimeout = limits.headerTimeoutMs + limits.bodyTimeoutMs;
  server.keepAliveTimeout = limits.keepAliveTimeoutMs;
  server.timeout = limits.bodyTimeoutMs + limits.responseDeadlineMs;

  function sendJson(res: http.ServerResponse, status: number, payload: unknown, extra: Record<string, string> = {}): void {
    if (res.writableEnded || res.destroyed) return;
    const body = JSON.stringify(payload);
    res.writeHead(status, {
      "content-type": "application/json; charset=utf-8",
      "content-length": Buffer.byteLength(body),
      "cache-control": "no-store",
      ...extra,
    });
    res.end(body);
  }

  function sendOk(res: http.ServerResponse, status: number, result: unknown): void {
    sendJson(res, status, { schemaVersion: BRIDGE_API_VERSION, ok: true, result });
  }

  function sendError(res: http.ServerResponse, mapped: Mapped, extra: Record<string, string> = {}): void {
    sendJson(
      res,
      mapped.status,
      {
        schemaVersion: BRIDGE_API_VERSION,
        ok: false,
        error: {
          code: mapped.code,
          message: ERROR_MESSAGES[mapped.code],
          retryable: RETRYABLE.has(mapped.code),
          ...(mapped.reason ? { reason: mapped.reason } : {}),
        },
      },
      extra,
    );
  }

  /** Exactly one Authorization header, and it must be `Bearer <token>`. */
  function authenticate(req: http.IncomingMessage): boolean {
    const values: string[] = [];
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      if (req.rawHeaders[i].toLowerCase() === "authorization") values.push(req.rawHeaders[i + 1]);
    }
    if (values.length !== 1) return false;
    const match = /^Bearer ([^\s]+)$/i.exec(values[0]); // scheme is case-insensitive per RFC 7235
    if (!match) return false;
    return tokenMatches(match[1], token);
  }

  type BodyResult = { ok: true; value: unknown } | { ok: false; mapped: Mapped };

  /** Read and decode the body: UTF-8 JSON only, counted as raw bytes, bounded by size and time. */
  function readJsonBody(req: http.IncomingMessage): Promise<BodyResult> {
    return new Promise<BodyResult>((resolve) => {
      const contentType = String(req.headers["content-type"] ?? "");
      if (!/^application\/json\b/i.test(contentType.trim())) {
        resolve({ ok: false, mapped: { status: 415, code: "unsupported-media-type" } });
        return;
      }
      const encoding = String(req.headers["content-encoding"] ?? "").trim().toLowerCase();
      if (encoding && encoding !== "identity") {
        resolve({ ok: false, mapped: { status: 415, code: "unsupported-encoding" } });
        return;
      }
      const declared = req.headers["content-length"];
      if (declared !== undefined) {
        const length = Number(Array.isArray(declared) ? declared[0] : declared);
        if (!Number.isInteger(length) || length < 0) {
          resolve({ ok: false, mapped: { status: 400, code: "bad-request" } });
          return;
        }
        if (length > limits.maxBodyBytes) {
          resolve({ ok: false, mapped: { status: 413, code: "oversized-body" } });
          return;
        }
      }

      const chunks: Buffer[] = [];
      let bytes = 0;
      let settled = false;
      const finish = (result: BodyResult, stopReading: boolean) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        req.removeListener("data", onData);
        req.removeListener("end", onEnd);
        req.removeListener("error", onError);
        req.removeListener("aborted", onAbort);
        if (stopReading) req.pause(); // do not buffer an unbounded upload we already refused
        resolve(result);
      };
      const onData = (chunk: Buffer) => {
        bytes += chunk.length;
        if (bytes > limits.maxBodyBytes) {
          finish({ ok: false, mapped: { status: 413, code: "oversized-body" } }, true);
          return;
        }
        chunks.push(chunk);
      };
      const onEnd = () => {
        let text: string;
        try {
          text = new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks));
        } catch {
          finish({ ok: false, mapped: { status: 400, code: "invalid-utf8" } }, false);
          return;
        }
        try {
          finish({ ok: true, value: JSON.parse(text) }, false);
        } catch {
          finish({ ok: false, mapped: { status: 400, code: "invalid-json" } }, false);
        }
      };
      const onError = () => finish({ ok: false, mapped: { status: 400, code: "bad-request" } }, false);
      const onAbort = () => finish({ ok: false, mapped: { status: 400, code: "bad-request" } }, false);
      const timer = setTimeout(() => finish({ ok: false, mapped: { status: 408, code: "request-timeout" } }, true), limits.bodyTimeoutMs);
      timer.unref?.();

      req.on("data", onData);
      req.on("end", onEnd);
      req.on("error", onError);
      req.on("aborted", onAbort);
    });
  }

  /** Validate identity and creator binding before any service work, exactly as the service does. */
  function parseEvent(value: unknown): InboundEvent {
    const event = parseInboundEvent(value);
    resolveCreator(event.accountId, event.creatorSlug);
    return event;
  }

  /**
   * One generation request. The work is not tied to the connection: a deadline or client disconnect
   * leaves it running, holds the capacity slot until it settles, and lets the same identity read the
   * result afterwards. The caller has already reserved the slot.
   */
  function runReply(event: InboundEvent, res: http.ServerResponse): void {
    let responded = false;
    const work = operations.requestReply(event);
    const settled = work.then(
      () => undefined,
      () => undefined,
    );
    activeWork.add(settled);

    const timer = setTimeout(() => {
      if (responded) return;
      responded = true;
      sendError(res, { status: 503, code: "deadline-exceeded" });
    }, limits.responseDeadlineMs);
    timer.unref?.();

    void work
      .then(
        (state) => {
          if (responded) return;
          responded = true;
          clearTimeout(timer);
          sendOk(res, 200, projectReply(state));
        },
        (err: unknown) => {
          if (responded) return;
          responded = true;
          clearTimeout(timer);
          sendError(res, mapThrown(err));
        },
      )
      .finally(() => {
        // The slot is released when the WORK finishes, never when the response is sent.
        activeWork.delete(settled);
        repliesInFlight--;
      });
  }

  async function handle(req: http.IncomingMessage, res: http.ServerResponse): Promise<void> {
    try {
      // Authentication first, for every path: an unauthenticated caller learns nothing, not even
      // whether a route exists.
      if (!authenticate(req)) {
        sendError(res, { status: 401, code: "unauthorized" });
        return;
      }

      const path = new URL(req.url ?? "/", `http://${BRIDGE_BIND_HOST}`).pathname;
      const method = req.method ?? "";

      if (path === BRIDGE_ROUTES.health) {
        if (method !== "GET") return sendError(res, { status: 405, code: "method-not-allowed" }, { allow: "GET" });
        sendOk(res, 200, { status: "ok", apiVersion: BRIDGE_API_VERSION });
        return;
      }

      const isKnownPost = path === BRIDGE_ROUTES.replies || path === BRIDGE_ROUTES.status || path === BRIDGE_ROUTES.ack || path === BRIDGE_ROUTES.cancel || path === BRIDGE_ROUTES.reset;
      if (!isKnownPost) {
        sendError(res, { status: 404, code: "not-found" });
        return;
      }
      if (method !== "POST") return sendError(res, { status: 405, code: "method-not-allowed" }, { allow: "POST" });

      const isReply = path === BRIDGE_ROUTES.replies;
      let slotHeld = false;
      if (isReply) {
        // Capacity is checked before the body is read, so excess work is never admitted and no
        // unbounded queue can form. Status, cancel and reset are not gated by this.
        if (repliesInFlight >= limits.maxConcurrentReplies) {
          sendError(res, { status: 429, code: "overloaded" });
          return;
        }
        repliesInFlight++;
        slotHeld = true;
      }

      try {
        const body = await readJsonBody(req);
        if (!body.ok) {
          sendError(res, body.mapped);
          return;
        }

        let event: InboundEvent;
        try {
          event = parseEvent(body.value);
        } catch (err) {
          sendError(res, mapThrown(err));
          return;
        }

        if (isReply) {
          slotHeld = false; // ownership of the slot passes to the running work
          runReply(event, res);
          return;
        }

        if (path === BRIDGE_ROUTES.status) {
          const state = await operations.readReplyState(event);
          if (!state) return sendError(res, { status: 404, code: "not-found" });
          sendOk(res, 200, projectReply(state));
          return;
        }
        if (path === BRIDGE_ROUTES.ack) {
          const result = await operations.acknowledgeDelivery(event);
          if (result.status === "delivered" || result.status === "already-delivered") {
            sendOk(res, 200, { requestId: result.requestId, conversationKey: result.conversationKey, status: result.status });
            return;
          }
          if (result.status === "not-found") return sendError(res, { status: 404, code: "not-found" });
          sendError(res, { status: 409, code: "ack-rejected", reason: result.status });
          return;
        }
        if (path === BRIDGE_ROUTES.cancel) {
          const result = await operations.cancelRequest(event);
          if (result.status === "cancelled" || result.status === "already-cancelled") {
            sendOk(res, 200, { requestId: result.requestId, conversationKey: result.conversationKey, status: result.status });
            return;
          }
          if (result.status === "not-found") return sendError(res, { status: 404, code: "not-found" });
          sendError(res, { status: 409, code: "cancel-rejected", reason: result.status });
          return;
        }
        const result = await operations.resetConversation(event);
        sendOk(res, 200, { conversationKey: result.conversationKey, epoch: result.epoch, cancelled: result.cancelled });
      } finally {
        if (slotHeld) repliesInFlight--;
      }
    } catch (err) {
      sendError(res, mapThrown(err));
    }
  }

  return { server, activeWork };
}

/** Build (but do not bind) the adapter. Validates the token before anything else happens. */
export function createBridgeServer(options: BridgeHttpOptions = {}): http.Server {
  return buildBridge(options).server;
}

/**
 * Build and bind the loopback server. Startup recovery runs first, so invalid configuration, a
 * corrupt snapshot or a legacy journal prevents readiness instead of serving.
 */
export async function startBridgeServer(options: BridgeHttpOptions & { port?: number } = {}): Promise<RunningBridge> {
  const recover = options.recover ?? (() => recoverInterruptedRequests());
  recover(); // throws before listening when durable state is unusable

  const { server, activeWork } = buildBridge(options);
  const port = options.port ?? 0;
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, BRIDGE_BIND_HOST, () => {
      server.removeListener("error", reject);
      resolve();
    });
  });

  const address = server.address();
  const boundPort = typeof address === "object" && address ? address.port : port;
  const sockets = new Set<Socket>();
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
  });

  const close = async (): Promise<void> => {
    if (!server.listening) return;
    const closed = new Promise<void>((resolve) => server.close(() => resolve()));
    server.closeIdleConnections();

    const graceMs = options.shutdownGraceMs ?? BRIDGE_LIMITS.shutdownGraceMs;
    let graceTimer: NodeJS.Timeout | undefined;
    const grace = new Promise<void>((resolve) => {
      graceTimer = setTimeout(resolve, graceMs);
      graceTimer.unref?.();
    });
    // Wait for in-flight generation work, but never longer than the grace deadline. Work that is
    // still running keeps its durable claim and is recovered as interrupted by the next start.
    await Promise.race([Promise.all([closed, Promise.all([...activeWork])]), grace]);
    if (graceTimer) clearTimeout(graceTimer);
    server.closeAllConnections();
    for (const socket of sockets) socket.destroy();
    await closed;
  };

  return { server, host: BRIDGE_BIND_HOST, port: boundPort, url: `http://${BRIDGE_BIND_HOST}:${boundPort}`, close };
}
