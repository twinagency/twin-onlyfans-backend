/**
 * Server-side identity binding for the OnlyFans bridge.
 *
 * The account -> creator mapping lives here, never in the inbound payload: a caller can claim
 * whatever creator it likes and we still route by the configured binding. One creator is served
 * per process, and it must match `config.girl`.
 *
 * Memory keys are opaque hashes of a stable, length-prefixed serialized tuple, so no external
 * identifier is ever interpolated into a filesystem path and no identifier can alias another
 * tuple by carrying a delimiter. Telegram's numeric keys are untouched and stay readable.
 */
import crypto from "node:crypto";
import { config } from "../config.js";
import { ChannelError, type InboundEvent } from "./types.js";

/** Prefix that marks an internally generated channel memory key (vs a legacy Telegram numeric id). */
export const CHANNEL_KEY_PREFIX = "of_";

/** Server-side account -> creator binding, from ONLYFANS_ACCOUNT_BINDINGS="acct:creator,acct2:creator2". */
let bindings = envBindings();

function envBindings(): Map<string, string> {
  const out = new Map<string, string>();
  for (const part of (process.env.ONLYFANS_ACCOUNT_BINDINGS ?? "").split(",")) {
    const entry = part.trim();
    if (!entry) continue;
    const i = entry.indexOf(":");
    if (i < 1) continue;
    const account = entry.slice(0, i).trim();
    const creator = entry.slice(i + 1).trim();
    if (account && creator) out.set(account, creator);
  }
  return out;
}

/** Replace the process binding table (used by the offline harness and future config loading). */
export function setAccountBindings(entries: Iterable<[string, string]>): void {
  bindings = new Map(entries);
}

/** Re-read the binding table from the environment. */
export function resetAccountBindings(): void {
  bindings = envBindings();
}

export function boundCreatorFor(accountId: string): string | null {
  return bindings.get(accountId) ?? null;
}

/**
 * Resolve the creator this account is allowed to answer as.
 * Rejects unknown accounts, a binding that does not match this process, and a payload that
 * claims a different creator than the server-side binding.
 */
export function resolveCreator(accountId: string, claimedCreatorSlug: string): string {
  const bound = boundCreatorFor(accountId);
  if (!bound) throw new ChannelError("unknown-account", `no channel binding for account ${JSON.stringify(accountId)}`);
  if (bound !== config.girl) {
    throw new ChannelError("creator-mismatch", `account is bound to ${JSON.stringify(bound)} but this process serves ${JSON.stringify(config.girl)}`);
  }
  if (claimedCreatorSlug !== bound) {
    throw new ChannelError("creator-mismatch", `payload claims creator ${JSON.stringify(claimedCreatorSlug)} but the account is bound to ${JSON.stringify(bound)}`);
  }
  return bound;
}

/**
 * Length-prefix each field ("<byteLength>:<value>") before joining, so a delimiter inside one
 * value can never shift the field boundaries and collide with a different tuple.
 */
function encodeTuple(parts: string[]): string {
  return parts.map((p) => `${Buffer.byteLength(p, "utf8")}:${p}`).join("|");
}

function hashTuple(prefix: string, parts: string[]): string {
  return `${prefix}${crypto.createHash("sha256").update(encodeTuple(parts), "utf8").digest("hex")}`;
}

/** The conversation identity that memory is keyed on: channel + account + creator + conversation + fan. */
export type ConversationIdentity = Pick<InboundEvent, "channel" | "accountId" | "creatorSlug" | "conversationId" | "fanId">;

/**
 * Filesystem-safe memory key for one conversation. Two messages in the same conversation share it,
 * because the provider message id is deliberately NOT part of the tuple.
 */
export function conversationKey(id: ConversationIdentity): string {
  return hashTuple(CHANNEL_KEY_PREFIX, [id.channel, id.accountId, id.creatorSlug, id.conversationId, id.fanId]);
}

/**
 * Stable identity of one provider message: channel + account + fan + message id. This is the dedupe
 * key later stages will persist; Stage 1A uses it only as the draft requestId. It is not a memory key.
 */
export function messageKey(id: Pick<InboundEvent, "channel" | "accountId" | "fanId" | "messageId">): string {
  return hashTuple("ofm_", [id.channel, id.accountId, id.fanId, id.messageId]);
}

/** True when a memory key was generated here rather than inherited from the Telegram flow. */
export function isChannelConversationKey(key: string): boolean {
  return key.startsWith(CHANNEL_KEY_PREFIX);
}
