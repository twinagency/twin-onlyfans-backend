/**
 * Entry point for the private OnlyFans bridge adapter (Stage 1B part 2).
 *
 *   npm run start:onlyfans-bridge
 *
 * Configuration comes from the environment only, never from a request:
 *   ONLYFANS_BRIDGE_TOKEN  required, at least 32 characters, no whitespace (generate with
 *                          `node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"`)
 *   ONLYFANS_BRIDGE_PORT   optional, 1-65535, default 4311
 *
 * It binds 127.0.0.1 only, completes durable startup recovery before it listens, and closes
 * predictably on SIGINT/SIGTERM. Startup logging is deliberately sanitised: no token, no raw error
 * text and no filesystem paths are written here.
 */
import { pathToFileURL } from "node:url";
import { StoreError } from "./store.js";
import { parseBridgePort, startBridgeServer, validateBridgeToken, type RunningBridge } from "./http.js";

const STATE_UNUSABLE = "[bridge] startup failed: durable state is unusable (corruption or a legacy journal needs operator attention); refusing to serve\n";
const BIND_FAILED = "[bridge] startup failed: cannot bind the configured loopback port\n";

/** Start the adapter. Returns an exit code; the process stays alive while the listener is open. */
export async function main(env: NodeJS.ProcessEnv = process.env): Promise<number> {
  let token: string;
  let port: number;
  try {
    token = validateBridgeToken(env.ONLYFANS_BRIDGE_TOKEN);
    port = parseBridgePort(env.ONLYFANS_BRIDGE_PORT);
  } catch (e: unknown) {
    // Our own validator messages are fixed and contain neither the token nor a path.
    process.stderr.write(`[bridge] configuration error: ${String((e as Error)?.message ?? e)}\n`);
    return 1;
  }

  let bridge: RunningBridge;
  try {
    bridge = await startBridgeServer({ token, port });
  } catch (e: unknown) {
    process.stderr.write(e instanceof StoreError ? STATE_UNUSABLE : BIND_FAILED);
    return 1;
  }

  process.stdout.write(`[bridge] listening on ${bridge.url} (loopback only)\n`);

  let closing = false;
  const shutdown = (signal: string): void => {
    if (closing) return;
    closing = true;
    process.stdout.write(`[bridge] ${signal} received, closing\n`);
    void bridge.close().then(
      () => process.exit(0),
      () => process.exit(1),
    );
  };
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  return 0;
}

// Only run when executed directly, so importing this module (for example from a test) is inert.
const invoked = process.argv[1] ? pathToFileURL(process.argv[1]).href === import.meta.url : false;
if (invoked) {
  void main().then((code) => {
    if (code !== 0) process.exit(code);
  });
}
