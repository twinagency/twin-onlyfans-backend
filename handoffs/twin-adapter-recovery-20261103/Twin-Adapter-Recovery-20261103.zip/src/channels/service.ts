/**
 * Durable reply service for the OnlyFans channel (Stage 1B part 1, repaired).
 *
 * Guarantees this layer provides, and the order that makes them hold:
 *
 * 1. Admission first. A request is persisted as `queued` with its admission revision BEFORE it waits
 *    behind another turn, so cancellation, reset, duplicate detection and restart recovery can all see
 *    it. The revision is re-checked immediately before the model runs.
 * 2. One turn per conversation. Requests are chained per conversation key; unrelated conversations run
 *    in parallel. A duplicate waits its turn and then returns the saved record.
 * 3. Drafts are not history. The transcript lives in the same durable snapshot as the journal, and a
 *    generated reply is only written into it by an acknowledgement.
 * 4. Acknowledgement is two ordered writes: the delivery DECISION (status delivered + deliveredAt) is
 *    committed first and is authoritative, then the transcript commit records `committedAt`. A failure
 *    after the decision can never make the reply deliverable again; it only leaves the commit to be
 *    finished idempotently by reconcile/recovery. If the decision write itself fails, nothing was
 *    recorded: the call throws, and the transport must treat delivery as unknown and must not resend.
 * 5. Commit evidence is per request id, never a text comparison, so two requests with identical replies
 *    each get an entry and a replay adds none.
 * 6. Reset and cancel keep confirmed-delivery evidence. Reset clears the transcript but a delivered
 *    reply can never be delivered again.
 * 7. An interrupted generation (claim or queue left by a process that is gone) is marked interrupted
 *    and never silently retried.
 *
 * No transport lives here: nothing is sent, and no HTTP server or Fastt caller exists yet.
 * Single-process scope, deliberately: a claim or queued record whose run id is not this process is
 * treated as a dead process. Shared leases across workers are Stage 1C.
 */
import crypto from "node:crypto";
import { config } from "../config.js";
import { getGirl, type Girl } from "../girls/index.js";
import type { Item } from "../media.js";
import type { Msg } from "../memory.js";
import { generateTurn, type GenerationResult, type TurnTranscript } from "../turn.js";
import { conversationKey, messageKey, resolveCreator } from "./identity.js";
import { classifyTurn } from "./text-turn.js";
import {
  STORE_VERSION,
  StoreError,
  listConversationKeys,
  mutateState,
  newRequestRecord,
  readState,
  type ConversationState,
  type RequestRecord,
  type RequestStatus,
} from "./store.js";
import { ChannelError, parseInboundEvent, type DraftOutcome, type InboundEvent } from "./types.js";

/** Identity of this process, so a claim or queue left by another run is recognisable as dead. */
const RUN_ID = crypto.randomBytes(8).toString("hex");

export type GenerateFn = (
  girl: Girl,
  catalogue: Item[],
  chatId: number | string,
  fanText: string,
  transcript: TurnTranscript,
) => Promise<GenerationResult>;

/** Test seams only; production callers use the defaults. */
export type ServiceOptions = {
  girl?: Girl;
  catalogue?: Item[];
  generate?: GenerateFn;
  now?: () => Date;
};

/** What a caller sees for one request. `text` is only ever a draft it may deliver when `deliverable`. */
export type ReplyState = {
  version: number;
  requestId: string;
  conversationKey: string;
  status: RequestStatus;
  outcome: DraftOutcome | null;
  note: string;
  text: string;
  deliverable: boolean;
  epoch: number;
  failure: string | null;
  createdAt: string;
  completedAt: string | null;
  deliveredAt: string | null;
  committedAt: string | null;
  usage: { provider: string; tokensIn: number; tokensOut: number; cost: number; ms: number; attempts: number };
};

export type AckStatus = "delivered" | "already-delivered" | "cancelled" | "interrupted" | "stale" | "not-ready" | "in-progress" | "not-found";
export type AckResult = { status: AckStatus; conversationKey: string; requestId: string };

export type CancelStatus = "cancelled" | "already-cancelled" | "already-delivered" | "not-found";
export type CancelResult = { status: CancelStatus; conversationKey: string; requestId: string };

export type ResetResult = { conversationKey: string; epoch: number; cancelled: number };
export type RecoveryReport = { interrupted: number; commitsCompleted: number };

/** One turn per conversation at a time. The chain also makes a concurrent duplicate wait, then find
 *  the saved record instead of regenerating. */
const chains = new Map<string, Promise<void>>();

function withConversationLock<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const prev = chains.get(key) ?? Promise.resolve();
  const run = prev.then(() => fn());
  const guard = run.then(
    () => undefined,
    () => undefined,
  );
  chains.set(key, guard);
  void guard.then(() => {
    if (chains.get(key) === guard) chains.delete(key);
  });
  return run;
}

const isoNow = (now?: () => Date) => (now ?? (() => new Date()))().toISOString();

/** Provider JSON is not made trustworthy by TypeScript annotations. Reject malformed usage rather
 *  than persisting it as a successful result or coercing it into apparently valid accounting data. */
function assertGenerationMetadata(result: GenerationResult["result"]): void {
  if (typeof result.provider !== "string" || !result.provider.trim()) throw new Error("generation returned invalid provider metadata");
  for (const field of ["tokensIn", "tokensOut", "cost", "ms"] as const) {
    const value = result[field];
    if (typeof value !== "number" || !Number.isFinite(value) || value < 0 ||
        ((field === "tokensIn" || field === "tokensOut") && !Number.isSafeInteger(value))) {
      throw new Error(`generation returned invalid ${field} metadata`);
    }
  }
}

/** The bridge transcript: the same shape the turn engine already uses, backed by the durable journal. */
function bridgeTranscript(key: string): TurnTranscript {
  return {
    load: () => {
      const s = readState(key);
      return { ageConfirmed: false, history: s.transcript, sent: [...s.sent], owned: [...s.owned], epoch: s.epoch };
    },
    commit: (chatId, chat, assistant) => {
      if (String(chatId) !== key) throw new StoreError(`transcript commit for ${String(chatId)} does not belong to ${key}`);
      return mutateState(key, assistant ? "transcript+reply" : "transcript", (s) => {
        if (s.epoch !== chat.epoch) return { result: false, changed: false }; // reset while generating
        const history = assistant ? [...chat.history, { role: "assistant" as const, content: assistant }] : chat.history;
        s.transcript = history.slice(-config.historyLimit);
        s.sent = [...chat.sent];
        s.owned = [...(chat.owned ?? [])];
        return { result: true, changed: true };
      });
    },
  };
}

function toReplyState(state: ConversationState, rec: RequestRecord): ReplyState {
  // Deliverable only while the reply is undecided, uncommitted, still `completed`, and on the current
  // conversation revision. A persisted delivery decision permanently disqualifies it.
  const live = rec.status === "completed" && rec.deliveredAt === null && rec.committedAt === null && rec.epoch === state.epoch;
  return {
    version: STORE_VERSION,
    requestId: rec.requestId,
    conversationKey: rec.conversationKey,
    status: rec.status,
    outcome: rec.outcome,
    note: rec.note,
    text: live ? rec.text : "",
    deliverable: live && !!rec.text,
    epoch: rec.epoch,
    failure: rec.failure,
    createdAt: rec.createdAt,
    completedAt: rec.completedAt,
    deliveredAt: rec.deliveredAt,
    committedAt: rec.committedAt,
    usage: { provider: rec.provider, tokensIn: rec.tokensIn, tokensOut: rec.tokensOut, cost: rec.cost, ms: rec.ms, attempts: rec.attempts },
  };
}

/**
 * Finish any confirmed delivery whose transcript commit is still outstanding. Idempotent and driven by
 * `committedAt`, so it can run at any time without duplicating a reply.
 */
function finishCommits(state: ConversationState, at: string): number {
  let done = 0;
  for (const rec of Object.values(state.requests)) {
    if (rec.deliveredAt === null || rec.committedAt !== null) continue;
    // The transcript commit is keyed on this request's identity. If the conversation was reset after
    // delivery, the transcript was cleared on purpose: keep the evidence, do not resurrect the history.
    if (state.epoch === rec.epoch) {
      const entry: Msg = { role: "assistant", content: rec.text };
      state.transcript = [...state.transcript, entry].slice(-config.historyLimit);
    }
    rec.committedAt = at;
    rec.status = "delivered";
    done++;
  }
  return done;
}

/** Same as finishCommits, scoped to one conversation and safe to call on every operation. */
function reconcileCommits(key: string, at: string): void {
  mutateState(key, "reconcile", (s) => ({ result: undefined, changed: finishCommits(s, at) > 0 }));
}

/**
 * Cancelling a request must also release its claim: a snapshot that claims a cancelled request is
 * internally inconsistent and would be rejected by the store's own validation. The running turn
 * re-reads the journal before finalising, so it still honours the cancellation.
 */
function releaseClaimFor(state: ConversationState, requestId: string): void {
  if (state.inProgress?.requestId === requestId) state.inProgress = null;
}

let recovered = false;

/** Finish startup recovery once per process, before the first request is accepted. */
function ensureRecovered(): void {
  if (recovered) return;
  recoverInterruptedRequests();
  recovered = true;
}

/**
 * Scan the durable journal once, at startup:
 * - a generation or a queued request owned by a process that is no longer running becomes `interrupted`,
 *   never silently regenerated;
 * - a delivery decision that was committed but not yet reflected in the transcript is finished once.
 * Raises StoreError if a snapshot is damaged rather than guessing at its contents.
 */
export function recoverInterruptedRequests(): RecoveryReport {
  const at = new Date().toISOString();
  const report: RecoveryReport = { interrupted: 0, commitsCompleted: 0 };
  for (const key of listConversationKeys()) {
    mutateState(key, "recover", (s) => {
      let changed = false;
      const claim = s.inProgress;
      if (claim && claim.runId !== RUN_ID) {
        const rec = s.requests[claim.requestId];
        if (rec && rec.status === "in_progress") {
          rec.status = "interrupted";
          rec.failure = "process stopped while generating";
          rec.completedAt = at;
          report.interrupted++;
        }
        s.inProgress = null;
        changed = true;
      }
      for (const rec of Object.values(s.requests)) {
        if (rec.status === "queued" && rec.runId !== RUN_ID) {
          rec.status = "interrupted";
          rec.failure = "queued when the process stopped";
          rec.completedAt = at;
          report.interrupted++;
          changed = true;
        }
        // A generation claimed by another process that left no claim behind (for example the claim was
        // released by a cancel) is just as abandoned as one with a stale claim.
        if (rec.status === "in_progress" && rec.runId !== RUN_ID && s.inProgress?.requestId !== rec.requestId) {
          rec.status = "interrupted";
          rec.failure = "process stopped while generating";
          rec.completedAt = at;
          report.interrupted++;
          changed = true;
        }
      }
      const commits = finishCommits(s, at);
      report.commitsCompleted += commits;
      return { result: undefined, changed: changed || commits > 0 };
    });
  }
  return report;
}

/** Persist the queued identity and admission revision before this request waits for the lock. */
function admit(key: string, event: InboundEvent, requestId: string, at: string): void {
  mutateState(key, "admit", (s) => {
    if (s.requests[requestId]) return { result: undefined, changed: false };
    s.requests[requestId] = newRequestRecord({
      requestId,
      conversationKey: key,
      accountId: event.accountId,
      fanId: event.fanId,
      messageId: event.messageId,
      runId: RUN_ID,
      epoch: s.epoch,
      createdAt: at,
    });
    return { result: undefined, changed: true };
  });
}

/**
 * Accept one inbound fan message and return a durable state. Never sends anything.
 * A message already seen returns its saved record: no second model call, no second transcript entry.
 */
export async function requestReply(raw: unknown, options: ServiceOptions = {}): Promise<ReplyState> {
  const event = parseInboundEvent(raw);
  const creator = resolveCreator(event.accountId, event.creatorSlug);
  const girl = options.girl ?? getGirl(creator);
  if (girl.slug !== creator) {
    throw new ChannelError("creator-mismatch", `service would run as ${JSON.stringify(girl.slug)} but the account is bound to ${JSON.stringify(creator)}`);
  }
  const generate = options.generate ?? generateTurn;
  const catalogue = options.catalogue ?? [];
  const key = conversationKey(event);
  const requestId = messageKey(event);

  ensureRecovered();

  // 1. Admission: durable and visible before this request waits behind anything.
  admit(key, event, requestId, isoNow(options.now));

  // 2. Work the queue for this conversation, one turn at a time.
  return withConversationLock(key, async () => {
    reconcileCommits(key, isoNow(options.now));

    const admitted = readState(key);
    const record = admitted.requests[requestId];
    if (!record) throw new StoreError(`admitted request ${requestId} is missing from the journal for ${key}`);
    if (record.status !== "queued") return toReplyState(admitted, record); // duplicate or already handled

    // 3. A reset that landed while this request was queued invalidates it before any model call.
    if (record.admittedEpoch !== admitted.epoch) {
      const stale = mutateState(key, "cancel-stale", (s) => {
        const r = s.requests[requestId];
        if (!r || r.status !== "queued") return { result: s, changed: false };
        r.status = "cancelled";
        r.failure = "conversation reset while queued";
        r.text = "";
        r.completedAt = isoNow(options.now);
        return { result: s, changed: true };
      });
      return toReplyState(stale, stale.requests[requestId]);
    }

    // 4. Claim the turn. A cancel that landed since admission is honoured here, before the model call.
    const startedAt = isoNow(options.now);
    const started = mutateState(key, "start", (s) => {
      const r = s.requests[requestId];
      if (!r || r.status !== "queued" || r.admittedEpoch !== s.epoch) return { result: false, changed: false };
      r.status = "in_progress";
      r.startedAt = startedAt;
      r.epoch = s.epoch;
      s.inProgress = { requestId, runId: RUN_ID, startedAt };
      return { result: true, changed: true };
    });
    if (!started) {
      const current = readState(key);
      return toReplyState(current, current.requests[requestId]);
    }

    let generated: GenerationResult;
    try {
      generated = await generate(girl, catalogue, key, event.text, bridgeTranscript(key));
      assertGenerationMetadata(generated.result);
    } catch (e: unknown) {
      const at = isoNow(options.now);
      mutateState(key, "failed", (s) => {
        const r = s.requests[requestId];
        if (!r) return { result: undefined, changed: false };
        if (r.status !== "cancelled") {
          r.status = "failed";
          r.outcome = "failed";
          r.failure = `generation threw: ${String((e as Error)?.message ?? e)}`;
        }
        r.text = "";
        r.completedAt = at;
        if (s.inProgress?.requestId === requestId && s.inProgress.runId === RUN_ID) s.inProgress = null;
        return { result: undefined, changed: true };
      });
      throw e;
    }

    const { outcome, note } = classifyTurn(generated.result);
    const draft = generated.pending?.text ?? "";
    const deliverable = (outcome === "ok" || outcome === "blocked") && !!draft;
    const at = isoNow(options.now);

    // 5. Finalise. A cancel or reset that landed while the model ran wins over this completion.
    const final = mutateState(key, "finalise", (s) => {
      const r = s.requests[requestId];
      if (!r) return { result: s, changed: false };
      r.provider = generated.result.provider;
      r.tokensIn = generated.result.tokensIn;
      r.tokensOut = generated.result.tokensOut;
      r.cost = generated.result.cost;
      r.ms = generated.result.ms;
      r.outcome = outcome;
      r.note = note;
      r.completedAt = at;
      if (r.status === "cancelled") {
        r.failure = r.failure ?? "cancelled while generating";
        r.text = "";
      } else if (deliverable) {
        r.status = "completed";
        r.text = draft;
        r.failure = null;
      } else {
        r.status = outcome === "stale" ? "cancelled" : "failed";
        r.failure = outcome === "stale" ? "conversation reset during generation" : note || "no draft produced";
        r.text = "";
      }
      if (s.inProgress?.requestId === requestId && s.inProgress.runId === RUN_ID) s.inProgress = null;
      return { result: s, changed: true };
    });
    return toReplyState(final, final.requests[requestId]);
  });
}

/**
 * Explicit delivery acknowledgement.
 * The durable delivery decision is committed first and is authoritative: once it is persisted the
 * reply can never be offered for delivery again, even if the following transcript commit fails. The
 * commit itself is idempotent and keyed on the request identity, so a replay adds nothing.
 */
export async function acknowledgeDelivery(raw: unknown, options: ServiceOptions = {}): Promise<AckResult> {
  const event = parseInboundEvent(raw);
  resolveCreator(event.accountId, event.creatorSlug);
  const key = conversationKey(event);
  const requestId = messageKey(event);
  const at = isoNow(options.now);
  const base = { conversationKey: key, requestId };

  ensureRecovered();

  return withConversationLock(key, async () => {
    reconcileCommits(key, at);
    const before = readState(key).requests[requestId];
    if (!before) return { ...base, status: "not-found" as const };

    // Delivery already confirmed (including a decision whose commit was interrupted): finish the
    // commit if it is outstanding, and never offer the reply again.
    if (before.deliveredAt !== null) {
      const committed = mutateState(key, "ack-commit", (s) => {
        const done = finishCommits(s, at) > 0;
        return { result: done, changed: done };
      });
      return { ...base, status: committed ? ("delivered" as const) : ("already-delivered" as const) };
    }

    // 1. The delivery decision: durable and authoritative.
    const decided = mutateState(key, "ack-decision", (s) => {
      const r = s.requests[requestId];
      if (!r) return { result: "not-found" as const, changed: false };
      if (r.deliveredAt !== null) return { result: "decided" as const, changed: false };
      if (r.status === "cancelled") return { result: "cancelled" as const, changed: false };
      if (r.status === "interrupted") return { result: "interrupted" as const, changed: false };
      if (r.status === "failed") return { result: "not-ready" as const, changed: false };
      if (r.status === "queued" || r.status === "in_progress") return { result: "in-progress" as const, changed: false };
      if (s.epoch !== r.epoch) {
        r.status = "cancelled";
        r.failure = "stale: conversation was reset after this draft was generated";
        r.text = "";
        return { result: "stale" as const, changed: true };
      }
      r.status = "delivered";
      r.deliveredAt = at;
      return { result: "decided" as const, changed: true };
    });
    if (decided !== "decided") return { ...base, status: decided };

    // 2. The transcript commit, plus its evidence. Idempotent, identity-based.
    mutateState(key, "ack-commit", (s) => ({ result: undefined, changed: finishCommits(s, at) > 0 }));
    return { ...base, status: "delivered" as const };
  });
}

/**
 * Explicit cancellation. Not queued behind the conversation lock: cancelling must be able to land
 * while a generation is running or while a request is waiting, and the running turn re-reads the
 * journal before finalising. Confirmed delivery is retained and cannot be cancelled.
 */
/**
 * Read one request's durable state without admitting, generating, acknowledging or changing anything.
 * Identity and creator binding are checked exactly as for a write, so an unknown account or a
 * conflicting creator claim is rejected here too. Returns null when the conversation or request is
 * unknown; a damaged snapshot raises StoreError. Deliberately does not run startup recovery, so a
 * status read can never mutate state.
 */
export async function readReplyState(raw: unknown, options: ServiceOptions = {}): Promise<ReplyState | null> {
  void options; // no seams apply to a read-only lookup
  const event = parseInboundEvent(raw);
  resolveCreator(event.accountId, event.creatorSlug);
  const state = readState(conversationKey(event));
  const record = state.requests[messageKey(event)];
  return record ? toReplyState(state, record) : null;
}

export async function cancelRequest(raw: unknown, options: ServiceOptions = {}): Promise<CancelResult> {
  const event = parseInboundEvent(raw);
  resolveCreator(event.accountId, event.creatorSlug);
  const key = conversationKey(event);
  const requestId = messageKey(event);
  const at = isoNow(options.now);

  ensureRecovered();

  return mutateState<CancelResult>(key, "cancel", (s) => {
    const r = s.requests[requestId];
    const base = { conversationKey: key, requestId };
    if (!r) return { result: { ...base, status: "not-found" as const }, changed: false };
    if (r.deliveredAt !== null) return { result: { ...base, status: "already-delivered" as const }, changed: false };
    if (r.status === "cancelled") return { result: { ...base, status: "already-cancelled" as const }, changed: false };
    r.status = "cancelled";
    r.failure = "cancelled by operator";
    r.text = "";
    r.completedAt = r.completedAt ?? at;
    releaseClaimFor(s, requestId);
    return { result: { ...base, status: "cancelled" as const }, changed: true };
  });
}

/**
 * Reset one conversation: clear the transcript, bump the revision and cancel every queued, running or
 * undelivered request. Immediate rather than queued, so a reset invalidates work that is running or
 * waiting right now. Confirmed-delivery evidence is kept, so a reset can never cause a redelivery.
 */
export async function resetConversation(raw: unknown, options: ServiceOptions = {}): Promise<ResetResult> {
  const event = parseInboundEvent(raw);
  resolveCreator(event.accountId, event.creatorSlug);
  const key = conversationKey(event);
  const at = isoNow(options.now);

  ensureRecovered();

  return mutateState(key, "reset", (s) => {
    s.epoch += 1;
    s.transcript = [];
    s.sent = [];
    let cancelled = 0;
    for (const r of Object.values(s.requests)) {
      if (r.deliveredAt !== null) continue; // confirmed delivery evidence is retained
      if (r.status === "queued" || r.status === "in_progress" || r.status === "completed") {
        r.status = "cancelled";
        r.failure = "conversation reset";
        r.text = "";
        r.completedAt = r.completedAt ?? at;
        releaseClaimFor(s, r.requestId);
        cancelled++;
      }
    }
    return { result: { conversationKey: key, epoch: s.epoch, cancelled }, changed: true };
  });
}
