/**
 * Durable bridge state for the OnlyFans channel (Stage 1B part 1, repaired storage).
 *
 * One conversation is a chain of immutable "generation" files:
 *
 *   data/<creator>/bridge/<conversationKey>.<seq>.json
 *
 * Each file is a complete committed snapshot:
 *
 *   <seq>\n<sha256 of the payload, first 32 hex chars>\n<pretty JSON payload>
 *
 * Design rules and why:
 * - A write NEVER modifies or replaces a file that already holds committed state. It creates the next
 *   sequence number with the exclusive "wx" flag. A failed or partial write can therefore only leave an
 *   incomplete new file behind, never damage the previous committed snapshot. The store removes the
 *   file it just created when its own write throws, so normal operation continues; if the process dies
 *   mid-write the incomplete file stays and reads fail closed with the committed files still intact.
 * - The newest existing generation is authoritative. It is fully validated (header, checksum, schema
 *   and cross-references) before use; any defect raises StoreError with the file path, and the bytes
 *   are left untouched for inspection. There is no implicit fall back to an older generation, because
 *   silently serving stale state is how dedupe and delivery guarantees get lost. Older generations are
 *   retained (the newest two) for inspection and manual rollback.
 * - The transcript and the conversation revision live in the same snapshot as the request journal, so
 *   a history mutation and its commit evidence land in one write. That is what makes acknowledgement
 *   idempotent without comparing reply text.
 * - A missing file (no generations at all) is a new conversation. A damaged file is an error. They are
 *   deliberately different cases.
 *
 * Single process, single writer: every operation is synchronous, so a read-modify-write inside one
 * call cannot interleave with another caller in the same process. Cross-process leases are Stage 1C.
 */
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";
import type { Msg } from "../memory.js";
import { messageKey } from "./identity.js";

export const STORE_VERSION = 2;

/** Lifecycle of one accepted fan message. Terminal: delivered, cancelled, interrupted, failed. */
export type RequestStatus = "queued" | "in_progress" | "completed" | "delivered" | "cancelled" | "interrupted" | "failed";
export type RequestOutcome = "ok" | "blocked" | "failed" | "stale" | "unsupported";

export type RequestRecord = {
  version: number;
  requestId: string;
  conversationKey: string;
  accountId: string;
  fanId: string;
  messageId: string;
  /** Process that admitted the request, so a queue left by a dead process is recognisable. */
  runId: string;
  /** Conversation revision at admission. Re-checked before the model runs. */
  admittedEpoch: number;
  /** Conversation revision the draft was generated against. */
  epoch: number;
  status: RequestStatus;
  outcome: RequestOutcome | null;
  text: string;
  note: string;
  failure: string | null;
  provider: string;
  tokensIn: number;
  tokensOut: number;
  cost: number;
  ms: number;
  attempts: number;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  /** Durable delivery decision. Once set the reply is never deliverable again. */
  deliveredAt: string | null;
  /** Evidence that this request's reply was written into the transcript (identity, never text match). */
  committedAt: string | null;
};

export type InProgressClaim = { requestId: string; runId: string; startedAt: string };

export type ConversationState = {
  version: number;
  conversationKey: string;
  /** Conversation revision. A reset bumps it; older drafts can never be delivered. */
  epoch: number;
  /** The transcript the model reads. Committed replies appear here; drafts do not. */
  transcript: Msg[];
  sent: string[];
  owned: string[];
  inProgress: InProgressClaim | null;
  requests: Record<string, RequestRecord>;
  /** Label of the write that produced this generation (write-order evidence). */
  lastMutation: string;
};

export class StoreError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "StoreError";
  }
}

const SAFE_KEY = /^[A-Za-z0-9_-]+$/;
const FILE_RE = /^([A-Za-z0-9_-]+)\.(\d+)\.json$/;
const LEGACY_FILE_RE = /^([A-Za-z0-9_-]+)\.json$/;
const STATUSES: RequestStatus[] = ["queued", "in_progress", "completed", "delivered", "cancelled", "interrupted", "failed"];
const OUTCOMES: RequestOutcome[] = ["ok", "blocked", "failed", "stale", "unsupported"];

/** Test-only fault hook, called immediately before a generation file is written. Throwing aborts that
 *  write exactly as a real write failure would, which lets the harness exercise the failure boundaries. */
let writeFault: ((file: string, label: string) => void) | null = null;
export function setWriteFaultForTest(fn: ((file: string, label: string) => void) | null): void {
  writeFault = fn;
}

function assertSafeKey(key: string): void {
  if (!SAFE_KEY.test(key) || key === "." || key === "..") {
    throw new StoreError(`refusing to build a state path from key ${JSON.stringify(key)}`);
  }
}

export function storeDir(): string {
  return path.join(config.dataDir, config.girl, "bridge");
}

function rejectLegacyFile(name: string): never {
  throw new StoreError(`${path.join(storeDir(), name)}: migration required for the legacy bridge journal; original bytes were left untouched`);
}

/** Generation files for one conversation, newest first. */
export function stateFilesFor(conversationKey: string): Array<{ file: string; seq: number }> {
  assertSafeKey(conversationKey);
  let names: string[];
  try {
    names = fs.readdirSync(storeDir());
  } catch (e: unknown) {
    if ((e as NodeJS.ErrnoException)?.code === "ENOENT") return [];
    throw new StoreError(`cannot list bridge state: ${String((e as Error)?.message ?? e)}`);
  }
  const out: Array<{ file: string; seq: number }> = [];
  for (const name of names) {
    // A mixed old/new directory is ambiguous too: never silently choose one delivery ledger.
    if (name === `${conversationKey}.json`) rejectLegacyFile(name);
    const m = FILE_RE.exec(name);
    if (!m || m[1] !== conversationKey) continue;
    out.push({ file: path.join(storeDir(), name), seq: Number(m[2]) });
  }
  return out.sort((a, b) => b.seq - a.seq);
}

/** Conversation keys that have at least one generation file. Used by startup recovery. */
export function listConversationKeys(): string[] {
  let names: string[];
  try {
    names = fs.readdirSync(storeDir());
  } catch (e: unknown) {
    if ((e as NodeJS.ErrnoException)?.code === "ENOENT") return [];
    throw new StoreError(`cannot list bridge state: ${String((e as Error)?.message ?? e)}`);
  }
  const keys = new Set<string>();
  for (const name of names) {
    // Complete discovery before recovery mutates anything. Version 1 used unsuffixed filenames.
    if (LEGACY_FILE_RE.test(name)) rejectLegacyFile(name);
    const m = FILE_RE.exec(name);
    if (m) keys.add(m[1]);
  }
  return [...keys].sort();
}

export function emptyConversationState(conversationKey: string): ConversationState {
  return {
    version: STORE_VERSION,
    conversationKey,
    epoch: 0,
    transcript: [],
    sent: [],
    owned: [],
    inProgress: null,
    requests: {},
    lastMutation: "new",
  };
}

const digest = (payload: string) => crypto.createHash("sha256").update(payload, "utf8").digest("hex").slice(0, 32);

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);
const isStr = (v: unknown): v is string => typeof v === "string";
const isName = (v: unknown): v is string => typeof v === "string" && v.trim().length > 0;
// Journal timestamps are generated internally with toISOString, unlike external event timestamps.
const isStamp = (v: unknown): v is string => {
  if (typeof v !== "string") return false;
  const millis = Date.parse(v);
  return Number.isFinite(millis) && new Date(millis).toISOString() === v;
};
const isStampOrNull = (v: unknown): v is string | null => v === null || isStamp(v);
const isInt = (v: unknown): v is number => typeof v === "number" && Number.isSafeInteger(v) && v >= 0;
const isNum = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v) && v >= 0;

function bad(file: string, detail: string): never {
  throw new StoreError(`${file}: ${detail}`);
}

function validateRecord(value: unknown, key: string, mapKey: string, epoch: number, file: string): RequestRecord {
  if (!isRecord(value)) bad(file, `request ${mapKey} is not an object`);
  if (value.version !== STORE_VERSION) bad(file, `request ${mapKey} has version ${String(value.version)}`);
  if (value.requestId !== mapKey) bad(file, `request ${mapKey} records requestId ${String(value.requestId)}`);
  if (value.conversationKey !== key) bad(file, `request ${mapKey} records a different conversation key`);
  for (const f of ["accountId", "fanId", "messageId", "runId", "provider"]) {
    if (!isName(value[f])) bad(file, `request ${mapKey} has an invalid ${f}`);
  }
  if (messageKey({ channel: "onlyfans", accountId: value.accountId as string, fanId: value.fanId as string, messageId: value.messageId as string }) !== mapKey) {
    bad(file, `request ${mapKey} does not match its account/fan/message identity`);
  }
  if (!isStr(value.text) || !isStr(value.note)) bad(file, `request ${mapKey} has a non-string text or note`);
  if (!(value.failure === null || isStr(value.failure))) bad(file, `request ${mapKey} has an invalid failure`);
  if (!STATUSES.includes(value.status as RequestStatus)) bad(file, `request ${mapKey} has status ${String(value.status)}`);
  if (!(value.outcome === null || OUTCOMES.includes(value.outcome as RequestOutcome))) bad(file, `request ${mapKey} has outcome ${String(value.outcome)}`);
  if (!isInt(value.admittedEpoch) || !isInt(value.epoch)) bad(file, `request ${mapKey} has an invalid epoch`);
  if (value.admittedEpoch !== value.epoch || value.epoch > epoch) bad(file, `request ${mapKey} has inconsistent revisions`);
  for (const f of ["tokensIn", "tokensOut", "attempts"]) {
    if (!isInt(value[f])) bad(file, `request ${mapKey} has an invalid ${f}`);
  }
  for (const f of ["cost", "ms"]) {
    if (!isNum(value[f])) bad(file, `request ${mapKey} has an invalid ${f}`);
  }
  if (!isStamp(value.createdAt)) bad(file, `request ${mapKey} has an invalid createdAt`);
  for (const f of ["startedAt", "completedAt", "deliveredAt", "committedAt"]) {
    if (!isStampOrNull(value[f])) bad(file, `request ${mapKey} has an invalid ${f}`);
  }
  if ((value.status === "delivered") !== (value.deliveredAt !== null) || (value.committedAt !== null && value.deliveredAt === null)) {
    bad(file, `request ${mapKey} has inconsistent delivery evidence`);
  }

  // These relationships also apply to proposed writes, so invalid transitions cannot poison storage.
  const active = value.status === "queued" || value.status === "in_progress" || value.status === "completed";
  if (active && value.epoch !== epoch) bad(file, `active request ${mapKey} belongs to an old revision`);
  if (value.status === "queued" || value.status === "in_progress") {
    if (value.outcome !== null || value.text !== "" || value.failure !== null || value.completedAt !== null) {
      bad(file, `unfinished request ${mapKey} already has a result`);
    }
    if ((value.status === "queued") !== (value.startedAt === null)) bad(file, `request ${mapKey} has inconsistent start evidence`);
  } else {
    if (value.completedAt === null) bad(file, `terminal or completed request ${mapKey} has no completion timestamp`);
    if (value.status === "completed" || value.status === "delivered") {
      if (value.startedAt === null || (value.outcome !== "ok" && value.outcome !== "blocked") || !isName(value.text) || value.failure !== null) {
        bad(file, `request ${mapKey} has an invalid deliverable result`);
      }
    } else {
      if (value.text !== "" || !isName(value.failure)) bad(file, `request ${mapKey} has an invalid terminal failure`);
      if (value.status === "failed" && (value.startedAt === null || value.outcome === null)) bad(file, `failed request ${mapKey} has no generation outcome`);
    }
  }
  return value as unknown as RequestRecord;
}

/** Validate a complete snapshot, including cross-references. Anything unexpected is an error. */
export function validateConversationState(value: unknown, key: string, file: string): ConversationState {
  if (!isRecord(value)) bad(file, "state is not an object");
  if (value.version !== STORE_VERSION) bad(file, `unsupported state version ${String(value.version)}; expected ${STORE_VERSION}`);
  if (value.conversationKey !== key) bad(file, "state records a different conversation key");
  if (!isInt(value.epoch)) bad(file, "epoch is not a non-negative integer");
  if (!isStr(value.lastMutation)) bad(file, "lastMutation is missing");

  if (!Array.isArray(value.transcript)) bad(file, "transcript is not an array");
  for (const entry of value.transcript) {
    if (!isRecord(entry) || (entry.role !== "user" && entry.role !== "assistant") || !isStr(entry.content)) {
      bad(file, "a transcript entry is malformed");
    }
  }
  for (const f of ["sent", "owned"]) {
    const list = value[f];
    if (!Array.isArray(list) || !list.every(isStr)) bad(file, `${f} is not a string array`);
  }
  if (!isRecord(value.requests)) bad(file, "requests is not an object map");

  const requests: Record<string, RequestRecord> = {};
  for (const [id, rec] of Object.entries(value.requests)) requests[id] = validateRecord(rec, key, id, value.epoch, file);

  if (value.inProgress !== null) {
    const claim = value.inProgress;
    if (!isRecord(claim) || !isName(claim.requestId) || !isName(claim.runId) || !isStamp(claim.startedAt)) {
      bad(file, "the in-progress claim is malformed");
    }
    const target = requests[claim.requestId];
    if (!target) bad(file, `the in-progress claim references unknown request ${claim.requestId}`);
    if (target.status !== "in_progress") bad(file, `the in-progress claim references ${claim.requestId}, which is ${target.status}`);
    if (claim.runId !== target.runId || claim.startedAt !== target.startedAt) bad(file, "the in-progress claim contradicts its request ownership or start time");
  }

  return {
    version: STORE_VERSION,
    conversationKey: key,
    epoch: value.epoch,
    transcript: value.transcript as Msg[],
    sent: value.sent as string[],
    owned: value.owned as string[],
    inProgress: value.inProgress as InProgressClaim | null,
    requests,
    lastMutation: value.lastMutation,
  };
}

/**
 * Read the authoritative snapshot. A conversation with no generation files is new; a conversation
 * whose newest snapshot is unreadable, damaged or schema-invalid raises StoreError and its bytes are
 * left exactly as they are.
 */
export function readState(conversationKey: string): ConversationState {
  const files = stateFilesFor(conversationKey);
  if (!files.length) return emptyConversationState(conversationKey);
  const { file, seq } = files[0]; // newest generation is authoritative; no implicit fallback

  let raw: string;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch (e: unknown) {
    throw new StoreError(`${file}: cannot read bridge state: ${String((e as Error)?.message ?? e)}`);
  }
  const first = raw.indexOf("\n");
  const second = first < 0 ? -1 : raw.indexOf("\n", first + 1);
  if (first < 0 || second < 0) throw new StoreError(`${file}: journal header is truncated`);

  const seqText = raw.slice(0, first);
  const checksum = raw.slice(first + 1, second);
  const payload = raw.slice(second + 1);
  if (Number(seqText) !== seq) throw new StoreError(`${file}: journal header does not match its file name`);
  if (checksum !== digest(payload)) throw new StoreError(`${file}: journal checksum mismatch (incomplete or damaged write)`);

  let parsed: unknown;
  try {
    parsed = JSON.parse(payload);
  } catch {
    throw new StoreError(`${file}: journal payload is not valid JSON`);
  }
  return validateConversationState(parsed, conversationKey, file);
}

/** Keep the newest two generations so a bad snapshot can be inspected or rolled back by hand. */
function pruneGenerations(conversationKey: string, keepSeq: number): void {
  const others = stateFilesFor(conversationKey).filter((f) => f.seq !== keepSeq);
  for (const old of others.slice(1)) {
    try {
      fs.rmSync(old.file, { force: true });
    } catch {
      /* keeping an extra file is harmless */
    }
  }
}

/**
 * Commit a new snapshot as the next generation. Never touches an existing file: it opens a new
 * sequence number exclusively, writes and fsyncs. On failure the file it created is removed (it never
 * held committed state) and the previous snapshot stays authoritative.
 */
export function writeState(state: ConversationState, label: string): void {
  assertSafeKey(state.conversationKey);
  const dir = storeDir();

  const seq = (stateFilesFor(state.conversationKey)[0]?.seq ?? 0) + 1;
  const file = path.join(dir, `${state.conversationKey}.${seq}.json`);
  // Check exactly the proposed snapshot before creating any new file or reporting a mutation's result.
  const validated = validateConversationState({ ...state, lastMutation: label }, state.conversationKey, file);
  const payload = JSON.stringify(validated, null, 2);
  const body = `${seq}\n${digest(payload)}\n${payload}`;

  writeFault?.(file, label);
  fs.mkdirSync(dir, { recursive: true });

  let fd: number | null = null;
  try {
    fd = fs.openSync(file, "wx");
    try {
      fs.writeFileSync(fd, body);
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
      fd = null;
    }
  } catch (e: unknown) {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch {
        /* already closed */
      }
    }
    try {
      fs.rmSync(file, { force: true });
    } catch {
      /* leave it: reads then fail closed rather than serving a partial snapshot */
    }
    throw new StoreError(`cannot write bridge state for ${state.conversationKey} (${label}): ${String((e as Error)?.message ?? e)}`);
  }
  pruneGenerations(state.conversationKey, seq);
}

/**
 * Read, change and commit one conversation in a single synchronous step. The read happens inside the
 * call, so concurrent callers in this process can never overwrite each other's changes.
 */
export function mutateState<T>(conversationKey: string, label: string, fn: (state: ConversationState) => { result: T; changed: boolean }): T {
  const state = readState(conversationKey);
  const { result, changed } = fn(state);
  if (changed) writeState(state, label);
  return result;
}

/** A fresh request record in the admitted (queued) state, before any generation. */
export function newRequestRecord(input: {
  requestId: string;
  conversationKey: string;
  accountId: string;
  fanId: string;
  messageId: string;
  runId: string;
  epoch: number;
  createdAt: string;
}): RequestRecord {
  return {
    version: STORE_VERSION,
    requestId: input.requestId,
    conversationKey: input.conversationKey,
    accountId: input.accountId,
    fanId: input.fanId,
    messageId: input.messageId,
    runId: input.runId,
    admittedEpoch: input.epoch,
    epoch: input.epoch,
    status: "queued",
    outcome: null,
    text: "",
    note: "",
    failure: null,
    provider: "none",
    tokensIn: 0,
    tokensOut: 0,
    cost: 0,
    ms: 0,
    attempts: 0,
    createdAt: input.createdAt,
    startedAt: null,
    completedAt: null,
    deliveredAt: null,
    committedAt: null,
  };
}
