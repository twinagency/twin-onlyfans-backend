/**
 * Text-only bridge turn: validate an inbound event, map it to a creator and a safe conversation
 * key, run the existing turn engine, and return a typed draft.
 *
 * STAGE 1A limits, deliberately:
 * - Empty media catalogue. Nothing is offered, downloaded or dispatched.
 * - Nothing is sent and no delivery marker is written. This wrapper has no transport and no
 *   acknowledgement state; it only produces a draft.
 * - It is NOT yet safe for live retry. The current `runTurn` eagerly saves generated assistant
 *   history before any transport exists, so a retry could double-append history. Stage 1B must
 *   add the durable turn/result journal and split generated from delivered before a production
 *   caller uses this. Do not wire this into a live sender yet.
 * - No extra retry loop: model attempts stay inside llm.complete's existing bounded retry.
 */
import { getGirl, type Girl } from "../girls/index.js";
import type { Item } from "../media.js";
import { runTurn as realRunTurn, type TurnResult } from "../turn.js";
import { conversationKey, messageKey, resolveCreator } from "./identity.js";
import { CHANNEL_SCHEMA_VERSION, ChannelError, parseInboundEvent, type DraftOutcome, type DraftResult } from "./types.js";

export type RunTurnFn = (girl: Girl, catalogue: Item[], chatId: number | string, fanText: string) => Promise<TurnResult>;

/** Offline/test seam. Production callers use the defaults. */
export type TextTurnOptions = {
  girl?: Girl; // neutral fixture creator in tests; defaults to the configured creator
  catalogue?: Item[]; // always empty in Stage 1A unless a test injects one
  runTurn?: RunTurnFn; // defaults to the real turn engine
  now?: () => Date;
};

const OK_NOTES = new Set(["ok", "ok+tag", "ok+asked"]);

/**
 * Map the turn engine's internal note to an explicit transport outcome.
 * Shared with the durable service so both layers agree on what a result means.
 */
export function classifyTurn(r: TurnResult): { outcome: DraftOutcome; note: string } {
  if (r.media) return { outcome: "unsupported", note: "media-unsupported" }; // text-only stage
  if (r.note === "reset-during-turn") return { outcome: "stale", note: r.note };
  if (r.note.startsWith("blocked")) return { outcome: "blocked", note: r.note };
  if (r.note === "ai-failed") return { outcome: "failed", note: r.note };
  if (OK_NOTES.has(r.note)) return { outcome: "ok", note: r.note };
  return { outcome: "unsupported", note: r.note };
}

/**
 * Run one inbound text through the real turn engine and return a draft.
 * Throws ChannelError (bad request / unknown account / creator mismatch) before any model call.
 */
export async function runTextTurn(raw: unknown, options: TextTurnOptions = {}): Promise<DraftResult> {
  const event = parseInboundEvent(raw);
  const creator = resolveCreator(event.accountId, event.creatorSlug);

  const girl = options.girl ?? getGirl(creator);
  if (girl.slug !== creator) {
    throw new ChannelError("creator-mismatch", `turn engine would run as ${JSON.stringify(girl.slug)} but the account is bound to ${JSON.stringify(creator)}`);
  }

  const catalogue = options.catalogue ?? [];
  const runTurn = options.runTurn ?? realRunTurn;
  const now = options.now ?? (() => new Date());

  // Opaque, filesystem-safe, conversation-scoped memory key. Same conversation => same key,
  // so successive messages share history; a new message id does not start a new conversation.
  const key = conversationKey(event);
  const r = await runTurn(girl, catalogue, key, event.text);
  const { outcome, note } = classifyTurn(r);

  return {
    schemaVersion: CHANNEL_SCHEMA_VERSION,
    requestId: messageKey(event),
    channel: event.channel,
    outcome,
    text: outcome === "ok" ? r.bubbles.join(" ").trim() : "",
    media: null,
    provider: r.provider,
    tokensIn: r.tokensIn,
    tokensOut: r.tokensOut,
    cost: r.cost,
    ms: r.ms,
    note,
    createdAt: now().toISOString(),
  };
}
