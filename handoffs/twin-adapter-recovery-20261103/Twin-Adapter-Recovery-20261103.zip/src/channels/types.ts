/**
 * Versioned transport contract for the Twin V2 <-> OnlyFans (Fastt) bridge.
 *
 * STAGE 1A: offline foundation only. This module defines and validates the wire shape.
 * It performs no network, storage, dispatch or delivery work.
 *
 * Design rules (see docs/onlyfans/IMPLEMENTATION_PLAN.md, "Contract and state rules"):
 * - Every identifier is a *string* at the boundary. Provider IDs can exceed
 *   Number.MAX_SAFE_INTEGER, so they are never coerced with Number()/parseInt().
 * - An unknown channel, an old/unknown schema version, an outbound (creator-side) event,
 *   a blank/oversized field or a malformed identifier is rejected before any model or
 *   storage work happens.
 * - Identifiers must be well-formed Unicode. An unpaired UTF-16 surrogate is rejected rather
 *   than replaced, because UTF-8 encoding would fold distinct malformed ids onto the same
 *   replacement character and make two different conversations hash to one memory key.
 * - Timestamps must be a timezone-qualified ISO-8601 subset (see readTimestamp). Valid values
 *   are normalised to canonical UTC so stored timestamps are comparable across machines.
 * - Field limits are explicit (REQUEST_LIMITS) and documented in PROGRESS.md.
 */

export const CHANNEL_SCHEMA_VERSION = 1;

/** Channels this process knows how to bind. Telegram keeps its own existing path and is not routed here. */
export const SUPPORTED_CHANNELS = ["onlyfans"] as const;
export type ChannelName = (typeof SUPPORTED_CHANNELS)[number];

/** Only a fan -> creator message is a turn. Creator echoes, tips and reactions are rejected here. */
export const SUPPORTED_DIRECTIONS = ["inbound"] as const;
export type Direction = (typeof SUPPORTED_DIRECTIONS)[number];

/**
 * Explicit, documented request limits. All lengths are characters unless noted.
 * These are deliberately generous for one fan text and tight enough to refuse junk.
 */
export const REQUEST_LIMITS = {
  schemaVersion: 8, // "1" and any future small integer
  id: 256, // one identifier: account, creator, conversation, fan, message
  timestamp: 40, // ISO-8601, e.g. 2026-10-15T04:05:06.789Z
  text: 4000, // one inbound fan message
  totalBytes: 16 * 1024, // the whole serialized request object
} as const;

/** Validated inbound event. Only these fields are read; unknown extra keys are ignored. */
export type InboundEvent = {
  schemaVersion: number;
  channel: ChannelName;
  accountId: string;
  creatorSlug: string;
  conversationId: string;
  fanId: string;
  messageId: string;
  occurredAt: string;
  receivedAt: string;
  direction: Direction;
  text: string;
};

/**
 * Outcome of one text turn.
 * - ok          a draft was produced (text only in Stage 1A)
 * - blocked     the in/out safety filter refused the message
 * - failed      the model failed within its existing bounded retry limit
 * - stale       the conversation was reset while the turn was running; drop it
 * - unsupported a result this stage cannot render (notably media); surfaced for review
 */
export type DraftOutcome = "ok" | "blocked" | "failed" | "stale" | "unsupported";

/** Versioned draft returned to a future caller. Stage 1A never dispatches or marks delivery. */
export type DraftResult = {
  schemaVersion: number;
  requestId: string; // opaque identity of the source message (see identity.messageKey)
  channel: ChannelName;
  outcome: DraftOutcome;
  text: string; // the draft; "" for every outcome other than ok
  media: null; // Stage 1A is text-only, always null
  provider: string;
  tokensIn: number;
  tokensOut: number;
  cost: number;
  ms: number;
  note: string; // short internal status, mirrors turn.ts notes
  createdAt: string; // ISO-8601
};

export type ChannelErrorCode =
  | "bad-request"
  | "unsupported-version"
  | "unsupported-channel"
  | "unsupported-direction"
  | "missing-field"
  | "blank-field"
  | "malformed-field"
  | "oversized-field"
  | "unknown-account"
  | "creator-mismatch";

/** Typed rejection. A future HTTP layer maps this to a 4xx; nothing is retried on it. */
export class ChannelError extends Error {
  readonly code: ChannelErrorCode;
  constructor(code: ChannelErrorCode, message: string) {
    super(`${code}: ${message}`);
    this.name = "ChannelError";
    this.code = code;
  }
}

const ID_FORBIDDEN = /[\/\\\u0000-\u001F\u007F]/; // path separators and control characters

/**
 * True when the string contains an unpaired UTF-16 surrogate (ill-formed Unicode).
 * Node's UTF-8 encoder collapses every unpaired surrogate to U+FFFD, so two distinct malformed
 * identifiers would otherwise produce the same hash. Written as an explicit scan because
 * String.prototype.isWellFormed is newer than this project's TypeScript target.
 */
function hasUnpairedSurrogate(v: string): boolean {
  for (let i = 0; i < v.length; i++) {
    const c = v.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff) {
      const next = v.charCodeAt(i + 1); // NaN past the end, and every comparison with NaN is false
      if (!(next >= 0xdc00 && next <= 0xdfff)) return true; // high surrogate without a low half
      i++; // valid pair: skip the low half
    } else if (c >= 0xdc00 && c <= 0xdfff) {
      return true; // low surrogate without a preceding high half
    }
  }
  return false;
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function readEnum<T extends string>(o: Record<string, unknown>, field: string, allowed: readonly T[], unsupported: ChannelErrorCode): T {
  const v = o[field];
  if (v === undefined || v === null) throw new ChannelError("missing-field", `${field} is required`);
  if (typeof v !== "string") throw new ChannelError("malformed-field", `${field} must be a string`);
  if (!(allowed as readonly string[]).includes(v)) throw new ChannelError(unsupported, `${field} ${JSON.stringify(v)} is not supported`);
  return v as T;
}

/**
 * One identifier. Rejects non-strings, blanks, oversized values, control characters, separators,
 * traversal dots and ill-formed Unicode (unpaired surrogates). Valid non-BMP characters survive.
 */
function readId(o: Record<string, unknown>, field: string): string {
  const v = o[field];
  if (v === undefined || v === null) throw new ChannelError("missing-field", `${field} is required`);
  if (typeof v !== "string") {
    throw new ChannelError("malformed-field", `${field} must be a string; provider ids are never coerced through Number`);
  }
  if (v.trim().length === 0) throw new ChannelError("blank-field", `${field} is blank`);
  if (v.length > REQUEST_LIMITS.id) throw new ChannelError("oversized-field", `${field} exceeds ${REQUEST_LIMITS.id} characters`);
  if (v !== v.trim()) throw new ChannelError("malformed-field", `${field} has leading or trailing whitespace`);
  if (v === "." || v === "..") throw new ChannelError("malformed-field", `${field} is a traversal value`);
  if (ID_FORBIDDEN.test(v)) throw new ChannelError("malformed-field", `${field} contains a path separator or control character`);
  if (hasUnpairedSurrogate(v)) throw new ChannelError("malformed-field", `${field} contains an unpaired UTF-16 surrogate`);
  return v;
}

/**
 * Supported timestamp subset, in the RFC 3339 shape:
 *
 *   YYYY-MM-DDTHH:MM:SS[.fraction]Z          UTC
 *   YYYY-MM-DDTHH:MM:SS[.fraction](+|-)HH:MM  explicit offset
 *
 * A timezone is mandatory. Rejected: numeric strings, date-only values, missing or partial
 * timezones, whitespace padding, non-existent calendar dates (including invalid leap days such as
 * 2026-02-29), rollover dates such as 2026-02-30, and out-of-range time/offset components.
 * Fractional seconds are accepted and truncated to milliseconds. Valid values are normalised to
 * canonical UTC ("...Z"), so stored timestamps compare directly regardless of the sender's zone.
 */
const TIMESTAMP_RE = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})$/;
const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

const isLeapYear = (year: number) => (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
const daysInMonth = (year: number, month: number) => (month === 2 && isLeapYear(year) ? 29 : DAYS_IN_MONTH[month - 1]);

/** Parse the subset above into a Date, or null when the value is not a valid instant. */
function parseTimestamp(v: string): Date | null {
  const m = TIMESTAMP_RE.exec(v);
  if (!m) return null;
  const year = Number(m[1]), month = Number(m[2]), day = Number(m[3]);
  const hour = Number(m[4]), minute = Number(m[5]), second = Number(m[6]);
  const zone = m[8];

  if (month < 1 || month > 12) return null;
  if (day < 1 || day > daysInMonth(year, month)) return null; // real calendar date, no rollover
  if (hour > 23 || minute > 59 || second > 59) return null;

  let offsetMinutes = 0;
  if (zone !== "Z") {
    const sign = zone[0] === "-" ? -1 : 1;
    const offHour = Number(zone.slice(1, 3)), offMinute = Number(zone.slice(4, 6));
    if (offHour > 23 || offMinute > 59) return null;
    offsetMinutes = sign * (offHour * 60 + offMinute);
  }
  const millis = m[7] ? Number((m[7] + "000").slice(0, 3)) : 0;

  // Build from validated components. setUTCFullYear avoids Date.UTC's two-digit year mapping.
  const d = new Date(0);
  d.setUTCFullYear(year, month - 1, day);
  d.setUTCHours(hour, minute, second, millis);
  return new Date(d.getTime() - offsetMinutes * 60_000);
}

function readTimestamp(o: Record<string, unknown>, field: string): string {
  const v = o[field];
  if (v === undefined || v === null) throw new ChannelError("missing-field", `${field} is required`);
  if (typeof v !== "string") throw new ChannelError("malformed-field", `${field} must be a string`);
  if (v.trim().length === 0) throw new ChannelError("blank-field", `${field} is blank`);
  if (v.length > REQUEST_LIMITS.timestamp) throw new ChannelError("oversized-field", `${field} exceeds ${REQUEST_LIMITS.timestamp} characters`);
  if (v !== v.trim()) throw new ChannelError("malformed-field", `${field} has leading or trailing whitespace`);

  const d = parseTimestamp(v);
  if (!d) {
    throw new ChannelError("malformed-field", `${field} must be a timezone-qualified ISO-8601 timestamp such as 2026-10-15T04:00:00Z`);
  }
  const iso = d.toISOString();
  if (!/^\d{4}-/.test(iso)) {
    throw new ChannelError("malformed-field", `${field} normalises outside the supported year range`);
  }
  return iso;
}

function readText(o: Record<string, unknown>): string {
  const v = o["text"];
  if (v === undefined || v === null) throw new ChannelError("missing-field", "text is required");
  if (typeof v !== "string") throw new ChannelError("malformed-field", "text must be a string");
  if (v.trim().length === 0) throw new ChannelError("blank-field", "text is blank");
  if (v.length > REQUEST_LIMITS.text) throw new ChannelError("oversized-field", `text exceeds ${REQUEST_LIMITS.text} characters`);
  return v; // kept verbatim so the model sees exactly what the fan typed
}

/** Validate and normalise an inbound bridge event. Throws ChannelError on anything malformed. */
export function parseInboundEvent(raw: unknown): InboundEvent {
  if (!isRecord(raw)) throw new ChannelError("bad-request", "inbound event must be an object");

  let bytes = 0;
  try {
    bytes = Buffer.byteLength(JSON.stringify(raw), "utf8");
  } catch {
    throw new ChannelError("bad-request", "inbound event is not serializable");
  }
  if (bytes > REQUEST_LIMITS.totalBytes) throw new ChannelError("oversized-field", `request exceeds ${REQUEST_LIMITS.totalBytes} bytes`);

  const ver = raw["schemaVersion"];
  if (ver === undefined || ver === null) throw new ChannelError("missing-field", "schemaVersion is required");
  if (typeof ver !== "number" || !Number.isInteger(ver)) throw new ChannelError("malformed-field", "schemaVersion must be an integer");
  if (ver !== CHANNEL_SCHEMA_VERSION) {
    throw new ChannelError("unsupported-version", `schemaVersion ${ver} is not supported (expected ${CHANNEL_SCHEMA_VERSION})`);
  }

  const channel = readEnum(raw, "channel", SUPPORTED_CHANNELS, "unsupported-channel");
  const direction = readEnum(raw, "direction", SUPPORTED_DIRECTIONS, "unsupported-direction");

  return {
    schemaVersion: ver,
    channel,
    direction,
    accountId: readId(raw, "accountId"),
    creatorSlug: readId(raw, "creatorSlug"),
    conversationId: readId(raw, "conversationId"),
    fanId: readId(raw, "fanId"),
    messageId: readId(raw, "messageId"),
    occurredAt: readTimestamp(raw, "occurredAt"),
    receivedAt: readTimestamp(raw, "receivedAt"),
    text: readText(raw),
  };
}
