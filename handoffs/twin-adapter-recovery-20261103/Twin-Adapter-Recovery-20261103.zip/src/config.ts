import net from "node:net";
// Node happy-eyeballs times out to api.telegram.org on this machine; curl works, so force plain connects.
net.setDefaultAutoSelectFamily(false);
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// Minimal .env loader (no deps). Real env vars win over the file.
function loadEnv() {
  const p = path.join(ROOT, ".env");
  if (!fs.existsSync(p)) return;
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    const v = m[2].replace(/^["']|["']$/g, "");
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadEnv();

// Model settings are fixed on purpose: one pinned model, one pinned provider list, no dials.
export const config = {
  girl: process.env.GIRL ?? "riley",
  openrouterKey: process.env.OPENROUTER_API_KEY ?? "",
  telegramToken: process.env.TELEGRAM_BOT_TOKEN ?? "",
  supabaseUrl: process.env.SUPABASE_URL ?? "",
  supabaseKey: process.env.SUPABASE_SERVICE_KEY ?? "",
  model: "deepseek/deepseek-v4.1-flash",
  providerOrder: ["deepinfra/fp8", "together"],
  temperature: 0.9,
  topP: 0.95,
  frequencyPenalty: 0.2,
  presencePenalty: 0.1,
  maxTokens: 400,
  historyLimit: 30, // messages kept per fan (user + assistant)
  mergeMs: 7000, // double-message wait: replies only after the fan has been quiet this long, so 2-3 quick texts get one answer
  dataDir: path.join(ROOT, "data"),
  logDir: path.join(ROOT, "logs"),
};
