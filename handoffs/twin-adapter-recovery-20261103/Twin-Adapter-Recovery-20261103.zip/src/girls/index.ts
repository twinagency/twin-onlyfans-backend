import { riley } from "./riley.js";
import type { GirlVars } from "./template.js";

export type Girl = {
  slug: string; // folder name under data/, value of GIRL in .env
  name: string;
  cloneId: string; // her row in the live `clones` table, used only to read her media
  vars: GirlVars; // her per-girl variables (read fresh from varsFile)
  varsFile: string; // JSON file the monitor edits
  prompt: string; // the shared template (template.ts) filled with her vars
  greeting: string; // sent after the 18+ button
  brb: string[]; // only used if the AI fails twice
  deflections: string[]; // when the fan asks for something banned
};

// To add a girl: write src/girls/<slug>.ts like riley.ts and add it here.
const GIRLS: Record<string, Girl> = { riley };

export function getGirl(slug: string): Girl {
  const g = GIRLS[slug];
  if (!g) throw new Error(`unknown GIRL "${slug}". Known: ${Object.keys(GIRLS).join(", ")}`);
  return g;
}
