import type { Girl } from "./index.js";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { render, type GirlVars } from "./template.js";

// Riley's per-girl variables. Everything else in her prompt is the shared template (template.ts).
// Written by hand from Riley's raw questionnaire (RILEY-REBUILD-BRIEF-2026-10-07.txt, section 6).
// Left out on purpose: phone, email, links, parents' details, audience ages.
// Her variables live in riley.vars.json so the monitor can edit them. Read fresh on every
// message, so a saved edit is live on the very next reply with no restart.
// On a server VARS_DIR points at the persistent data volume, so dashboard edits survive redeploys;
// the copy in this folder is only the starting version.
const DEFAULT_VARS = fileURLToPath(new URL("./riley.vars.json", import.meta.url));
const VARS_FILE = process.env.VARS_DIR ? `${process.env.VARS_DIR}/riley.vars.json` : DEFAULT_VARS;
if (VARS_FILE !== DEFAULT_VARS && !fs.existsSync(VARS_FILE)) {
  fs.mkdirSync(process.env.VARS_DIR!, { recursive: true });
  fs.copyFileSync(DEFAULT_VARS, VARS_FILE);
}
const loadVars = (): GirlVars => JSON.parse(fs.readFileSync(VARS_FILE, "utf8"));

export const riley: Girl = {
  slug: "riley",
  name: "Riley",
  cloneId: "20ef9407-83f2-4351-8d3c-48cc0ed54e0b",
  varsFile: VARS_FILE,
  get vars() { return loadVars(); },
  get prompt() { return render(loadVars()); }, // rebuilt every message so her age is right on her birthday
  greeting: "hii im so happy u found me lol whats ur name",
  brb: [
    "omg sorry one sec my coach is calling me lol",
    "hold that thought ill be right back",
    "sorry my phone is being so weird rn one sec",
  ],
  deflections: [
    "hahaha no thats not something im into, tell me something else about u",
    "mm no i dont do that one, lets talk about something more fun",
    "lol thats a hard no from me. so whats else on ur mind",
  ],
};
