import { config } from "./config.js";

export type ChatMsg = { role: "system" | "user" | "assistant"; content: string };
export type LlmResult = { text: string; ok: boolean; provider: string; tokensIn: number; tokensOut: number; cost: number; attempts: number };

const URL = "https://openrouter.ai/api/v1/chat/completions";

async function callOnce(messages: ChatMsg[]) {
  const res = await fetch(URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${config.openrouterKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: config.model,
      messages,
      provider: { order: config.providerOrder, allow_fallbacks: false },
      reasoning: { enabled: false },
      temperature: config.temperature,
      top_p: config.topP,
      frequency_penalty: config.frequencyPenalty,
      presence_penalty: config.presencePenalty,
      max_tokens: config.maxTokens,
      usage: { include: true },
    }),
    signal: AbortSignal.timeout(45_000),
  });
  const j: any = await res.json().catch(() => ({}));
  if (!res.ok || j.error) throw new Error(`openrouter ${res.status}: ${JSON.stringify(j.error ?? j).slice(0, 300)}`);
  const choice = j.choices?.[0];
  let text: string = choice?.message?.content ?? "";
  if (choice?.finish_reason === "length") text = trimToSentence(text);
  return { text: text.trim(), provider: j.provider ?? "?", usage: j.usage ?? {} };
}

/** If the model hit max_tokens, cut back to the last full sentence so nothing ends mid-word. */
export function trimToSentence(t: string): string {
  const m = t.match(/^[\s\S]*[.!?…)](?:["'”]|\s*\p{Extended_Pictographic})*/u);
  return m && m[0].length > t.length * 0.4 ? m[0] : t;
}

/**
 * The one AI call per fan turn. On an error or empty reply it resamples ONCE with the exact same
 * messages (nothing appended, so nothing to leak). Never throws.
 */
export async function complete(messages: ChatMsg[]): Promise<LlmResult> {
  let tokensIn = 0, tokensOut = 0, cost = 0, provider = "none", lastErr = "";
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const r = await callOnce(messages);
      provider = r.provider;
      tokensIn += r.usage.prompt_tokens ?? 0;
      tokensOut += r.usage.completion_tokens ?? 0;
      cost += r.usage.cost ?? 0;
      if (r.text) return { text: r.text, ok: true, provider, tokensIn, tokensOut, cost, attempts: attempt };
      lastErr = "empty reply";
    } catch (e: any) {
      lastErr = String(e?.message ?? e);
    }
    console.warn(`[llm] attempt ${attempt} failed: ${lastErr.slice(0, 200)}`);
  }
  return { text: "", ok: false, provider, tokensIn, tokensOut, cost, attempts: 2 };
}
