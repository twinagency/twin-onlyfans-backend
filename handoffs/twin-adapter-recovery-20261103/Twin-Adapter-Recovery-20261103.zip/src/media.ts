import { config } from "./config.js";

// Her catalogue, read once at startup from the live tables. READ ONLY: this file never writes to Supabase.
export type Item = {
  key: string; // "photo:<id>" or "video:<id>", used for the sent list and file-id cache
  kind: "photo" | "video";
  storagePath: string;
  words: Set<string>; // searchable words from caption + tags + visual description
  label: string; // short neutral description, saved to history so she knows what he saw
  desc: string; // longer description shown to her in the menu before she sends
  explicitness: string; // none | suggestive | explicit
  stars: number; // its live price, only shown on the locked card ("normally X Stars"), never charged
};

const STOP = new Set("a an the and or of in on at to with for my me you your i is are this that it its her she person woman girl their they them wearing wears photo pic picture video baby babe u".split(" "));
// Fan slang and catalogue wording mapped to one word, so "booty" finds a photo described as "ass".
const SYN: Record<string, string> = Object.fromEntries(Object.entries({
  ass: "booty butt bum buns ass backside behind",
  boobs: "tits titties boobs boob breasts breast chest rack",
  nude: "naked nude nudes topless bare undressed",
  lingerie: "lingerie underwear panties panty bra thong knickers corset bodysuit",
  bikini: "bikini bikinis swimsuit swimwear swimming",
  pool: "pool poolside",
  gym: "gym workout exercise fitness training",
  shower: "shower bath bathtub towel",
  bed: "bed bedroom sheets",
  feet: "feet foot toes soles",
  legs: "legs thighs leg",
  selfie: "selfie selfies mirror",
  dress: "dress dresses skirt",
  stairs: "stairs staircase steps stair",
  horse: "horse horses riding",
}).flatMap(([canon, list]) => list.split(" ").map((w) => [w, canon])));
export const words = (s: string) =>
  new Set(s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w)).map((w) => SYN[w] ?? w));

/** Live upload paths are "<clone>/<type>/<Date.now()>-<file>"; the same file uploaded twice differs only in the prefix. */
export const baseName = (p: string) => p.replace(/^.*\//, "").replace(/^[0-9]{10,}-/, "").toLowerCase();

function firstSentence(s: string): string {
  const t = (s ?? "").replace(/\s+/g, " ").trim();
  const m = t.match(/^.*?[.!?](?=\s|$)/);
  return (m ? m[0] : t).slice(0, 140);
}

export function dedupe(rows: any[]): any[] {
  const seen = new Set<string>();
  return rows.filter((r) => {
    const b = baseName(r.storage_path);
    if (seen.has(b)) return false;
    seen.add(b);
    return true;
  });
}

async function rest(table: string, cloneId: string): Promise<any[]> {
  const q = `select=id,storage_path,caption,tags,visual_description,explicitness,star_value,created_at&clone_id=eq.${cloneId}&order=created_at.asc`;
  const res = await fetch(`${config.supabaseUrl}/rest/v1/${table}?${q}`, {
    headers: { apikey: config.supabaseKey, Authorization: `Bearer ${config.supabaseKey}` },
    signal: AbortSignal.timeout(20_000),
  });
  if (!res.ok) throw new Error(`supabase ${table} ${res.status}: ${(await res.text()).slice(0, 200)}`);
  return res.json();
}

export function toItem(kind: "photo" | "video", r: any): Item {
  const tags: string[] = r.tags ?? [];
  return {
    key: `${kind}:${r.id}`,
    kind,
    storagePath: r.storage_path,
    words: words(`${r.caption ?? ""} ${tags.join(" ")} ${tags.join(" ").replace(/_/g, " ")} ${r.visual_description ?? ""}`),
    label: firstSentence(r.visual_description || tags.join(", ")),
    desc: `${(r.visual_description || "").replace(/\s+/g, " ").trim().slice(0, 320)}${tags.length ? ` (tags: ${tags.join(", ")})` : ""}`,
    explicitness: r.explicitness ?? "none",
    stars: Number(r.star_value) || 0,
  };
}

export async function loadCatalogue(cloneId: string): Promise<Item[]> {
  const [photos, videos] = await Promise.all([rest("photos", cloneId), rest("videos", cloneId)]);
  const p = dedupe(photos), v = dedupe(videos);
  console.log(`[media] ${p.length} photos (${photos.length - p.length} dupes dropped), ${v.length} videos (${videos.length - v.length} dupes dropped)`);
  return [...p.map((r) => toItem("photo", r)), ...v.map((r) => toItem("video", r))];
}

// ---------- tags in her reply ----------
const TAG_RE = /\[\s*(free\s+)?(photo|pic|picture|selfie|video|vid)\s*#?(\d)?\s*(?::\s*([^\]]*))?\]/gi;
export type Want = { kind: "photo" | "video"; hint: string; free: boolean; n?: number; byDesc?: boolean };

// She sometimes copies the history note format ("[locked photo waiting for him to unlock: <desc>]")
// instead of writing a tag. That is still a send: the description picks the menu item.
const NOTE_RE = /\[\s*(?:locked\s+(photo|video)\s+waiting[^:\]]*|sent\s+him\s+(free)\s+(photo|video))\s*:\s*([^\]]*)\]/i;

/** Pull the media tag out of her text. Also drops any other stray [bracket] text so nothing internal reaches the fan. */
export function extractTag(text: string): { clean: string; want: Want | null } {
  let want: Want | null = null;
  const clean = text
    .replace(TAG_RE, (_, free: string | undefined, k: string, n: string | undefined, hint?: string) => {
      if (!want) want = { kind: /vid/i.test(k) ? "video" : "photo", hint: (hint ?? "").trim(), free: !!free, n: n ? Number(n) : undefined };
      return "";
    })
    .replace(NOTE_RE, (_, lk?: string, free?: string, fk?: string, desc?: string) => {
      if (!want) want = { kind: /video/i.test(lk ?? fk ?? "") ? "video" : "photo", hint: (desc ?? "").trim(), free: !!free, byDesc: true };
      return "";
    })
    .replace(/\[[^\]]{0,300}\]/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
  return { clean, want };
}

const ASK_RE = /\b(send|show|see|share|got|have|want|wanna|need|can i get|gimme|give me)\b.{0,40}\b(pics?|photos?|pictures?|selfies?|nudes?|videos?|vids?|clips?)\b|^\s*(pics?|nudes?|photos?|videos?|vids?)\s*[?!.]*\s*$|\b(pics?|photos?|videos?|vids?|selfies?|nudes?)\b\s*(please|pls|plz)\b|\b(show|see)\b.{0,15}\b(you|your|ur)\b.{0,25}\b(body|tits|boobs|ass|butt|pussy|outfit|naked|nude)\b/i;

/** Backup when the fan clearly asks for media and her reply forgot the tag. */
export function fanAsked(text: string): Want | null {
  if (!ASK_RE.test(text)) return null;
  return { kind: /\b(videos?|vids?|clips?)\b/i.test(text) ? "video" : "photo", hint: text, free: false };
}

const SEXY_RE = /\b(fuck|cum|cock|dick|pussy|wet|hard|horny|naked|nude|tits|boobs|ass|suck|lick|ride|strip|panties|bra|lingerie)\b/i;

/**
 * Best unsent item for this request: word overlap between the hint (+ the fan's last text) and the item,
 * a nudge toward spicier items when the chat is sexual, random tie-break. Falls back to the other kind
 * if she's out of videos. Returns null only when he has seen everything.
 */
export function pick(cat: Item[], sent: Set<string>, kind: "photo" | "video", hint: string, fanText: string, free = false, focus = ""): Item | null {
  const want = words(`${hint} ${hint} ${fanText}`);
  const focusWords = words(focus); // his newest message: each match counts 3x
  const sexy = SEXY_RE.test(`${hint} ${fanText}`);
  const score = (it: Item) => {
    let s = 0;
    for (const w of want) if (it.words.has(w)) s += 1;
    for (const w of focusWords) if (it.words.has(w)) s += 2;
    if (free) s += it.explicitness === "explicit" ? -3 : it.explicitness === "suggestive" ? 0.5 : 0; // free teasers stay tamer
    else if (sexy) s += it.explicitness === "explicit" ? 1.5 : it.explicitness === "suggestive" ? 1 : 0;
    else s += it.explicitness === "explicit" ? -0.5 : 0;
    return s + Math.random() * 0.5;
  };
  for (const k of [kind, kind === "photo" ? "video" : "photo"] as const) {
    const pool = cat.filter((it) => it.kind === k && !sent.has(it.key));
    if (pool.length) return pool.map((it) => [score(it), it] as const).sort((a, b) => b[0] - a[0])[0][1];
  }
  return null;
}

// ---------- what she can send this turn ----------
export type Menu = { free: Item | null; photos: Item[]; video: Item | null };

/**
 * Chosen by code BEFORE her reply, so she knows exactly what each item shows: 3 locked photos matched to the chat,
 * 1 locked video, 1 tame free teaser. All unsent to this fan, no item twice.
 */
export function buildMenu(cat: Item[], sent: Set<string>, context: string, focus = ""): Menu {
  const taken = new Set(sent);
  const take = (it: Item | null) => { if (it) taken.add(it.key); return it; };
  const free = take(pickKind(cat, taken, "photo", "", true));
  const photos: Item[] = [];
  for (let i = 0; i < 3; i++) {
    const it = pickKind(cat, taken, "photo", context, false, focus);
    if (!it) break;
    photos.push(take(it)!);
  }
  const video = take(pickKind(cat, taken, "video", context, false, focus));
  return { free, photos, video };
}

function pickKind(cat: Item[], taken: Set<string>, kind: "photo" | "video", context: string, free: boolean, focus = ""): Item | null {
  const it = pick(cat, taken, kind, "", context, free, focus);
  return it && it.kind === kind ? it : null;
}

/** Full description for her: the stored visual description, trimmed. */
export const describe = (it: Item) => it.desc;

export function menuText(m: Menu): string {
  const lines: string[] = [];
  m.photos.forEach((it, i) => lines.push(`[photo ${i + 1}] (locked): ${describe(it)}`));
  if (m.video) lines.push(`[video 1] (locked): ${describe(m.video)}`);
  if (m.free) lines.push(`[free photo] (free): ${describe(m.free)}`);
  if (!lines.length) return "YOUR CONTENT READY TO SEND\n(none left for him right now, so don't offer any)";
  return `YOUR CONTENT READY TO SEND (descriptions of you, written by someone looking at the file)\n${lines.join("\n")}`;
}

/** Resolve her tag (or his ask) against this turn's menu. */
export function fromMenu(m: Menu, want: Want): { item: Item; free: boolean } | null {
  if (want.byDesc) {
    // Pick the menu item her description matches best; nothing if it matches none of them.
    // Search every slot: the item she described decides, and it goes out the way its slot says (free or locked).
    const slots = [...m.photos.map((it) => ({ it, free: false })), ...(m.video ? [{ it: m.video, free: false }] : []), ...(m.free ? [{ it: m.free, free: true }] : [])];
    const w = words(want.hint);
    const best = slots.filter((x) => x.it.kind === want.kind).map((x) => [[...w].filter((y) => x.it.words.has(y)).length, x] as const).sort((a, b) => b[0] - a[0])[0];
    return best && best[0] >= 2 ? { item: best[1].it, free: best[1].free } : null;
  }
  if (want.free) return m.free ? { item: m.free, free: true } : null;
  if (want.kind === "video") return m.video ? { item: m.video, free: false } : null;
  if (want.kind === "photo" && m.photos.length) return { item: m.photos[Math.min(Math.max((want.n ?? 1) - 1, 0), m.photos.length - 1)], free: false };
  return null;
}

/** Download the real full file from private storage via a short-lived signed URL. */
export async function download(it: Item): Promise<Buffer> {
  const sign = await fetch(`${config.supabaseUrl}/storage/v1/object/sign/media/${it.storagePath}`, {
    method: "POST",
    headers: { apikey: config.supabaseKey, Authorization: `Bearer ${config.supabaseKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ expiresIn: 300 }),
    signal: AbortSignal.timeout(20_000),
  });
  const j: any = await sign.json().catch(() => ({}));
  if (!sign.ok || !j.signedURL) throw new Error(`sign failed ${sign.status}: ${JSON.stringify(j).slice(0, 200)}`);
  const res = await fetch(`${config.supabaseUrl}/storage/v1${j.signedURL}`, { signal: AbortSignal.timeout(120_000) });
  if (!res.ok) throw new Error(`download failed ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}
