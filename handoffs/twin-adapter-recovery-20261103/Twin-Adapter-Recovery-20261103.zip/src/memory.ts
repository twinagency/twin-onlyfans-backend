import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";

export type Msg = { role: "user" | "assistant"; content: string };
/** epoch goes up on every /start or /reset, so a reply that was already running can tell its chat was wiped. */
export type Chat = { ageConfirmed: boolean; history: Msg[]; sent: string[]; epoch: number;
  bcid?: string; // business connection this fan writes through (unset = plain bot chat)
  who?: string; // @username or id, for the monitor
  owned?: string[]; // item keys he has paid for (never offered again)
}; // sent = media keys already sent to this fan

const dir = () => path.join(config.dataDir, config.girl);
const file = (id: number | string) => path.join(dir(), `${id}.json`);

export function loadChat(id: number | string): Chat {
  try {
    const c = JSON.parse(fs.readFileSync(file(id), "utf8"));
    return {
      ageConfirmed: !!c.ageConfirmed,
      history: Array.isArray(c.history) ? c.history : [],
      sent: Array.isArray(c.sent) ? c.sent : [],
      epoch: Number(c.epoch) || 0,
      bcid: c.bcid || undefined,
      who: c.who || undefined,
      owned: Array.isArray(c.owned) ? c.owned : [],
    };
  } catch {
    return { ageConfirmed: false, history: [], sent: [], epoch: 0 };
  }
}

export function saveChat(id: number | string, chat: Chat) {
  fs.mkdirSync(dir(), { recursive: true });
  chat.history = chat.history.slice(-config.historyLimit);
  fs.writeFileSync(file(id), JSON.stringify(chat, null, 2));
}

/** /reset: wipe history and sent list, keep the 18+ confirmation. */
export function resetChat(id: number | string) {
  const c = loadChat(id);
  // Fresh chat: history and the offered list go; what he actually paid for stays his.
  saveChat(id, { ageConfirmed: c.ageConfirmed, history: [], sent: [...(c.owned ?? [])], epoch: c.epoch + 1, bcid: c.bcid, who: c.who, owned: c.owned });
}

/** Save only if nobody reset this chat since `epoch` was read. False = the turn is stale, drop it. */
export function saveIfCurrent(id: number | string, chat: Chat): boolean {
  if (loadChat(id).epoch !== chat.epoch) return false;
  saveChat(id, chat);
  return true;
}

/** Remember how to reach this fan (business connection) and what to call him in the monitor. */
export function touchChat(id: number | string, info: { bcid?: string; who?: string }) {
  const c = loadChat(id);
  if ((info.bcid ?? c.bcid) === c.bcid && (info.who ?? c.who) === c.who) return;
  c.bcid = info.bcid ?? c.bcid;
  c.who = info.who ?? c.who;
  saveChat(id, c);
}

export function setConfirmed(id: number | string, v: boolean) {
  const c = loadChat(id);
  c.ageConfirmed = v;
  saveChat(id, c);
}

// This bot's own Telegram file ids (the live bots' ids belong to their tokens and can't be reused).
const fidFile = () => path.join(dir(), "_file_ids.json");
let fids: Record<string, string> | null = null;
export function getFileId(key: string): string | undefined {
  if (!fids) { try { fids = JSON.parse(fs.readFileSync(fidFile(), "utf8")); } catch { fids = {}; } }
  return fids![key];
}
export function setFileId(key: string, fid: string) {
  getFileId(key);
  fids![key] = fid;
  fs.mkdirSync(dir(), { recursive: true });
  fs.writeFileSync(fidFile(), JSON.stringify(fids, null, 2));
}
