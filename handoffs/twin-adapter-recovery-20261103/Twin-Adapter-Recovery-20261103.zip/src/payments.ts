// Telegram Stars: the price of a locked item, and the sales ledger.
//
// A locked item goes out as a Telegram paid post (sendPaidMedia) whose payload is "<kind>_<id>".
// Business-connection sends fire no purchase update, so (like live Twin's star reconciler) the
// source of truth is a poller on getStarTransactions: every incoming Stars payment with a
// paid_media_payload is one sale. Ledger: data/<girl>/purchases.jsonl, deduped by Telegram's charge id.
import fs from "node:fs";
import path from "node:path";
import type { Api } from "grammy";
import { config } from "./config.js";

export type Purchase = {
  ts: string; // when Telegram says he paid
  chatId: number; // the fan (his Telegram user id)
  itemKey: string; // "photo:<id>" / "video:<id>"
  kind: "photo" | "video";
  stars: number;
  chargeId: string;
};

/** STAR_PRICE in .env: a number (test price for every item, default 1) or "real" (each item's live star_value). */
export function priceFor(itemStars: number): number {
  const mode = (process.env.STAR_PRICE ?? "1").trim();
  if (mode === "real") return Math.max(1, Math.round(itemStars) || 1);
  return Math.max(1, Math.round(Number(mode)) || 1);
}
export const priceMode = () => ((process.env.STAR_PRICE ?? "1").trim() === "real" ? "real" : `test (${priceFor(0)} Star each)`);

export const payloadFor = (key: string) => key.replace(":", "_"); // "photo:<id>" -> "photo_<id>"
export function keyFromPayload(p: string | undefined): { key: string; kind: "photo" | "video" } | null {
  const m = p?.match(/^(photo|video)_([0-9a-f-]{36})$/i);
  return m ? { key: `${m[1].toLowerCase()}:${m[2]}`, kind: m[1].toLowerCase() as "photo" | "video" } : null;
}

const file = () => path.join(config.dataDir, config.girl, "purchases.jsonl");
let seen: Set<string> | null = null;

export function purchases(): Purchase[] {
  try {
    return fs.readFileSync(file(), "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l));
  } catch { return []; }
}

/** Adds the sale once (by charge id). True when it was new. */
export function recordPurchase(p: Purchase): boolean {
  if (!seen) seen = new Set(purchases().map((x) => x.chargeId));
  if (seen.has(p.chargeId)) return false;
  seen.add(p.chargeId);
  fs.mkdirSync(path.dirname(file()), { recursive: true });
  fs.appendFileSync(file(), JSON.stringify(p) + "\n");
  return true;
}

/** Turns one getStarTransactions entry into a sale, or null when it isn't a paid-post unlock. */
export function purchaseFromTransaction(t: any): Purchase | null {
  const src = t?.source;
  if (!src || src.type !== "user" || !src.user?.id) return null;
  const item = keyFromPayload(src.paid_media_payload);
  if (!item) return null;
  return { ts: new Date((t.date ?? 0) * 1000).toISOString(), chatId: src.user.id, itemKey: item.key, kind: item.kind, stars: Number(t.amount) || 0, chargeId: String(t.id) };
}

/** Polls Telegram for new Stars payments every `everyMs` and calls onSale for each new one. */
export function startStarPoller(api: Api, onSale: (p: Purchase) => void | Promise<void>, everyMs = 30_000) {
  const tick = async () => {
    try {
      // Newest are at the end; the last 100 is plenty for a test bot.
      const res: any = await api.raw.getStarTransactions({ offset: 0, limit: 100 });
      for (const t of res?.transactions ?? []) {
        const p = purchaseFromTransaction(t);
        if (p && recordPurchase(p)) await onSale(p);
      }
    } catch (e: any) {
      console.warn(`[stars] poll failed: ${String(e?.message ?? e).slice(0, 160)}`);
    }
  };
  void tick();
  return setInterval(tick, everyMs);
}
