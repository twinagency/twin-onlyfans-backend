import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";

// ---------- detection ----------
const TEEN_WORDS = "eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen";
const LOW_WORDS = "zero|one|two|three|four|five|six|seven|eight|nine|ten";
const NUM_WORDS = `${LOW_WORDS}|${TEEN_WORDS}`;
const LEAD = "(?:i'?m|im|i am|you'?re|youre|you are|u r|ur|u are|she'?s|shes|she is|he'?s|he is|be|act|acting|pretend(?:\\s+(?:to be|you'?re|youre|you are|ur))?|roleplay(?:\\s+as)?|age|aged|turning)\\s+(?:a\\s+)?";
const STRICT_END = "(?=\\s*(?:$|[.,!?;:)\\n]|and\\b|but\\b|yo\\b|y\\/o|years?\\b|yrs?\\b))";
const SEXUAL = "sex|fuck|fucking|fucked|nude|nudes|naked|horny|cum|cock|dick|pussy|tits|boobs|suck|blowjob|kinky|porn|sexy|spank|strip";

const MINOR: RegExp[] = [
  // "i'm 16", "pretend you're 16", "she's fifteen" (digits and teen words: loose; one..ten: strict follow)
  new RegExp(`\\b${LEAD}(?:[0-9]|1[0-7])(?![0-9]|[:.,]\\d)(?!['’]\\d)(?!\\s*(?:ft|foot|feet|cm|kg|inch|inches|min|mins|minutes|hours|hrs|times|x|%|\\$|pm|am|st|nd|rd|th|of)\\b)`, "i"),
  new RegExp(`\\b${LEAD}(?:${TEEN_WORDS})\\b`, "i"),
  new RegExp(`\\b${LEAD}(?:${LOW_WORDS})${STRICT_END}`, "i"),
  new RegExp(`\\b(?:[0-9]|1[0-7]|${NUM_WORDS})[\\s-]*(?:yo|y\\/o|yr|yrs|yr old|yrs old|y\\.o\\.?|years? old|year-old|yearold)\\b`, "i"),
  /\bunder\s*-?\s*age(?:d)?\b/i,
  /\bunder\s*(?:the age of\s*)?(?:18|eighteen)\b/i,
  /\bminors?\b/i,
  /\bunderaged\b/i,
  /\bjailbait\b/i,
  /\bloli(?:ta|s)?\b/i,
  /\bshota\b/i,
  /\bpre-?teen\b/i,
  /\bpedo(?:phile|philia)?\b/i,
  /\bchild(?:ren)?\b.{0,30}\b(?:sex|fuck|nude|naked|porn)/i,
  /\b(?:sex|fuck|nude|naked|porn).{0,30}\bchild(?:ren)?\b/i,
  /\bschool\s*-?\s*girl\b/i,
  /\bschool\s*-?\s*boy\b/i,
  /\bhigh\s*-?\s*school(?:er)?\b/i,
  /\bmiddle\s*-?\s*school\b/i,
  /\b(?:in|from)\s+(?:the\s+)?(?:\d+(?:st|nd|rd|th)|ninth|tenth|eleventh|twelfth)\s+grade\b/i,
  /\byoung\s+girl\b/i,
  /\bkid(?:s|do)?\b.{0,25}\b(?:sex|fuck|nude|naked|horny)/i,
  new RegExp(`\\b(?:teen|teens|teenage|teenager|barely legal)\\b.{0,40}\\b(?:${SEXUAL})\\b`, "i"),
  new RegExp(`\\b(?:${SEXUAL})\\b.{0,40}\\b(?:teen|teens|teenage|teenager|barely legal)\\b`, "i"),
  /\bunder\s*age\b/i,
  /\bflat[- ]chested\s+(?:girl|kid)\b/i,
];

const INCEST: RegExp[] = [
  /\bincest(?:uous)?\b/i,
  new RegExp(`\\b(?:my|your|ur|her)\\s+(?:step)?(?:sister|brother|sis|bro|mom|mum|mother|dad|father|daughter|son|cousin|aunt|uncle|niece|nephew|sibling)\\b.{0,40}\\b(?:${SEXUAL})\\b`, "i"),
  new RegExp(`\\b(?:${SEXUAL})\\b.{0,40}\\b(?:my|your|ur|her)\\s+(?:step)?(?:sister|brother|sis|bro|mom|mum|mother|dad|father|daughter|son|cousin|aunt|uncle|niece|nephew|sibling)\\b`, "i"),
  /\b(?:roleplay|role-play|pretend|act|play)\b.{0,30}\b(?:my|as my|like my|be my)\s+(?:little\s+|step)?(?:sister|brother|sis|bro|mom|mum|mother|dad|father|daughter|son|sibling)\b/i,
  /\b(?:be|act like|play)\s+my\s+(?:little\s+)?(?:sister|sis|daughter|mom|mum|mother)\b/i,
  /\b(?:step)?(?:sis|sister|brother|mom|mum|daddy|dad)\s*(?:-)?\s*(?:fantasy|roleplay|rp)\b/i,
  /\bfamily\s+(?:sex|roleplay)\b/i,
];

const BEAST: RegExp[] = [
  /\bbestiality\b/i,
  /\bzoophil\w*\b/i,
  /\bbeastiality\b/i,
  new RegExp(`\\b(?:dog|horse|pony|donkey|animal|pet|puppy|cat|dolphin|stallion|goat)\\b.{0,40}\\b(?:${SEXUAL}|fuck(?:ed|s)?|knot|mount(?:ed)?)\\b`, "i"),
  new RegExp(`\\b(?:${SEXUAL}|fuck(?:ed|s)?)\\b.{0,40}\\b(?:a|the|my|your|with)\\s+(?:dog|horse|pony|donkey|animal|pet|puppy|dolphin|stallion|goat)\\b`, "i"),
];

const NONCON: RegExp[] = [
  /\brap(?:e|ed|es|ing|ist)\b/i,
  /\bnon-?consen\w*\b/i,
  /\bwithout\s+(?:her|his|your|their)\s+consent\b/i,
  /\bforce[ds]?\s+(?:you|her|him|them)\s+(?:to|into)\b.{0,30}\b(?:sex|fuck|suck|strip)/i,
  /\bforce[ds]?\s+(?:myself|himself)\s+on\b/i,
  /\b(?:drugged|roofied|roofie|date rape)\b/i,
  /\b(?:asleep|unconscious|passed out|knocked out|sleeping)\b.{0,50}\b(?:fuck|sex|rape|cum|molest|touch|use you)/i,
  /\b(?:fuck|sex|rape|cum|molest|touch|use)\b.{0,50}\b(?:while|when)\s+(?:you'?re|youre|you are|she'?s|shes|she is)\s+(?:asleep|unconscious|passed out|sleeping|drugged)\b/i,
  /\bmolest\w*\b/i,
  /\bsexual\s+assault\b/i,
  /\bsay\s+no\b.{0,30}\b(?:anyway|but i)\b/i,
  /\bcan'?t\s+say\s+no\b/i,
  /\bkidnap\w*\b.{0,40}\b(?:fuck|sex|use)\b/i,
  /\bbegging\s+me\s+to\s+stop\b(?!\s+(?:messing|teasing|being|playing|talking|tease|that|it so))/i,
  /\bnot\s+(?:want|wanting)\s+it\b.{0,30}\b(?:anyway|but)\b/i,
];

const CELEB_NOTE = /\b(?:celebrity|celeb)\b.{0,30}\b(?:nude|sex|fuck|naked)\b/i;

type Hit = { category: "minor" | "incest" | "bestiality" | "non-consent" | "real-person"; pattern: string };

export function checkText(text: string): Hit | null {
  const t = text.normalize("NFKC").replace(/[​-‏⁠]/g, "");
  const groups: [Hit["category"], RegExp[]][] = [
    ["minor", MINOR], ["incest", INCEST], ["bestiality", BEAST], ["non-consent", NONCON], ["real-person", [CELEB_NOTE]],
  ];
  for (const [category, res] of groups) {
    for (const re of res) if (re.test(t)) return { category, pattern: re.source.slice(0, 60) };
  }
  return null;
}

// ---------- canned deflections (in character) ----------
export const DEFLECTIONS = [
  "mm nope, not going there babe. try me with something else 😏",
  "haha no. that's a hard no from me, ask me something that's actually fun",
  "nah not my thing, don't ruin the mood. what else you got for me",
  "uh no babe. change the subject or i'm leaving you on read",
  "not doing that one, sorry. come on, be good and tell me what you're really in the mood for",
];
let deflectIdx = 0;
export function nextDeflection(): string {
  const d = DEFLECTIONS[deflectIdx % DEFLECTIONS.length];
  deflectIdx++;
  return d;
}

export function logBlocked(entry: Record<string, unknown>) {
  try {
    fs.mkdirSync(config.logDir, { recursive: true });
    fs.appendFileSync(path.join(config.logDir, "blocked.jsonl"), JSON.stringify({ ts: new Date().toISOString(), ...entry }) + "\n");
  } catch {}
}

/** Input pre-filter. Returns a deflection if blocked (message must NOT reach the LLM). */
export function preFilter(chatId: string | number, text: string): string | null {
  const hit = checkText(text);
  if (!hit) return null;
  logBlocked({ stage: "input", chatId, category: hit.category, pattern: hit.pattern, text });
  return nextDeflection();
}

// ---------- output cleanup ----------
/** Post-filter on model reply. Returns {text} cleaned, or {blocked:true, text: deflection}. */
export function postFilter(chatId: string | number, reply: string): { text: string; blocked: boolean } {
  const hit = checkText(reply);
  if (hit) {
    logBlocked({ stage: "output", chatId, category: hit.category, pattern: hit.pattern, text: reply });
    return { text: nextDeflection(), blocked: true };
  }
  return { text: cleanReply(reply), blocked: false };
}

export function cleanReply(raw: string): string {
  let t = raw.replace(/\r/g, "");
  // em/en dashes -> comma or space
  t = t.replace(/\s*[—–]\s*/g, ", ").replace(/,\s*,/g, ",").replace(/,\s*([.!?\n])/g, "$1");
  // drop lines that sound like an assistant
  t = t
    .split("\n")
    .filter((l) => !/as an ai\b|language model|i cannot (?:help|assist|continue)|i can'?t (?:assist|help with that)/i.test(l))
    .join("\n");
  // strip leading speaker labels and wrapping quotes
  t = t.replace(/^\s*(?:mia|assistant)\s*:\s*/gim, "");
  t = t
    .split("\n")
    .map((l) => l.trim().replace(/^["“”'`]+(.+?)["“”'`]+$/, "$1"))
    .join("\n");
  return t.replace(/\n{2,}/g, "\n").trim();
}
