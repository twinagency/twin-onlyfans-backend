import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";
import type { Girl } from "./girls/index.js";
import { complete, type ChatMsg } from "./llm.js";
import { loadChat, saveChat, saveIfCurrent, type Chat } from "./memory.js";
import { checkText, cleanReply, logBlocked } from "./safety.js";
import { extractTag, buildMenu, menuText, fromMenu, type Item } from "./media.js";

export type TurnResult = {
  bubbles: string[];
  media: Item | null;
  free: boolean; // true = real file goes straight out; false = locked card with an Unlock button
  note: string; // short status for the log: ok / blocked-in / blocked-out / ai-failed
  provider: string;
  tokensIn: number;
  tokensOut: number;
  cost: number;
  ms: number;
};

/** No emojis ever (Ronan's rule). Prompt says so too; this is the backstop. */
export const stripEmoji = (t: string) =>
  t.replace(/[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\u200D\uFE0F]/gu, "").replace(/(^|\s)(?::\)|:\(|;\)|:D|:P|<3|xD)(?=\s|$)/gi, "$1").replace(/[ \t]{2,}/g, " ").replace(/ +([.,!?])/g, "$1").trim();

/** She must lead, not hand it back. Drops a trailing "what would u do to me" style question when there's other text. */
const THROW_BACK = /(?<=^|[.!?,]\s*|\s)(?:now\s+|so\s+|ok\s+)?(?:tell me[, ]+)?(?:what|how)\s+(?:would|will|wud|wld|do)\s+(?:u|you)(?:\s+wanna|\s+want to)?\s+(?:do|have done)\b[^.!?]*[.!?]?\s*$|(?<=^|[.!?,]\s*|\s)tell me (?:what|how) (?:u|you)(?:'?d| would| wanna| want to)[^.!?]*[.!?]?\s*$|(?<=^|[.!?,]\s*|\s)(?:ur|your) turn[^.!?]*[.!?]?\s*$/i;
export function dropThrowBack(t: string): string {
  const cut = t.replace(THROW_BACK, "").trim().replace(/,$/, "");
  return cut.length >= 15 ? cut : t;
}

const pickOne = <T>(a: T[]) => a[Math.floor(Math.random() * a.length)];

/**
 * Where a turn reads and commits the conversation.
 *
 * The default is the existing Telegram memory (data/<girl>/<chatId>.json), so runTurn behaves exactly
 * as before. The channel service supplies a durable bridge transcript instead, so a channel
 * conversation's history lives in the recoverable bridge journal rather than the legacy file.
 */
export type TurnTranscript = {
  /** The transcript the model reads, with the revision it belongs to. */
  load(id: number | string): Chat;
  /**
   * Commit the fan's message, plus her reply when `assistant` is given, if the revision has not moved.
   * Returns false when the conversation moved on (reset), which makes this turn stale.
   */
  commit(id: number | string, chat: Chat, assistant: string | null): boolean;
};

const memoryTranscript: TurnTranscript = {
  load: (id) => loadChat(id),
  commit: (id, chat, assistant) => {
    if (assistant) chat.history.push({ role: "assistant", content: assistant });
    return saveIfCurrent(id, chat);
  },
};

/** One fan turn: filter, ONE AI call, clean, choose media. Saves history. Sending is the caller's job. */
/** Full record of one turn for the monitor dashboard (logs/requests.jsonl): exactly what the AI saw and said. */
export type RequestRecord = {
  ts: string; chatId: number | string; fanText: string; note?: string; ms?: number;
  system?: string; history?: ChatMsg[]; menu?: { slot: string; key: string; stars: number; desc: string }[];
  raw?: string; final?: string[]; media?: { key: string; kind: string; free: boolean; stars: number; label: string } | null;
  provider?: string; tokensIn?: number; tokensOut?: number; cost?: number; attempts?: number;
};
function logRequest(rec: RequestRecord) {
  try {
    fs.mkdirSync(config.logDir, { recursive: true });
    fs.appendFileSync(path.join(config.logDir, "requests.jsonl"), JSON.stringify(rec) + "\n");
  } catch {}
}

export async function runTurn(girl: Girl, catalogue: Item[], chatId: number | string, fanText: string, transcript: TurnTranscript = memoryTranscript): Promise<TurnResult> {
  const rec: RequestRecord = { ts: new Date().toISOString(), chatId, fanText };
  try {
    const r = await runTurnInner(girl, catalogue, chatId, fanText, rec, transcript, true);
    Object.assign(rec, { note: r.note, ms: r.ms, final: r.bubbles, provider: r.provider, tokensIn: r.tokensIn, tokensOut: r.tokensOut, cost: r.cost,
      media: r.media ? { key: r.media.key, kind: r.media.kind, free: r.free, stars: r.media.stars, label: r.media.label } : null });
    return r;
  } finally {
    logRequest(rec);
  }
}

/**
 * A generated reply held outside conversation history until a transport confirms delivery.
 * `epoch` is the conversation revision the reply was generated against; committing later must
 * check it so a reset conversation never receives a stale reply.
 */
export type PendingReply = { chatId: number | string; epoch: number; text: string };
export type GenerationResult = { result: TurnResult; pending: PendingReply | null };

/**
 * Same pipeline as runTurn, but her reply is NOT written into conversation history: only the fan's
 * message is committed, and the reply comes back as `pending` for the durable channel service to
 * commit on delivery acknowledgement. Telegram keeps calling runTurn, whose behaviour is unchanged.
 */
export async function generateTurn(girl: Girl, catalogue: Item[], chatId: number | string, fanText: string, transcript: TurnTranscript = memoryTranscript): Promise<GenerationResult> {
  const rec: RequestRecord = { ts: new Date().toISOString(), chatId, fanText };
  try {
    const epoch = transcript.load(chatId).epoch;
    const result = await runTurnInner(girl, catalogue, chatId, fanText, rec, transcript, false);
    Object.assign(rec, { note: result.note, ms: result.ms, final: result.bubbles, provider: result.provider, tokensIn: result.tokensIn, tokensOut: result.tokensOut, cost: result.cost,
      media: result.media ? { key: result.media.key, kind: result.media.kind, free: result.free, stars: result.media.stars, label: result.media.label } : null });
    const text = result.bubbles.join("\n");
    const pending = result.note === "reset-during-turn" || !text ? null : { chatId, epoch, text };
    return { result, pending };
  } finally {
    logRequest(rec);
  }
}

async function runTurnInner(girl: Girl, catalogue: Item[], chatId: number | string, fanText: string, rec: RequestRecord, transcript: TurnTranscript, commitAssistant: boolean): Promise<TurnResult> {
  const t0 = Date.now();
  const base = { media: null, free: false, provider: "none", tokensIn: 0, tokensOut: 0, cost: 0 };

  const inHit = checkText(fanText);
  if (inHit) {
    logBlocked({ stage: "input", chatId, category: inHit.category, text: fanText });
    return { ...base, bubbles: [pickOne(girl.deflections)], note: `blocked-in:${inHit.category}`, ms: Date.now() - t0 };
  }

  const chat = transcript.load(chatId);
  // /start or /reset during this turn: nothing is saved and nothing is sent (Jesse's review #2).
  const stale = (): TurnResult => ({ ...base, bubbles: [], note: "reset-during-turn", ms: Date.now() - t0 });
  chat.history.push({ role: "user", content: fanText });
  // The model sees only her prompt and the conversation. Nothing is ever added after the fan's message.
  // Her sendable items are picked BEFORE the call and described in the system prompt (still before the chat,
  // never after his message), so she knows exactly what she's teasing.
  // His newest message counts three times as much as the rest of the recent chat, so a specific ask lands.
  const recent = chat.history.slice(-6).map((m) => m.content).join(" ");
  const menu = buildMenu(catalogue, new Set(chat.sent), recent, fanText);
  const messages: ChatMsg[] = [
    { role: "system", content: `${girl.prompt}\n\n${menuText(menu)}` },
    ...chat.history.slice(-config.historyLimit),
  ];
  rec.system = messages[0].content;
  rec.history = messages.slice(1);
  rec.menu = [
    ...menu.photos.map((it, i) => ({ slot: `photo ${i + 1}`, key: it.key, stars: it.stars, desc: it.desc })),
    ...(menu.video ? [{ slot: "video 1", key: menu.video.key, stars: menu.video.stars, desc: menu.video.desc }] : []),
    ...(menu.free ? [{ slot: "free photo", key: menu.free.key, stars: 0, desc: menu.free.desc }] : []),
  ];
  const r = await complete(messages);
  rec.raw = r.text;
  rec.attempts = r.attempts;
  const meta = { provider: r.provider, tokensIn: r.tokensIn, tokensOut: r.tokensOut, cost: r.cost };

  if (!r.ok) {
    if (!transcript.commit(chatId, chat, null)) return stale(); // keep his message so the next turn still answers it
    return { ...base, ...meta, bubbles: [pickOne(girl.brb)], note: "ai-failed", ms: Date.now() - t0 };
  }

  const outHit = checkText(r.text);
  if (outHit) {
    logBlocked({ stage: "output", chatId, category: outHit.category, text: r.text });
    if (!transcript.commit(chatId, chat, null)) return stale(); // the blocked reply is never saved, so it can't be copied later
    return { ...base, ...meta, bubbles: [pickOne(girl.deflections)], note: `blocked-out:${outHit.category}`, ms: Date.now() - t0 };
  }

  const { clean, want } = extractTag(r.text);
  // lowercase only, like a real girl texting (Ronan's rule). Prompt says so too; this is the backstop.
  const text = stripEmoji(cleanReply(clean)).replace(new RegExp(`^\\s*${girl.name}\\s*:\\s*`, "gim"), "").toLowerCase();
  // ONLY the exact item she tagged goes out. No tag = no media (she may have said she doesn't have it),
  // and code never swaps the kind or the item, so the file always matches what she just said.
  const request = want;
  const chosen = request ? fromMenu(menu, request) : null;
  const media = chosen?.item ?? null;
  const free = chosen?.free ?? false;

  const textFinal = dropThrowBack(text);
  const lines = textFinal.split("\n").map((l) => l.trim()).filter(Boolean);
  // ONE message per reply, never a burst: her lines are joined into a single text.
  const bubbles = lines.length ? [lines.join(" ")] : [];
  if (!bubbles.length && !media) bubbles.push(pickOne(girl.brb));

  // Telegram (commitAssistant) keeps her reply in history immediately. The channel service defers it:
  // only the fan's message is committed here and the reply is committed on delivery acknowledgement.
  if (!transcript.commit(chatId, chat, bubbles.length && commitAssistant ? bubbles.join("\n") : null)) return stale();
  return { ...meta, bubbles, media, free, note: want ? "ok+tag" : request ? "ok+asked" : "ok", ms: Date.now() - t0 };
}

/**
 * After a send succeeded: remember the item for this fan (never offered twice) and tell her what happened,
 * so she can talk about it. "free" = he got the file, "locked" = he got the locked card, "unlocked" = he tapped Unlock.
 */
export function noteMediaSent(chatId: number | string, it: Item, how: "free" | "locked" | "unlocked") {
  const chat = loadChat(chatId);
  if (!chat.sent.includes(it.key)) chat.sent.push(it.key);
  const tag =
    how === "free" ? `[sent him free ${it.kind}: ${it.label}]`
    : how === "locked" ? `[locked ${it.kind} waiting for him to unlock: ${it.label}]`
    : `[he unlocked the ${it.kind}: ${it.label}]`;
  const last = chat.history[chat.history.length - 1];
  if (last?.role === "assistant") last.content += `\n${tag}`;
  else chat.history.push({ role: "assistant", content: tag });
  saveChat(chatId, chat);
}

export function logTurn(entry: { fan: string; text: string; r: TurnResult; mediaStatus?: string }) {
  const { r } = entry;
  const one = (s: string) => s.replace(/\s+/g, " ").slice(0, 300);
  const line =
    `${new Date().toISOString()} | ${entry.fan} | ${r.note} | ${r.ms}ms | ${r.provider} | in=${r.tokensIn} out=${r.tokensOut} $${r.cost.toFixed(5)}\n` +
    `  FAN: ${one(entry.text)}\n` +
    `  HER: ${one(r.bubbles.join(" / ")) || "(none)"}\n` +
    (r.media ? `  MEDIA: ${r.free ? "FREE" : "LOCKED"} ${r.media.key} ${r.media.stars}* ${entry.mediaStatus ?? ""} (${one(r.media.label)})\n` : "");
  process.stdout.write(line);
  try {
    fs.mkdirSync(config.logDir, { recursive: true });
    fs.appendFileSync(path.join(config.logDir, "turns.log"), line);
  } catch {}
}
